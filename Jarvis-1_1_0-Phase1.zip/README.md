# Jarvis Android Assistant — 1.1.0 (Phase 1: foundation)

## 1.1.0 — what is new
- **Native UI, no WebView.** App screen, cross-app overlay and the system-assistant session all use one
  light native panel (`JarvisPanel`). The bubble is a Canvas orb that is static when idle and only
  animates while Jarvis listens / thinks / acts. Nothing heavy, tuned for a 2 GB phone.
- **Permission autopilot.** The user only switches Accessibility ON. Jarvis then opens the remaining
  permission pages (system settings, notification access, Do Not Disturb access, battery exemption,
  Vivo autostart) and taps the switch / "Allow" itself. It never turns a permission off.
- **Health + watchdog.** Live "Jarvis health" card, and a tiny foreground service that re-checks every
  20 s that Accessibility is still ON; if Vivo or the system switched it off it posts a one-tap alert.
- **Recon.** "Phone scan" reads the notification panel (3 pages), Bluetooth, Wi-Fi and Sound settings and
  writes a report (`jarvis-recon.txt`, share/copy) so Jarvis can be calibrated to the real phone.
- STOP button that really stops a running multi-step command; several screens can watch progress at once.

# Earlier: 1.0.1

Personal-use Android assistant for Android 10+ (UI-tap based control, offline-first).

## 1.0.1 — audit fixes
1. Dictated message bodies are no longer split on "aur / and / phir / then"; chained commands only
   run when every part is understood.
2. Tiered approval policy: user commands run directly; steps from a *remote model* need approval for
   calls, SMS and sensitive clicks.
3. `dialer kholo`, `call log kholo`, `caller id` no longer place calls.
4. Relative volume/brightness (`badhao`, `kam karo`, `thoda`, `mute`, `full`) instead of always 50%.
5. UI-clause parser is anchored (ordinary sentences are not hijacked into click/type/search).
6. Task lanes run sequentially (no more step interleaving across apps); failed lanes skip only themselves.
7. Manifest: `ACCESS_WIFI_STATE`, `ACCESS_NETWORK_STATE`, `BLUETOOTH` (<=API 30); state reads are
   exception-safe; Quick Settings is closed after toggling and expanded by swipe if tiles are hidden.
8. Brightness switches to manual mode, uses 1-255, and the "Modify system settings" page is opened and
   tapped through Accessibility.
9. Alarm: `SET_ALARM` permission, `SKIP_UI` with fallback, morning/evening handling.
10. History no longer stores raw text, typed text or message bodies.

Also: `KeyEvent` media constants (build fix), explicit coroutines + `org.json` test dependency,
APK build no longer blocked by unit tests, approve/cancel off the main thread, plain-text/reply-only
cloud answers are shown, app list cached, voice language tag + extra error codes, repo cleanup.

## Brain setup (optional)
Open Jarvis settings and configure an OpenAI-compatible endpoint, model and API key (stored with
Android Keystore). Without it Jarvis uses the local command engine.

## Example commands
`YouTube kholo`, `Zubair ko call karo`, `volume badhao`, `brightness 30`, `Wi-Fi band karo`,
`alarm shaam 6 baje`, `Zubair ko message bhejo: main aur tum kal milenge`,
`Chrome kholo aur Google par cricket search karo`.

## Platform limits
Android 10 gives no unlimited background control; mobile-data/hotspot toggling is OEM dependent;
banking apps may block Accessibility; no on-device LLM is bundled.

## CI
The workflow picks the latest committed zip, runs preflight, builds the debug APK, uploads it, and
then runs unit tests (a failing test is visible but never hides the APK).
