package com.kaifrza.jarvis.ui

import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.kaifrza.jarvis.core.brain.BrainTaskRunner

/**
 * The one native assistant panel used by the app, the cross-app overlay and the system voice session.
 * Plain framework views only (no WebView) so it opens instantly and stays light on a 2 GB phone.
 */
class JarvisPanel(context: Context) : LinearLayout(context) {
    interface Listener {
        fun onCommand(text: String)
        fun onMic()
        fun onApprove()
        fun onCancel()
        /** STOP pressed while a command is running. */
        fun onStop()
        fun onOpenSettings()
    }

    private var listener: Listener? = null

    /** Called when the user touches the input box (the overlay must become focusable to show the keyboard). */
    var onInputTouched: (() -> Unit)? = null

    private val orb = OrbView(context)
    private val headline = Ui.label(context, PanelModel.headline(""), 15f, Ui.TEXT, bold = true)
    private val sub = Ui.label(context, "", 12f, Ui.MUTED)
    private val scroll = ScrollView(context)
    private val messages = LinearLayout(context).apply { orientation = VERTICAL }
    private val taskBoard = LinearLayout(context).apply { orientation = VERTICAL }
    private val approvalRow = LinearLayout(context).apply { orientation = VERTICAL; visibility = View.GONE }
    private val approvalText = Ui.label(context, "", 13f, Ui.TEXT)
    private val inputRow = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private val stopRow = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER; visibility = View.GONE }
    private val input = EditText(context)
    private var maxMessages = 24

    init {
        orientation = VERTICAL
        background = Ui.rounded(Ui.SURFACE, Ui.dp(context, 20), 0x3363D8FF, Ui.dp(context, 1))
        val pad = Ui.dp(context, 12)
        setPadding(pad, pad, pad, pad)

        val header = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(orb, LayoutParams(Ui.dp(context, 40), Ui.dp(context, 40)))
        val titles = LinearLayout(context).apply { orientation = VERTICAL }
        titles.addView(headline)
        titles.addView(sub)
        header.addView(titles, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = Ui.dp(context, 10) })
        header.addView(Ui.pill(context, "Brain", false) { listener?.onOpenSettings() })
        addView(header)

        scroll.addView(messages)
        addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = Ui.dp(context, 8) })
        addView(taskBoard, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        approvalRow.addView(approvalText)
        val buttons = LinearLayout(context).apply { orientation = HORIZONTAL }
        buttons.addView(Ui.pill(context, "Haan, karo", true) { listener?.onApprove() })
        buttons.addView(
            Ui.pill(context, "Cancel", false) { listener?.onCancel() },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { leftMargin = Ui.dp(context, 8) }
        )
        approvalRow.addView(buttons, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(context, 6) })
        addView(approvalRow, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(context, 6) })

        stopRow.addView(Ui.pill(context, "STOP", true) { listener?.onStop() })
        addView(stopRow, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(context, 8) })

        input.apply {
            hint = "Command likho…"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.TEXT)
            textSize = 14f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = Ui.rounded(Ui.SURFACE2, Ui.dp(context, 14))
            setPadding(Ui.dp(context, 12), Ui.dp(context, 9), Ui.dp(context, 12), Ui.dp(context, 9))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
            }
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) onInputTouched?.invoke()
                false
            }
        }
        inputRow.addView(input, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        inputRow.addView(
            Ui.pill(context, "MIC", false) { listener?.onMic() },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { leftMargin = Ui.dp(context, 6) }
        )
        inputRow.addView(
            Ui.pill(context, "Send", true) { submit() },
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { leftMargin = Ui.dp(context, 6) }
        )
        addView(inputRow, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(context, 8) })
    }

    fun attach(l: Listener) { listener = l }

    /** Overlay uses fewer message rows than the full-screen app. */
    fun setMessageLimit(limit: Int) { maxMessages = limit }

    fun setCompactMessages(compact: Boolean) {
        scroll.visibility = if (compact) View.GONE else View.VISIBLE
    }

    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        addMessage("user", text)
        input.setText("")
        hideKeyboard()
        listener?.onCommand(text)
    }

    fun focusInput() {
        input.requestFocus()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
    }

    /** Shows a brain/voice/response event. Must be called on the main thread. */
    fun show(type: String, message: String, state: String) {
        headline.text = PanelModel.headline(state)
        sub.text = state.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
        orb.orbState = PanelModel.orbFor(type, state)
        if (type == "voice" && message.isNotBlank()) sub.text = message
        if (type == "response" && message.isNotBlank()) addMessage("jarvis", message)
        val busy = PanelModel.isBusy(state)
        stopRow.visibility = if (busy) View.VISIBLE else View.GONE
        inputRow.visibility = if (busy) View.GONE else View.VISIBLE
        val waiting = state == "WAITING_FOR_APPROVAL"
        approvalRow.visibility = if (waiting) View.VISIBLE else View.GONE
        if (waiting) approvalText.text = message.ifBlank { "Jarvis ne ek action taiyaar kiya hai." }
        if (!busy && state != "RUNNING") clearTasksIfFinished(state)
    }

    fun showTasks(steps: List<BrainTaskRunner.StepView>) {
        taskBoard.removeAllViews()
        if (steps.isEmpty()) return
        val shown = steps.takeLast(6)
        shown.forEach { step ->
            val color = when (step.state) {
                "DONE" -> Ui.OK
                "FAILED" -> Ui.DANGER
                "RUNNING" -> Ui.WARN
                "WAITING" -> Ui.ACCENT
                else -> Ui.MUTED
            }
            val line = Ui.label(context, "${step.index}/${step.total}  ${step.title.ifBlank { "Kaam" }}  -  ${step.state}", 12f, color)
            taskBoard.addView(line)
        }
    }

    private fun clearTasksIfFinished(state: String) {
        if (state == "SUCCESS" || state == "CANCELLED") taskBoard.removeAllViews()
    }

    private fun addMessage(role: String, text: String) {
        if (text.isBlank()) return
        val isUser = role == "user"
        val bubble = TextView(context).apply {
            this.text = text
            textSize = 13f
            setTextColor(if (isUser) Ui.ACCENT_TEXT else Ui.TEXT)
            background = Ui.rounded(if (isUser) Ui.ACCENT else Ui.SURFACE2, Ui.dp(context, 14))
            setPadding(Ui.dp(context, 11), Ui.dp(context, 7), Ui.dp(context, 11), Ui.dp(context, 7))
        }
        val lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            gravity = if (isUser) Gravity.END else Gravity.START
            topMargin = Ui.dp(context, 5)
            if (isUser) leftMargin = Ui.dp(context, 40) else rightMargin = Ui.dp(context, 40)
        }
        messages.addView(bubble, lp)
        while (messages.childCount > maxMessages) messages.removeViewAt(0)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    fun setOrb(state: OrbState) { orb.orbState = state }

    /** Shows what the user said by voice (typed commands are added by submit()). */
    fun addUserMessage(text: String) = addMessage("user", text)

    /** The overlay has no spare height, so the message list gets a fixed height instead of weight. */
    fun setMessagesHeightPx(px: Int) {
        val lp = scroll.layoutParams as LayoutParams
        lp.height = px
        lp.weight = 0f
        scroll.layoutParams = lp
    }
}
