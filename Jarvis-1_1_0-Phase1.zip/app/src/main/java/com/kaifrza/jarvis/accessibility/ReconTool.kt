package com.kaifrza.jarvis.accessibility

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import com.kaifrza.jarvis.ui.MainActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Recon: reads (never taps anything except page swipes / back) the Quick Settings panel, the Bluetooth,
 * Wi-Fi and Sound settings pages and writes every node label/state to a text report. The report is used to
 * calibrate Jarvis for this exact phone (tile names, pages, which nodes expose on/off state).
 */
object ReconTool {
    @Volatile var running = false
        private set
    @Volatile var lastReport: String? = null
        private set
    @Volatile var lastPath: String? = null
        private set
    @Volatile var finishedNotice = false

    fun start(service: JarvisAccessibilityService, onDone: () -> Unit): Boolean {
        if (running) return false
        running = true
        finishedNotice = false
        Thread({
            val report = try {
                build(service)
            } catch (t: Throwable) {
                "Recon failed: ${t.message}"
            }
            lastReport = report
            lastPath = save(service.applicationContext, report)
            running = false
            finishedNotice = true
            runCatching {
                service.startActivity(
                    Intent(service, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            }
            onDone()
        }, "jarvis-recon").start()
        return true
    }

    private fun build(s: JarvisAccessibilityService): String {
        val out = StringBuilder()
        val dm = s.resources.displayMetrics
        out.append("JARVIS RECON ").append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).append('\n')
        out.append("device=").append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL)
            .append(" | android=").append(android.os.Build.VERSION.RELEASE).append(" (sdk ").append(android.os.Build.VERSION.SDK_INT).append(')')
            .append(" | screen=").append(dm.widthPixels).append('x').append(dm.heightPixels).append('\n')
        out.append("NOTE: this file contains on-screen text (device names, Wi-Fi names). Review before sharing.\n\n")

        // ---- Quick Settings: 3 pages
        s.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        SystemClock.sleep(1_100L)
        section(out, "QUICK_SETTINGS page 1 (after GLOBAL_ACTION_QUICK_SETTINGS)", dumpWindows(s))
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        for (page in 2..4) {
            s.swipeBy(w * 0.88f, h * 0.25f, w * 0.12f, h * 0.25f, 280L)
            SystemClock.sleep(800L)
            section(out, "QUICK_SETTINGS page $page (after swipe left)", dumpWindows(s))
        }
        // Swipe back to page 1 and close the panel.
        repeat(4) {
            s.swipeBy(w * 0.12f, h * 0.25f, w * 0.88f, h * 0.25f, 220L)
            SystemClock.sleep(350L)
        }
        s.performGlobalActionBack()
        SystemClock.sleep(500L)

        // ---- Settings pages
        settingsPage(s, out, "BLUETOOTH settings", Settings.ACTION_BLUETOOTH_SETTINGS, scrolls = 1)
        settingsPage(s, out, "WI-FI settings", Settings.ACTION_WIFI_SETTINGS, scrolls = 1)
        settingsPage(s, out, "SOUND settings", Settings.ACTION_SOUND_SETTINGS, scrolls = 1)

        out.append("\nEND OF RECON\n")
        return out.toString()
    }

    private fun settingsPage(s: JarvisAccessibilityService, out: StringBuilder, title: String, action: String, scrolls: Int) {
        runCatching { s.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { section(out, title, "could not open: ${it.message}"); return }
        SystemClock.sleep(1_900L)
        section(out, "$title (top)", dumpWindows(s))
        repeat(scrolls) { i ->
            if (s.scrollForward()) {
                SystemClock.sleep(700L)
                section(out, "$title (scrolled ${i + 1})", dumpWindows(s))
            }
        }
        s.performGlobalActionBack()
        SystemClock.sleep(450L)
        s.performGlobalActionBack()
        SystemClock.sleep(450L)
    }

    private fun section(out: StringBuilder, title: String, body: String) {
        out.append("=== ").append(title).append(" ===\n").append(body).append("\n\n")
    }

    /** Dumps every accessibility window (the Quick Settings panel can live in its own window). */
    private fun dumpWindows(s: JarvisAccessibilityService): String {
        val sb = StringBuilder()
        val windows = runCatching { s.windows }.getOrNull().orEmpty()
        if (windows.isEmpty()) {
            val root = s.rootInActiveWindow
            sb.append("[active window only]\n")
            if (root != null) dumpNode(root, 0, sb, Counter()) else sb.append("(no root)\n")
            return sb.toString()
        }
        windows.sortedBy { it.layer }.forEach { w ->
            val root = w.root ?: return@forEach
            sb.append("-- window type=").append(w.type).append(" layer=").append(w.layer)
                .append(" pkg=").append(root.packageName).append(" title=").append(w.title).append('\n')
            dumpNode(root, 0, sb, Counter())
        }
        return sb.toString()
    }

    private class Counter { var n = 0 }

    private fun dumpNode(node: AccessibilityNodeInfo, depth: Int, sb: StringBuilder, counter: Counter) {
        if (counter.n >= 450) return
        counter.n++
        val text = node.text?.toString()?.replace('\n', ' ')?.take(80)
        val desc = node.contentDescription?.toString()?.replace('\n', ' ')?.take(80)
        val interesting = !text.isNullOrBlank() || !desc.isNullOrBlank() || node.isClickable || node.isCheckable || node.isScrollable
        if (interesting && node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            sb.append("  ".repeat(depth.coerceAtMost(12)))
                .append(node.className?.toString()?.substringAfterLast('.') ?: "?")
            if (!text.isNullOrBlank()) sb.append(" text=\"").append(text).append('"')
            if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc).append('"')
            node.viewIdResourceName?.let { sb.append(" id=").append(it.substringAfterLast('/')) }
            val flags = buildList {
                if (node.isClickable) add("click")
                if (node.isCheckable) add(if (node.isChecked) "CHECKED" else "unchecked")
                if (node.isSelected) add("SELECTED")
                if (!node.isEnabled) add("disabled")
                if (node.isScrollable) add("scroll")
            }
            if (flags.isNotEmpty()) sb.append(" [").append(flags.joinToString(",")).append(']')
            sb.append(" @").append(r.left).append(',').append(r.top).append('-').append(r.right).append(',').append(r.bottom).append('\n')
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            dumpNode(child, depth + 1, sb, counter)
        }
    }

    private fun save(context: Context, report: String): String? = runCatching {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        val file = File(dir, "jarvis-recon.txt")
        file.writeText(report)
        file.absolutePath
    }.getOrNull()
}
