package com.kaifrza.jarvis.core.actions

import android.content.Context
import com.kaifrza.jarvis.core.model.IntentType

class ActionRegistry(
    private val context: Context,
    private val contacts: ContactResolver
) {
    fun resolve(intent: IntentType): JarvisAction? = when (intent) {
        IntentType.OPEN_APP -> OpenAppAction(context)
        IntentType.NAVIGATE_BACK,
        IntentType.HOME,
        IntentType.RECENTS,
        IntentType.OPEN_NOTIFICATIONS -> NavigationAction()
        IntentType.READ_NOTIFICATIONS -> NotificationAction(context)
        IntentType.ACCESS_SCREEN -> ScreenAction()
        IntentType.MAKE_CALL -> CallAction(context, contacts)
        IntentType.SEND_MESSAGE -> SmsAction(context, contacts)
        IntentType.UI_CLICK_TEXT -> AccessibilityAction()
        IntentType.UI_TYPE_TEXT, IntentType.UI_FOCUS_INPUT -> AccessibilityAction()
        IntentType.UI_SCROLL,
        IntentType.UI_SEARCH -> AccessibilityAction()
        IntentType.CALCULATE,
        IntentType.SET_VOLUME,
        IntentType.SET_BRIGHTNESS,
        IntentType.PLAY_MEDIA,
        IntentType.PAUSE_MEDIA,
        IntentType.STOP_MEDIA,
        IntentType.NEXT_MEDIA,
        IntentType.PREVIOUS_MEDIA,
        IntentType.CREATE_ALARM,
        IntentType.OPEN_NETWORK_SETTINGS,
        IntentType.OPEN_WIFI_SETTINGS,
        IntentType.OPEN_BLUETOOTH_SETTINGS,
        IntentType.SET_FLASHLIGHT,
        IntentType.TOGGLE_WIFI,
        IntentType.TOGGLE_MOBILE_DATA,
        IntentType.TOGGLE_BLUETOOTH -> UtilityAction(context)
        else -> null
    }
}
