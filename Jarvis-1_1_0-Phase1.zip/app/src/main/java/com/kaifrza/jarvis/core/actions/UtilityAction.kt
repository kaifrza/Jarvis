package com.kaifrza.jarvis.core.actions

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import kotlin.math.roundToInt

class UtilityAction(private val context: Context) : JarvisAction {
    override val id = "android.utility"

    override fun validate(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.CALCULATE -> if (plan.command.parameters["expression"].isNullOrBlank()) ActionResult.Failure("Mujhe calculation expression nahi mila.") else ActionResult.Success
        IntentType.SET_FLASHLIGHT -> if (Build.VERSION.SDK_INT >= 23) ActionResult.Success else ActionResult.Failure("Torch control is not available on this Android version.")
        IntentType.SET_VOLUME, IntentType.SET_BRIGHTNESS -> ActionResult.Success
        IntentType.PLAY_MEDIA, IntentType.PAUSE_MEDIA, IntentType.STOP_MEDIA, IntentType.NEXT_MEDIA, IntentType.PREVIOUS_MEDIA -> ActionResult.Success
        IntentType.CREATE_ALARM -> if (plan.command.parameters["hour"].isNullOrBlank()) ActionResult.Failure("Alarm ke liye time batao, e.g. 7:30 AM.") else ActionResult.Success
        IntentType.TOGGLE_WIFI, IntentType.TOGGLE_MOBILE_DATA, IntentType.TOGGLE_BLUETOOTH -> if (JarvisAccessibilityService.instance == null) ActionResult.Failure("Accessibility Service is required for system toggle control.") else ActionResult.Success
        else -> ActionResult.Success
    }

    override fun execute(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.OPEN_NETWORK_SETTINGS -> open(Settings.ACTION_WIRELESS_SETTINGS)
        IntentType.OPEN_WIFI_SETTINGS -> open(Settings.ACTION_WIFI_SETTINGS)
        IntentType.OPEN_BLUETOOTH_SETTINGS -> open(Settings.ACTION_BLUETOOTH_SETTINGS)
        IntentType.SET_FLASHLIGHT -> setTorch(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_WIFI -> toggleWifi(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_MOBILE_DATA -> toggleMobileData(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_BLUETOOTH -> toggleBluetooth(plan.command.parameters["enabled"] != "false")
        IntentType.SET_VOLUME -> setVolume(plan.command.parameters)
        IntentType.SET_BRIGHTNESS -> setBrightness(plan.command.parameters)
        IntentType.PLAY_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_PLAY)
        IntentType.PAUSE_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_PAUSE)
        IntentType.STOP_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_STOP)
        IntentType.NEXT_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_NEXT)
        IntentType.PREVIOUS_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        IntentType.CREATE_ALARM -> createAlarm(plan)
        IntentType.CALCULATE -> {
            val expression = plan.command.parameters["expression"].orEmpty()
            val result = SimpleCalculator.evaluate(expression)
            if (result == null) ActionResult.Failure("Main calculation ko samajh nahi paaya: $expression") else ActionResult.SuccessWithMessage("$expression = $result")
        }
        else -> ActionResult.Failure("Unsupported utility action.")
    }

    override fun verify(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.TOGGLE_WIFI -> verifyWifi(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_BLUETOOTH -> verifyBluetooth(plan.command.parameters["enabled"] != "false")
        else -> ActionResult.Success
    }

    // ---------------------------------------------------------------- volume / brightness

    /**
     * mode = set (absolute level), up/down (relative by delta), min, get (just report).
     * A bare "level" without a mode means "set".
     */
    private fun resolveLevel(p: Map<String, String>, current: Int, minLevel: Int): Int? {
        val level = p["level"]?.toIntOrNull()
        val mode = p["mode"] ?: if (level != null) "set" else "get"
        val delta = p["delta"]?.toIntOrNull() ?: 20
        return when (mode) {
            "set" -> level?.coerceIn(minLevel, 100)
            "up" -> (current + delta).coerceIn(minLevel, 100)
            "down" -> (current - delta).coerceIn(minLevel, 100)
            "min" -> minLevel
            else -> null
        }
    }

    private fun setVolume(p: Map<String, String>): ActionResult = runCatching {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val currentRaw = audio.getStreamVolume(stream)
        val currentPercent = (currentRaw * 100f / max).roundToInt()
        val target = resolveLevel(p, currentPercent, 0)
            ?: return ActionResult.SuccessWithMessage("Volume abhi $currentPercent% hai.")
        var value = (max * target / 100f).roundToInt().coerceIn(0, max)
        // Make sure "badhao"/"kam karo" always moves at least one step on devices with few steps.
        if (p["mode"] == "up" && value <= currentRaw && currentRaw < max) value = currentRaw + 1
        if (p["mode"] == "down" && value >= currentRaw && currentRaw > 0) value = currentRaw - 1
        audio.setStreamVolume(stream, value, AudioManager.FLAG_SHOW_UI)
        ActionResult.SuccessWithMessage("Volume ${(value * 100f / max).roundToInt()}% kar diya.")
    }.getOrElse { ActionResult.Failure("Volume control fail hua: ${it.message ?: "unknown"}") }

    private fun setBrightness(p: Map<String, String>): ActionResult {
        if (!Settings.System.canWrite(context)) {
            // UI-tap setup: open the "Modify system settings" page for Jarvis and flip the switch.
            runCatching {
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            val service = JarvisAccessibilityService.instance
            if (service != null) {
                SystemClock.sleep(1_000L)
                service.setFirstSwitch(true)
                service.performGlobalActionBack()
                SystemClock.sleep(350L)
            }
            if (!Settings.System.canWrite(context)) {
                return ActionResult.Failure("Brightness ke liye Jarvis ko 'Modify system settings' allow karo — settings page khol diya hai.")
            }
        }
        return runCatching {
            val cr = context.contentResolver
            val current255 = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
            val current = (current255 * 100f / 255f).roundToInt()
            val target = resolveLevel(p, current, 1)
                ?: return ActionResult.SuccessWithMessage("Brightness abhi $current% hai.")
            // Manual mode first, otherwise adaptive brightness overrides the value immediately.
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (255 * target / 100f).roundToInt().coerceIn(1, 255))
            ActionResult.SuccessWithMessage("Brightness $target% kar di.")
        }.getOrElse { ActionResult.Failure("Brightness control fail hua: ${it.message ?: "unknown"}") }
    }

    private fun media(keyCode: Int): ActionResult = runCatching {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Media control fail hua: ${it.message ?: "unknown"}") }

    // ---------------------------------------------------------------- alarm

    private fun createAlarm(plan: ActionPlan): ActionResult {
        val p = plan.command.parameters
        var hour = p["hour"]?.toIntOrNull() ?: return ActionResult.Failure("Alarm ke liye time batao, e.g. 7:30 AM.")
        val minute = (p["minute"]?.toIntOrNull() ?: 0).coerceIn(0, 59)
        val ampm = p["ampm"].orEmpty().lowercase()
        if (ampm == "pm" && hour < 12) hour += 12
        if (ampm == "am" && hour == 12) hour = 0
        hour = hour.coerceIn(0, 23)
        val label = String.format("%02d:%02d", hour, minute)

        fun alarmIntent(skipUi: Boolean) = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, skipUi)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(alarmIntent(true))
            ActionResult.SuccessWithMessage("Alarm $label ke liye set kar diya.")
        } catch (e1: Exception) {
            // Without SET_ALARM (or if the clock app refuses SKIP_UI) fall back to the clock app's own screen.
            try {
                context.startActivity(alarmIntent(false))
                ActionResult.SuccessWithMessage("Alarm $label ka setup khol diya.")
            } catch (e2: Exception) {
                ActionResult.Failure("Alarm app open nahi ho saki.")
            }
        }
    }

    // ---------------------------------------------------------------- connectivity (UI tap)

    private fun toggleWifi(enabled: Boolean): ActionResult {
        val manager = runCatching { context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager }.getOrNull()
        val current = runCatching { manager?.isWifiEnabled }.getOrNull()
        if (current != null && current == enabled) return ActionResult.Success
        return toggleViaQuickSettings(listOf("Wi-Fi", "WiFi", "WLAN"), enabled, "Wi-Fi")
    }

    private fun toggleMobileData(enabled: Boolean): ActionResult =
        toggleViaQuickSettings(listOf("Mobile data", "Mobile Data", "Cellular data", "Data", "Internet"), enabled, "Mobile-data/Internet")

    private fun toggleBluetooth(enabled: Boolean): ActionResult {
        val adapter = runCatching { BluetoothAdapter.getDefaultAdapter() }.getOrNull()
        val current = runCatching { adapter?.isEnabled }.getOrNull()
        if (current != null && current == enabled) return ActionResult.Success
        return toggleViaQuickSettings(listOf("Bluetooth"), enabled, "Bluetooth")
    }

    private fun toggleViaQuickSettings(labels: List<String>, enabled: Boolean, name: String): ActionResult {
        val service = JarvisAccessibilityService.instance ?: return ActionResult.Failure("Accessibility Service is unavailable.")
        val ok = service.openQuickSettingsAndToggle(labels, enabled)
        service.closeQuickSettings()
        return if (ok) ActionResult.Success else ActionResult.Failure("$name toggle control could not be located on this device.")
    }

    private fun verifyWifi(enabled: Boolean): ActionResult {
        val manager = runCatching { context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager }.getOrNull()
            ?: return ActionResult.Success
        if (runCatching { manager.isWifiEnabled }.isFailure) return ActionResult.Success
        val deadline = SystemClock.uptimeMillis() + 2_500L
        while (SystemClock.uptimeMillis() < deadline) {
            if (runCatching { manager.isWifiEnabled }.getOrNull() == enabled) return ActionResult.Success
            SystemClock.sleep(120)
        }
        return ActionResult.Failure("Wi-Fi state could not be verified.")
    }

    private fun verifyBluetooth(enabled: Boolean): ActionResult {
        val adapter = runCatching { BluetoothAdapter.getDefaultAdapter() }.getOrNull() ?: return ActionResult.Success
        if (runCatching { adapter.isEnabled }.isFailure) return ActionResult.Success
        val deadline = SystemClock.uptimeMillis() + 2_500L
        while (SystemClock.uptimeMillis() < deadline) {
            if (runCatching { adapter.isEnabled }.getOrNull() == enabled) return ActionResult.Success
            SystemClock.sleep(120)
        }
        return ActionResult.Failure("Bluetooth state could not be verified.")
    }

    private fun open(action: String): ActionResult = runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Settings open nahi ho sakin.") }

    private fun setTorch(enabled: Boolean): ActionResult = runCatching {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return ActionResult.Failure("Torch camera nahi mila.")
        manager.setTorchMode(cameraId, enabled)
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Torch control fail hua: ${it.message ?: "unknown"}") }
}

internal object SimpleCalculator {
    fun evaluate(raw: String): String? {
        val s = raw.replace(" ", "")
        val m = Regex("^(-?\\d+(?:\\.\\d+)?)([+\\-*/])(-?\\d+(?:\\.\\d+)?)$").matchEntire(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val v = when (m.groupValues[2]) { "+" -> a + b; "-" -> a - b; "*" -> a * b; "/" -> if (b == 0.0) return null else a / b; else -> return null }
        return if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
    }
}
