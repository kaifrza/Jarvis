package com.kaifrza.jarvis.core.security

import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.model.RiskLevel
import com.kaifrza.jarvis.core.tools.ToolRegistry

/** Policy boundary. The model cannot lower the risk declared by a registered tool. */
class RiskEngine(private val tools: ToolRegistry) {
    fun plan(command: JarvisCommand): ActionPlan {
        val descriptor = tools.find(command.intent)
        val risk = descriptor?.risk ?: when (command.intent) {
            IntentType.UNKNOWN -> RiskLevel.CRITICAL
            else -> RiskLevel.HIGH
        }
        return ActionPlan(
            command = command,
            risk = risk,
            requiresConfirmation = descriptor?.requiresConfirmation ?: true
        )
    }
}
