package com.kaifrza.jarvis.core.tools

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.RiskLevel

/** Single source of truth for the capabilities Jarvis may expose to a brain. */
class ToolRegistry {
    private val tools = listOf(
        ToolDescriptor("android_open_app", "Open an installed application by name or alias.", IntentType.OPEN_APP, RiskLevel.LOW, false,
            listOf(ToolParameter("app_name", "Application name", true))),
        ToolDescriptor("android_back", "Navigate back in the foreground application.", IntentType.NAVIGATE_BACK, RiskLevel.LOW, false),
        ToolDescriptor("android_home", "Go to the Android home screen.", IntentType.HOME, RiskLevel.LOW, false),
        ToolDescriptor("android_recents", "Open Android recent apps.", IntentType.RECENTS, RiskLevel.LOW, false),
        ToolDescriptor("android_notifications", "Open the Android notification shade.", IntentType.OPEN_NOTIFICATIONS, RiskLevel.LOW, false),
        ToolDescriptor("communication_call", "Place a phone call after explicit user approval.", IntentType.MAKE_CALL, RiskLevel.HIGH, true,
            listOf(ToolParameter("contact_name", "Contact name", false), ToolParameter("phone_number", "Phone number", false))),
        ToolDescriptor("communication_send_message", "Send an SMS after explicit user approval.", IntentType.SEND_MESSAGE, RiskLevel.HIGH, true,
            listOf(ToolParameter("contact_name", "Contact name", false), ToolParameter("phone_number", "Phone number", false), ToolParameter("message", "Message body", true)))
    )

    private val byId = tools.associateBy { it.id }
    private val byIntent = tools.associateBy { it.intent }

    fun all(): List<ToolDescriptor> = tools
    fun find(id: String): ToolDescriptor? = byId[id]
    fun find(intent: IntentType): ToolDescriptor? = byIntent[intent]

    fun validate(call: ToolCall): ToolValidation {
        val descriptor = find(call.toolId)
            ?: return ToolValidation(false, "Unknown tool: ${call.toolId}")
        val missing = descriptor.parameters.filter { it.required && call.arguments[it.name].isNullOrBlank() }
        if (missing.isNotEmpty()) return ToolValidation(false, "Missing required parameter(s): ${missing.joinToString { it.name }}")
        if (call.toolId == "communication_call" &&
            call.arguments["contact_name"].isNullOrBlank() && call.arguments["phone_number"].isNullOrBlank()) {
            return ToolValidation(false, "A call needs either contact_name or phone_number.")
        }
        if (call.toolId == "communication_send_message" &&
            call.arguments["contact_name"].isNullOrBlank() && call.arguments["phone_number"].isNullOrBlank()) {
            return ToolValidation(false, "A message needs either contact_name or phone_number.")
        }
        return ToolValidation(true)
    }

    /** OpenAI-compatible function schema. Providers that support tools can consume this directly. */
    fun openAiToolsJson(): org.json.JSONArray = org.json.JSONArray().apply {
        tools.forEach { tool ->
            val properties = org.json.JSONObject()
            val required = org.json.JSONArray()
            tool.parameters.forEach { parameter ->
                properties.put(parameter.name, org.json.JSONObject().put("type", "string").put("description", parameter.description))
                if (parameter.required) required.put(parameter.name)
            }
            put(org.json.JSONObject()
                .put("type", "function")
                .put("function", org.json.JSONObject()
                    .put("name", tool.id)
                    .put("description", tool.description)
                    .put("parameters", org.json.JSONObject()
                        .put("type", "object")
                        .put("properties", properties)
                        .put("required", required)
                        .put("additionalProperties", false))))
        }
    }

    /** Compact schema text for provider prompts; intentionally provider-neutral. */
    fun promptSchema(): String = buildString {
        appendLine("Available tools:")
        tools.forEach { tool ->
            append("- ").append(tool.id).append(": ").append(tool.description)
            if (tool.parameters.isNotEmpty()) {
                append(" params=")
                append(tool.parameters.joinToString(",") { "${it.name}${if (it.required) "*" else ""}" })
            }
            appendLine()
        }
        appendLine("Return only JSON: {\"reply\":string,\"steps\":[{\"tool\":string,\"arguments\":{string:string},\"rationale\":string?}]}")
    }
}
