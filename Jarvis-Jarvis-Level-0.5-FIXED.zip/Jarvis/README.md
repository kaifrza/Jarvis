# Jarvis Android Assistant — 0.5

Personal-use Android assistant foundation for Android 10+.

## 0.5: Brain + Interface architecture

- Premium local HTML/CSS/JS face hosted by a hardened WebViewAssetLoader.
- Native Android remains the capability/action layer.
- Modern WebMessageListener bridge with a local-content fallback.
- Normal Activity input window fixes the keyboard/focus problem caused by putting an EditText inside an accessibility overlay.
- Accessibility service is now a lightweight global Jarvis bubble; tapping it opens the full assistant surface.
- Hybrid command brain: fast deterministic local parser for simple commands, remote OpenAI-compatible brain for complex/unknown/compound commands.
- Remote brain outputs a strict structured plan; it never receives Android Context, permissions, or executor access.
- Multi-step plan runner executes ordered actions and pauses safely for contact choice or explicit approval.
- API key is encrypted with Android Keystore. Endpoint/model remain user-configurable.
- Current remote brain supports the action vocabulary already implemented by the executor; unsupported actions are rejected rather than guessed.
- Full system VoiceInteractionService classes are kept isolated for a later milestone; Android 10 requires a valid recognition-service integration for a true default assistant, so 0.5 does not pretend that capability is complete.

## Brain setup

Open Jarvis settings and configure a trusted OpenAI-compatible chat endpoint, model, and API key. Example endpoint shape: `/v1/chat/completions`. Do not put API keys into source code or GitHub.

Without remote configuration, Jarvis stays fully usable with the local command engine.

## Example commands

- `YouTube kholo`
- `Zubair ko call karo`
- `9876543210 par call karo`
- `Zubair ko message bhejo: Main 10 minute mein aa raha hoon`
- `WhatsApp kholo aur phir back jao` (remote brain configured)
- `Zubair ko call karo, agar multiple numbers hain to 12 se start wala use karo` (brain can plan, executor still confirms/chooses)

## Architecture

`Voice/Text -> Brain -> Structured Plan -> Risk -> Approval/Choice -> Action Executor -> Verification -> Response`

The brain is intentionally not allowed to call Android APIs.
