package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Pure parser for the brain's strict JSON contract. No Android dependencies. */
object BrainJsonParser {
    fun parsePlan(content: String): BrainPlan {
        val json = extractJson(content)
        val stepsJson = json.optJSONArray("steps") ?: JSONArray()
        val steps = buildList {
            for (i in 0 until stepsJson.length()) {
                val item = stepsJson.optJSONObject(i) ?: continue
                val intent = runCatching { IntentType.valueOf(item.optString("intent").uppercase()) }.getOrNull() ?: continue
                val params = mutableMapOf<String, String>()
                item.optJSONObject("parameters")?.let { obj ->
                    obj.keys().forEach { key -> params[key] = obj.optString(key) }
                }
                add(BrainStep(
                    JarvisCommand(
                        UUID.randomUUID().toString(),
                        item.optString("rawText", intent.name),
                        intent,
                        params
                    ),
                    item.optString("rationale").ifBlank { null }
                ))
            }
        }
        return BrainPlan(reply = json.optString("reply").ifBlank { null }, steps = steps, source = "remote")
    }

    private fun extractJson(text: String): JSONObject {
        val cleaned = text.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        require(start >= 0 && end > start) { "Brain did not return JSON." }
        return JSONObject(cleaned.substring(start, end + 1))
    }
}
