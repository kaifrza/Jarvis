package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.intent.CommandUnderstandingEngine
import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.IntentType
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

interface BrainEngine {
    fun plan(rawText: String, context: String = ""): BrainPlan
}

class HybridBrainEngine(
    private val local: CommandUnderstandingEngine,
    private val remote: RemoteBrainEngine
) : BrainEngine {
    override fun plan(rawText: String, context: String): BrainPlan {
        val localCommand = local.understand(rawText)
        val complex = isComplex(rawText)
        if (!complex && localCommand.intent != IntentType.UNKNOWN) {
            return BrainPlan(steps = listOf(BrainStep(localCommand)), source = "local")
        }
        return runCatching { remote.plan(rawText, context) }
            .getOrElse { BrainPlan(steps = if (localCommand.intent == IntentType.UNKNOWN) emptyList() else listOf(BrainStep(localCommand)), source = "local-fallback") }
    }

    private fun isComplex(text: String): Boolean {
        val n = text.lowercase()
        val markers = listOf(" and ", " aur ", " phir ", " then ", " after that ", " uske baad ", " if ", " agar ", " otherwise ", " warna ")
        return markers.any(n::contains)
    }
}

class RemoteBrainEngine(private val store: BrainStore) : BrainEngine {
    override fun plan(rawText: String, context: String): BrainPlan {
        val cfg = store.read()
        require(cfg.enabled && cfg.endpoint.isNotBlank() && cfg.model.isNotBlank() && cfg.apiKey.isNotBlank()) { "Brain is not configured yet." }

        val payload = JSONObject()
            .put("model", cfg.model)
            .put("temperature", 0.1)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", systemPrompt()))
                .put(JSONObject().put("role", "user").put("content", "Context: $context\n\nCommand: $rawText")))

        val connection = (URL(cfg.endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer ${cfg.apiKey}")
        }
        return try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
            if (connection.responseCode !in 200..299) error("Brain HTTP ${connection.responseCode}")
            parseResponse(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseResponse(body: String): BrainPlan {
        val outer = JSONObject(body)
        val content = outer.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
            ?: outer.optString("output_text", "")
        require(content.isNotBlank()) { "Brain returned no content." }
        return BrainJsonParser.parsePlan(content)
    }

    private fun systemPrompt(): String = """
You are Jarvis's command-planning brain. Return ONLY valid JSON.
Schema: {\"reply\":string,\"steps\":[{\"intent\":string,\"parameters\":object,\"rawText\":string,\"rationale\":string}]}
Allowed intents: OPEN_APP, NAVIGATE_BACK, HOME, RECENTS, OPEN_NOTIFICATIONS, MAKE_CALL, SEND_MESSAGE.
Never invent an action outside this list. For calls use phone_number or contact_name. For messages use contact_name or phone_number plus message.
Break compound requests into ordered steps. Preserve user intent exactly. Do not execute anything.
""".trimIndent()
}
