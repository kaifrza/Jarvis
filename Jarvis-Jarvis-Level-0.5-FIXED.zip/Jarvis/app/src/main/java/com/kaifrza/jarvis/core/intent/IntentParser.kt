package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import java.util.Locale
import java.util.UUID

/** Offline-first natural command parser. The execution layer only receives structured commands. */
class IntentParser {

    fun parse(raw: String): JarvisCommand {
        val text = raw.trim().replace(Regex("\\s+"), " ")
        val n = normalize(text)

        val intent = when {
            isCancel(n) -> IntentType.UNKNOWN
            isBack(n) -> IntentType.NAVIGATE_BACK
            isHome(n) -> IntentType.HOME
            isRecents(n) -> IntentType.RECENTS
            isNotifications(n) -> IntentType.OPEN_NOTIFICATIONS
            looksLikeMessage(n) -> IntentType.SEND_MESSAGE
            looksLikeCall(n) -> IntentType.MAKE_CALL
            looksLikeOpenApp(n) -> IntentType.OPEN_APP
            else -> IntentType.UNKNOWN
        }

        val params = when (intent) {
            IntentType.OPEN_APP -> extractAppName(n)?.let { mapOf("app_name" to it) } ?: emptyMap()
            IntentType.MAKE_CALL -> extractCallParams(text, n)
            IntentType.SEND_MESSAGE -> {
                val target = extractMessageTarget(n)
                val body = extractMessageBody(text)
                buildMap {
                    if (target != null) put("contact_name", target)
                    target?.let { extractPhoneNumber(it)?.let { number -> put("phone_number", number) } }
                    if (body != null) put("message", body)
                }
            }
            else -> emptyMap()
        }

        return JarvisCommand(
            id = UUID.randomUUID().toString(),
            rawText = text,
            intent = intent,
            parameters = params
        )
    }

    private fun normalize(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace('’', '\'')
        .replace('“', '"')
        .replace('”', '"')
        .replace(Regex("[!?]+$"), "")
        .trim()

    private fun isCancel(n: String): Boolean = n in setOf(
        "cancel", "cancel karo", "cancel kar do", "rehne do", "chhodo", "stop", "stop karo"
    )

    private fun isBack(n: String): Boolean =
        n in setOf("back", "go back", "back jao", "peeche jao", "piche jao", "wapas jao", "wapis jao") ||
            n.contains("previous page") || n.contains("pichle page") || n.contains("pichhle page")

    private fun isHome(n: String): Boolean =
        n in setOf("home", "home jao", "home kholo", "home screen", "home screen kholo") ||
            n.contains("home screen par") || n.contains("ghar screen")

    private fun isRecents(n: String): Boolean =
        n.contains("recent apps") || n.contains("recent app") || n == "recents" ||
            n.contains("recent kholo") || n.contains("recent dikhao")

    private fun isNotifications(n: String): Boolean =
        n.contains("notification kholo") || n.contains("notifications kholo") ||
            n.contains("notification dikhao") || n.contains("notifications dikhao") ||
            n.contains("notification panel") || n.contains("notification shade")

    private fun looksLikeMessage(n: String): Boolean {
        val words = listOf("message", "msg", "sms", "text message", "text karo", "text bhejo")
        return words.any(n::contains) && !n.startsWith("open message")
    }

    private fun looksLikeCall(n: String): Boolean {
        val words = listOf(
            "call ", "call karo", "call kar", "phone karo", "phone kar", "phone lagao",
            "phone lagana", "dial ", "dial karo", "ring karo", "number pe call", "number par call"
        )
        return words.any(n::contains) || n.startsWith("call") || n.startsWith("dial") ||
            (extractPhoneNumber(n) != null && (n.contains("phone") || n.contains("call") || n.contains("dial")))
    }

    private fun looksLikeOpenApp(n: String): Boolean {
        val verbs = listOf("open ", "open karo", "kholo", "khol do", "kholna", "chalao", "launch ", "launch karo", "start ", "start karo", "run ", "run karo")
        return verbs.any(n::contains) || knownAppAlias(n)?.let { alias -> n == alias || n == alias.replace("youtube", "yt") } == true
    }

    private fun extractAppName(n: String): String? {
        knownAppAlias(n)?.let { return it }
        var value = n
        listOf("open ", "launch ", "start ", "run ", "open karo ", "launch karo ", "start karo ", "run karo ", "khol do ", "kholna ", "kholo ", "chalao ").forEach {
            value = value.removePrefix(it)
        }
        value = value.replace(Regex("\\b(please|zara|plz|app|application|ko|karo|kar do)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return value.ifBlank { null }
    }

    private fun knownAppAlias(n: String): String? {
        val aliases = linkedMapOf(
            "youtube" to listOf("youtube", "you tube", "yt"),
            "whatsapp" to listOf("whatsapp", "what's app", "whats app", "whatsap"),
            "instagram" to listOf("instagram", "insta"),
            "chrome" to listOf("chrome", "google chrome"),
            "calculator" to listOf("calculator", "calc", "calcu")
        )
        return aliases.entries.firstOrNull { (_, words) -> words.any(n::contains) }?.key
    }

    private fun extractCallParams(text: String, n: String): Map<String, String> {
        val number = extractPhoneNumber(text)
        if (number != null) return mapOf("phone_number" to number)
        return extractCallTarget(n)?.let { mapOf("contact_name" to it) } ?: emptyMap()
    }

    /** Accepts India-style and international digit strings with spaces, +, -, or parentheses. */
    private fun extractPhoneNumber(value: String): String? {
        val candidates = Regex("(?<!\\d)(?:\\+?\\d[\\d\\s().-]{6,18}\\d)(?!\\d)")
            .findAll(value)
            .map { it.value.filter(Char::isDigit) }
            .filter { it.length in 7..15 }
            .toList()
        return candidates.firstOrNull()
    }

    private fun extractCallTarget(n: String): String? {
        var value = n
        listOf("^please ", "^zara ", "^mujhe ", "^mere liye ", "^can you ", "^please call ", "^please phone ").forEach {
            value = value.replace(Regex(it), "")
        }
        value = value.replace(Regex("^call\\s+"), "")
            .replace(Regex("^dial\\s+"), "")
            .replace(Regex("^phone\\s+"), "")
            .replace(Regex("^ring\\s+"), "")
            .replace(Regex("\\b(ko|k[o0]|please|zara|se|par|pe)\\b"), " ")
            .replace(Regex("\\b(call|phone|lagao|lagana|karo|karna|kar do|dial|ring)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return value.ifBlank { null }
    }

    private fun extractMessageTarget(n: String): String? {
        Regex("\\bto\\s+(.+?)\\s+\\b(?:saying|that)\\b").find(n)?.groupValues?.getOrNull(1)?.let {
            cleanContactTarget(it)?.let { target -> return target }
        }
        val marker = Regex("\\b(?:message|msg|sms|text)\\b").find(n)
        if (marker != null) {
            val afterMarker = n.substring(marker.range.last + 1).trim()
            val targetPart = afterMarker.substringBefore(":").substringBefore(" saying ").substringBefore(" that ").trim()
            if (targetPart.isNotBlank() && !targetPart.contains(" ")) cleanContactTarget(targetPart)?.let { return it }
        }
        val before = marker?.let { n.substring(0, it.range.first) } ?: n
        val beforeTrimmed = before.trim()
        if (beforeTrimmed.endsWith(" ko")) return cleanContactTarget(beforeTrimmed.removeSuffix(" ko"))
        Regex("(?i)^(.+?)\\s+ko$").find(beforeTrimmed)?.groupValues?.getOrNull(1)?.let { return cleanContactTarget(it) }
        Regex("(?i)\\bto\\s+(.+)$").find(before)?.groupValues?.getOrNull(1)?.let { cleanContactTarget(it)?.let { target -> return target } }
        return null
    }

    private fun cleanContactTarget(value: String): String? {
        val cleaned = value.replace(Regex("\\b(please|zara|mujhe|mere liye|to|ko|ke liye|par|pe|bhejo|send|do|karo|kar do|message|msg|sms|text)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return cleaned.ifBlank { null }
    }

    private fun extractMessageBody(text: String): String? {
        val colon = text.indexOf(':')
        if (colon >= 0) {
            val prefix = text.substring(0, colon).lowercase(Locale.ROOT)
            if (listOf("message", "msg", "sms", "text", "bhejo").any(prefix::contains)) return text.substring(colon + 1).trim().ifBlank { null }
        }
        Regex("(?i)\\b(?:message|msg|sms|text)\\s*:\\s*").find(text)?.let { return text.substring(it.range.last + 1).trim().ifBlank { null } }
        Regex("(?i)\\bbhejo\\s*:\\s*").find(text)?.let { return text.substring(it.range.last + 1).trim().ifBlank { null } }
        Regex("(?i)\\bsaying\\s+(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().ifBlank { null } }
        Regex("(?i)\\bbhejo\\b\\s*(.*)$").find(text)?.groupValues?.getOrNull(1)?.let { val body = it.removePrefix(":").trim(); if (body.isNotBlank()) return body }
        Regex("(?i)\\bko\\s+(?:message|msg|sms|text)\\s+(?:karo|kar do|bhejo)\\s*:??\\s*(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().removePrefix(":").trim().ifBlank { null } }
        return null
    }
}
