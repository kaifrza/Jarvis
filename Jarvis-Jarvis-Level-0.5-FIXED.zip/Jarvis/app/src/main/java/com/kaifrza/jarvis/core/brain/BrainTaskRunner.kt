package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.assistant.CommandProcessor
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.JarvisCommand

class BrainTaskRunner(
    private val brain: BrainEngine,
    private val processor: CommandProcessor
) {
    private val remaining = ArrayDeque<JarvisCommand>()

    fun handle(rawText: String, context: String = ""): CommandResponse {
        val text = rawText.trim()
        if (processor.hasPendingApproval() || processor.hasPendingChoice()) {
            val response = processor.handle(text)
            return continueIfReady(response)
        }
        val plan = brain.plan(text, context)
        if (plan.steps.isEmpty()) {
            return CommandResponse(CommandState.FAILED, plan.reply ?: "Sir, mujhe abhi is command ko confidently map karna nahi aaya.")
        }
        remaining.clear()
        remaining.addAll(plan.steps.map { it.command })
        val response = runNext()
        return if (!plan.reply.isNullOrBlank() && response.state == CommandState.SUCCESS) response.copy(message = plan.reply) else response
    }

    fun approve(): CommandResponse = continueIfReady(processor.approve())
    fun cancel(): CommandResponse { remaining.clear(); return processor.cancel() }

    private fun runNext(): CommandResponse {
        while (remaining.isNotEmpty()) {
            val command = remaining.removeFirst()
            val response = processor.handleCommand(command)
            if (response.state == CommandState.WAITING_FOR_APPROVAL || response.state == CommandState.WAITING_FOR_CHOICE || response.state == CommandState.FAILED) return response
        }
        return CommandResponse(CommandState.SUCCESS, "Done, sir.")
    }

    private fun continueIfReady(response: CommandResponse): CommandResponse {
        if (response.state == CommandState.WAITING_FOR_APPROVAL || response.state == CommandState.WAITING_FOR_CHOICE || response.state == CommandState.FAILED) return response
        return if (remaining.isEmpty()) response else runNext()
    }
}
