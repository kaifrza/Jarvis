package com.kaifrza.jarvis.voice

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.webkit.WebView
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.ui.JarvisWebViewHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class JarvisVoiceInteractionSession(private val sessionContext: VoiceInteractionSessionService) : VoiceInteractionSession(sessionContext) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var webView: WebView
    private lateinit var host: JarvisWebViewHost
    private lateinit var speaker: JarvisSpeaker

    private val container get() = (sessionContext.application as JarvisApplication).container

    override fun onCreateContentView(): android.view.View {
        webView = WebView(sessionContext)
        host = JarvisWebViewHost(webView)
        speaker = JarvisSpeaker(sessionContext)
        host.attach(object : JarvisWebViewHost.Listener {
            override fun onCommand(text: String) = process(text)
            override fun onMic() = startMic()
            override fun onApprove() = processResult(container.brainTaskRunner.approve())
            override fun onCancel() = processResult(container.brainTaskRunner.cancel())
            override fun onOpenSettings() = openMainForSettings()
        })
        return webView
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        host.send("status", "Ready, sir.", "READY", setupReady(), brainReady())
        webView.post { webView.requestFocus() }
    }

    private fun process(text: String) {
        if (text.isBlank()) return
        host.send("thinking", "Thinking…", "THINKING", setupReady(), brainReady())
        scope.launch {
            val context = "voice-session=true"
            val result = runCatching { container.brainTaskRunner.handle(text, context) }
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown error"}") }
            withContext(Dispatchers.Main) { processResult(result) }
        }
    }

    private fun processResult(result: CommandResponse) {
        host.send("response", result.message, result.state.name, setupReady(), brainReady())
        if (result.state == CommandState.SUCCESS) speaker.speak(result.message)
    }

    private fun startMic() {
        if (ContextCompat.checkSelfPermission(sessionContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            host.send("response", "Mic permission ko pehle Jarvis app mein allow karo, sir.", "SETUP", setupReady(), brainReady())
            return
        }
        JarvisVoiceController(sessionContext, object : JarvisVoiceController.Listener {
            override fun onReady() = host.send("voice", "Listening…", "LISTENING", setupReady(), brainReady())
            override fun onListening() = host.send("voice", "I'm listening…", "LISTENING", setupReady(), brainReady())
            override fun onPartial(text: String) = host.send("voice", text, "LISTENING", setupReady(), brainReady())
            override fun onResult(text: String) = process(text)
            override fun onError(message: String) = host.send("voice", message, "FAILED", setupReady(), brainReady())
        }.also { it.start() })
    }

    private fun openMainForSettings() {
        val intent = android.content.Intent(sessionContext, com.kaifrza.jarvis.ui.MainActivity::class.java)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        sessionContext.startActivity(intent)
    }

    private fun setupReady(): Boolean = true

    private fun brainReady(): Boolean {
        val c = container.brainStore.read()
        return c.enabled && c.endpoint.isNotBlank() && c.model.isNotBlank() && c.apiKey.isNotBlank()
    }

    override fun onDestroy() {
        scope.cancel()
        if (::speaker.isInitialized) speaker.shutdown()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
