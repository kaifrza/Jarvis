package com.kaifrza.jarvis.core.model

import java.util.UUID

data class BrainStep(
    val command: JarvisCommand,
    val rationale: String? = null
)

data class BrainPlan(
    val id: String = UUID.randomUUID().toString(),
    val reply: String? = null,
    val steps: List<BrainStep> = emptyList(),
    val source: String = "local"
)
