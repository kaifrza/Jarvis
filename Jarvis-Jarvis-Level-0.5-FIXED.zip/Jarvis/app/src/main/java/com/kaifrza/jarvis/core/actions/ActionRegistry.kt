package com.kaifrza.jarvis.core.actions

import android.content.Context
import com.kaifrza.jarvis.core.model.IntentType

class ActionRegistry(
    private val context: Context,
    private val contacts: ContactResolver
) {
    fun resolve(intent: IntentType): JarvisAction? = when (intent) {
        IntentType.OPEN_APP -> OpenAppAction(context)
        IntentType.NAVIGATE_BACK,
        IntentType.HOME,
        IntentType.RECENTS,
        IntentType.OPEN_NOTIFICATIONS -> NavigationAction()
        IntentType.MAKE_CALL -> CallAction(context, contacts)
        IntentType.SEND_MESSAGE -> SmsAction(context, contacts)
        else -> null
    }
}
