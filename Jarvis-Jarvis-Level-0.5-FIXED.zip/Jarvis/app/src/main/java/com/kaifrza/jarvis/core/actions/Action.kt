package com.kaifrza.jarvis.core.actions

import com.kaifrza.jarvis.core.model.ActionPlan

sealed interface ActionResult {
    data object Success : ActionResult
    data class Failure(val reason: String) : ActionResult
    data object RequiresApproval : ActionResult
}

interface JarvisAction {
    val id: String

    fun validate(plan: ActionPlan): ActionResult

    fun execute(plan: ActionPlan): ActionResult

    fun verify(plan: ActionPlan): ActionResult
}
