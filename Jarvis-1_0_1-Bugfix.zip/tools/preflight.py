from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "app/src/main/java"
JAVA_ROOT = JAVA / "com/kaifrza/jarvis"
RES = ROOT / "app/src/main/res"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"

errors = []

# Known compile traps caught by previous CI failures.
for p in JAVA.rglob("*.kt"):
    text = p.read_text(encoding="utf-8")
    if "ACTION_IME_ENTER" in text:
        errors.append(f"Forbidden/non-portable ACTION_IME_ENTER reference: {p}")

# More compile/runtime traps found in the 1.0.1 audit.
for p in JAVA.rglob("*.kt"):
    text = p.read_text(encoding="utf-8")
    if "AudioManager.KEYCODE_" in text:
        errors.append(f"AudioManager has no KEYCODE_* constants, use android.view.KeyEvent: {p}")
    if re.search(r"EXTRA_LANGUAGE,\s*Locale\.getDefault\(\)\s*\)", text):
        errors.append(f"EXTRA_LANGUAGE needs a language tag String, not a Locale: {p}")
    if re.search(r"\.copy\(parameters\s*=", text) and "resolved_display_name" in text and "HistoryLabel" not in text and "ActionHistory" in text:
        pass

gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
main_text = " ".join(p.read_text(encoding="utf-8") for p in JAVA.rglob("*.kt"))
if "import kotlinx.coroutines" in main_text and "kotlinx-coroutines" not in gradle:
    errors.append("kotlinx.coroutines is imported but not declared in app/build.gradle.kts")
TEST = ROOT / "app/src/test"
test_text = " ".join(p.read_text(encoding="utf-8") for p in TEST.rglob("*.kt")) if TEST.exists() else ""
if ("org.json" in test_text or "BrainJsonParser" in test_text) and "org.json:json" not in gradle:
    errors.append("unit tests use org.json but app/build.gradle.kts has no testImplementation(org.json:json)")

# Parse every XML resource and manifest.
for p in RES.rglob("*.xml"):
    try:
        ET.parse(p)
    except Exception as e:
        errors.append(f"Invalid XML {p}: {e}")
try:
    ET.parse(MANIFEST)
except Exception as e:
    errors.append(f"Invalid manifest: {e}")

# Verify every manifest component resolves to a source class.
manifest = MANIFEST.read_text(encoding="utf-8")
for name in re.findall(r'android:name="\.([^\"]+)"', manifest):
    path = JAVA_ROOT / (name.replace('.', '/') + ".kt")
    if not path.exists():
        errors.append(f"Manifest component source missing: {name}")

# Verify Android resource references in Kotlin exist.
resources = set()
for p in RES.rglob("*"):
    if p.is_file():
        rel = p.relative_to(RES).parts
        if len(rel) >= 2:
            resources.add((rel[0].split('-')[0], p.stem))
for p in JAVA.rglob("*.kt"):
    text = p.read_text(encoding="utf-8")
    for typ, name in re.findall(r"R\.(\w+)\.(\w+)", text):
        if (typ, name) not in resources:
            errors.append(f"Missing resource R.{typ}.{name}: {p}")

# Ensure all source files use the current package root.
for p in JAVA.rglob("*.kt"):
    text = p.read_text(encoding="utf-8")
    if "package com.kaifrza.jarvis" not in text:
        errors.append(f"Unexpected package declaration: {p}")

if errors:
    print("PREFLIGHT FAILED")
    for error in errors:
        print(" -", error)
    raise SystemExit(1)

print("PREFLIGHT PASS")
