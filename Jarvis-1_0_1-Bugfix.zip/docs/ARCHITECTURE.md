# Jarvis 1.0.1 Architecture

```text
Voice / Text
     |
     v
HTML/CSS/JS UI --(local WebView bridge)--> Android host (MainActivity / overlay / voice session)
     |
     v
HybridBrainEngine
  1. OfflineAgentBrain (deterministic, always first)   -> trusted plan
  2. Local IntentParser                                 -> trusted command
  3. RemoteBrainEngine (optional OpenAI-compatible)     -> UNTRUSTED plan
     |
     v
BrainTaskRunner  (task lanes, run one after another)
     |
     v
CommandProcessor -> RiskEngine -> (approval / contact choice) -> ActionExecutor
     |
     v
Action (UI-tap via Accessibility, intents, system services) -> verify -> response
```

## Execution policy (tiered)
- Commands typed/spoken by the user run directly (Android permission grants are the gate).
- Plans produced by a remote model are untrusted: HIGH-risk tools (call, SMS) and sensitive UI
  clicks (Send, Pay, Delete, Buy, Confirm ...) need explicit approval.

## Lanes
Android has one foreground window, so lanes run sequentially and each lane runs to completion.
A failed lane skips only its own remaining steps; other lanes still run.

## UI-tap principle
System toggles (Wi-Fi, Bluetooth, mobile data) are done by tapping Quick Settings tiles through the
Accessibility service. The "Modify system settings" grant needed for brightness is also tapped through
Accessibility once. Mobile data / hotspot remain OEM dependent.

## Privacy
Action history stores only intent labels (never raw text, typed text or message bodies).
Conversation context is in-memory only. The cloud brain, when enabled, receives the user's command text.

## Verification status
Parser/planner logic is covered by unit tests (`app/src/test`). A full Android build and on-device test
must still be done by CI / on the phone.
