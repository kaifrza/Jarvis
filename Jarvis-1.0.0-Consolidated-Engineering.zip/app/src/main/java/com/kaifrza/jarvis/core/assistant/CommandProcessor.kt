package com.kaifrza.jarvis.core.assistant

import com.kaifrza.jarvis.core.actions.ActionExecutor
import com.kaifrza.jarvis.core.actions.ActionResult
import com.kaifrza.jarvis.core.actions.ContactMatch
import com.kaifrza.jarvis.core.actions.ContactResolver
import com.kaifrza.jarvis.core.intent.CommandUnderstandingEngine
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.security.RiskEngine

 data class CommandResponse(
    val state: CommandState,
    val message: String,
    val approvalToken: String? = null,
    val commandId: String? = null
)

class CommandProcessor(
    private val parser: CommandUnderstandingEngine,
    private val riskEngine: RiskEngine,
    private val executor: ActionExecutor,
    private val history: ActionHistory,
    private val contacts: ContactResolver
) {
    private var pendingApproval: ActionExecutor.PreparedAction? = null
    private var pendingChoice: PendingContactChoice? = null

    private data class PendingContactChoice(
        val plan: ActionPlan,
        val matches: List<ContactMatch>
    )

    fun handle(rawText: String): CommandResponse {
        val cleaned = rawText.trim()
        if (cleaned.isEmpty()) return CommandResponse(CommandState.FAILED, "Command khaali hai, sir.")

        if (pendingApproval != null) {
            val approval = interpretApproval(cleaned)
            if (approval == true) return approve()
            if (approval == false) return cancel()
        }

        pendingChoice?.let { choice ->
            val selected = resolveChoice(choice.matches, cleaned)
            if (selected != null) return continueAfterContactChoice(choice, selected)
            return CommandResponse(
                CommandState.WAITING_FOR_CHOICE,
                "Mujhe in mein se kaunsa number chahiye, sir?\n\n${contacts.describe(choice.matches)}\n\nAap keh sakte hain: “pehla”, “dusra”, “12 se start”, ya “last 4 digits 5678”.",
                commandId = choice.plan.command.id
            )
        }

        val command = parser.understand(cleaned)
        return handleCommand(command)
    }

    /** Execute an already-understood structured command. The brain never gets direct Android access. */
    fun handleCommand(command: JarvisCommand): CommandResponse {
        val plan = riskEngine.plan(command)

        if (command.intent == IntentType.UNKNOWN) {
            val result = CommandResponse(CommandState.FAILED, unknownMessage(command.rawText), commandId = command.id)
            history.record(command, result)
            return result
        }

        val resolved = resolveContactIfNeeded(plan)
        if (resolved is ContactResolution.Ambiguous) {
            pendingChoice = PendingContactChoice(resolved.plan, resolved.matches)
            return CommandResponse(
                CommandState.WAITING_FOR_CHOICE,
                "Mujhe ${resolved.name} ke multiple contacts mile hain. Kaunsa number use karun?\n\n${contacts.describe(resolved.matches)}\n\nNumber ka starting part, last digits, ya “pehla/dusra” bol sakte hain.",
                commandId = command.id
            )
        }
        val finalPlan = (resolved as ContactResolution.Resolved).plan

        val prepared = executor.prepare(finalPlan)
        if (finalPlan.requiresConfirmation) {
            pendingApproval = prepared
            return CommandResponse(
                CommandState.WAITING_FOR_APPROVAL,
                confirmationMessage(finalPlan),
                prepared.approvalToken,
                command.id
            )
        }

        val result = executePrepared(prepared)
        history.record(finalPlan.command, result)
        return result
    }

    fun approve(): CommandResponse {
        val prepared = pendingApproval
            ?: return CommandResponse(CommandState.FAILED, "Koi pending action nahi hai, sir.")
        val result = executePrepared(prepared, prepared.approvalToken)
        pendingApproval = null
        history.record(prepared.plan.command, result)
        return result
    }

    fun cancel(): CommandResponse {
        val command = pendingApproval?.plan?.command ?: pendingChoice?.plan?.command
        pendingApproval?.approvalToken?.let(executor::revoke)
        pendingApproval = null
        pendingChoice = null
        val result = CommandResponse(CommandState.CANCELLED, "Theek hai sir, cancel kar diya.", commandId = command?.id)
        if (command != null) history.record(command, result)
        return result
    }

    fun hasPendingApproval(): Boolean = pendingApproval != null
    fun hasPendingChoice(): Boolean = pendingChoice != null

    private sealed interface ContactResolution {
        data class Resolved(val plan: ActionPlan) : ContactResolution
        data class Ambiguous(val plan: ActionPlan, val matches: List<ContactMatch>, val name: String) : ContactResolution
    }

    private fun resolveContactIfNeeded(plan: ActionPlan): ContactResolution {
        if (plan.command.intent != IntentType.MAKE_CALL && plan.command.intent != IntentType.SEND_MESSAGE) {
            return ContactResolution.Resolved(plan)
        }

        val directNumber = plan.command.parameters["phone_number"]
        if (!directNumber.isNullOrBlank()) return ContactResolution.Resolved(plan)

        val name = plan.command.parameters["contact_name"]
            ?: return ContactResolution.Resolved(plan)

        val matches = contacts.find(name)
        return when {
            matches.isEmpty() -> ContactResolution.Resolved(plan)
            matches.size == 1 -> ContactResolution.Resolved(withPhone(plan, matches.single()))
            else -> ContactResolution.Ambiguous(plan, matches, name)
        }
    }

    private fun continueAfterContactChoice(
        choice: PendingContactChoice,
        selected: ContactMatch
    ): CommandResponse {
        pendingChoice = null
        val plan = withPhone(choice.plan, selected)
        val prepared = executor.prepare(plan)
        if (plan.requiresConfirmation) {
            pendingApproval = prepared
            return CommandResponse(
                CommandState.WAITING_FOR_APPROVAL,
                confirmationMessage(plan),
                prepared.approvalToken,
                plan.command.id
            )
        }
        val result = executePrepared(prepared)
        history.record(plan.command, result)
        return result
    }

    private fun withPhone(plan: ActionPlan, match: ContactMatch): ActionPlan {
        return plan.copy(command = plan.command.copy(parameters = plan.command.parameters + mapOf(
            "phone_number" to match.phoneNumber,
            "resolved_display_name" to match.displayName
        )))
    }

    private fun resolveChoice(matches: List<ContactMatch>, text: String): ContactMatch? {
        val n = text.lowercase().trim()
        val ordinal = when {
            n.matches(Regex("(pehla|first|1|one|number 1|no 1|1st).*")) -> 0
            n.matches(Regex("(dusra|second|2|two|number 2|no 2|2nd).*")) -> 1
            n.matches(Regex("(teesra|third|3|three|number 3|no 3|3rd).*")) -> 2
            n.matches(Regex("(chautha|fourth|4|four|number 4|no 4|4th).*")) -> 3
            else -> null
        }
        if (ordinal != null) return matches.getOrNull(ordinal)

        val filtered = contacts.chooseByHint(matches, n)
        if (filtered.size == 1) return filtered.single()

        val digits = n.filter(Char::isDigit)
        if (digits.length >= 7) {
            matches.firstOrNull { it.normalizedNumber == digits || it.nationalNumber == digits.takeLast(10) }?.let { return it }
        }
        return null
    }

    private fun interpretApproval(text: String): Boolean? {
        val n = text.lowercase().replace(Regex("[.!?,]+"), " ").replace(Regex("\\s+"), " ").trim()
        val yes = setOf("yes", "haan", "ha", "han", "ok", "okay", "theek", "theek hai", "kar do", "bhej do", "send kar do", "call kar do", "confirm", "confirmed")
        val no = setOf("no", "nahi", "nahin", "cancel", "cancel karo", "rehne do", "chhodo", "mat karo", "mat bhejo", "don't", "dont", "stop")
        return when {
            n in yes || n.startsWith("haan ") || n.startsWith("ha ") || n.startsWith("yes ") || n.startsWith("okay ") || n.startsWith("ok ") -> true
            n in no || n.startsWith("nahi ") || n.startsWith("nahin ") || n.startsWith("cancel ") || n.startsWith("mat ") -> false
            else -> null
        }
    }

    private fun executePrepared(prepared: ActionExecutor.PreparedAction, approvalToken: String? = null): CommandResponse {
        return when (val result = executor.execute(prepared, approvalToken)) {
            ActionResult.Success -> CommandResponse(CommandState.SUCCESS, successMessage(prepared.plan.command))
            is ActionResult.SuccessWithMessage -> CommandResponse(CommandState.SUCCESS, result.message)
            is ActionResult.Failure -> CommandResponse(CommandState.FAILED, result.reason)
            ActionResult.RequiresApproval -> CommandResponse(CommandState.WAITING_FOR_APPROVAL, "Pehle approval chahiye, sir.")
        }
    }

    private fun confirmationMessage(plan: ActionPlan): String {
        val command = plan.command
        return when (command.intent) {
            IntentType.SEND_MESSAGE -> {
                val who = command.parameters["resolved_display_name"] ?: command.parameters["contact_name"] ?: command.parameters["phone_number"] ?: "the contact"
                val body = command.parameters["message"] ?: ""
                "Message ready for $who:\n\n“$body”\n\nBhej doon, sir?"
            }
            IntentType.MAKE_CALL -> {
                val who = command.parameters["resolved_display_name"] ?: command.parameters["contact_name"]
                val number = command.parameters["phone_number"]
                if (who != null && number != null) "$who — ${contacts.mask(number)} ko call kar doon, sir?"
                else "${number ?: who ?: "is number"} par call kar doon, sir?"
            }
            IntentType.UI_CLICK_TEXT -> {
                val target = command.parameters["text"] ?: "this action"
                val who = command.parameters["contact_name"]
                val preview = command.parameters["message_preview"]
                if (target.equals("send", true) && !preview.isNullOrBlank()) {
                    "WhatsApp message ready${who?.let { " for $it" } ?: ""}:\n\n“$preview”\n\nBhej doon, sir?"
                } else {
                    "Action ready: click “$target”. Aapki approval chahiye, sir?"
                }
            }
            else -> "This action needs your approval, sir.\n\n${command.rawText}"
        }
    }

    private fun unknownMessage(raw: String): String =
        "Abhi main is command ko confidently samajh nahi paaya, sir. Aap natural language mein bol sakte hain — jaise “Zubair ko call karo”, “9876543210 par call karo”, ya “YouTube kholo”."

    private fun successMessage(command: JarvisCommand): String = when (command.intent) {
        IntentType.OPEN_APP -> "${command.parameters["app_name"] ?: "App"} opened, sir."
        IntentType.NAVIGATE_BACK -> "Back ho gaya, sir."
        IntentType.HOME -> "Home par aa gaya, sir."
        IntentType.RECENTS -> "Recent apps khol diye, sir."
        IntentType.OPEN_NOTIFICATIONS -> "Notifications khol diye, sir."
        IntentType.READ_NOTIFICATIONS -> "Notifications read kar li, sir."
        IntentType.ACCESS_SCREEN -> "Screen read kar li, sir."
        IntentType.SET_VOLUME -> "Volume ${command.parameters["level"] ?: "50"}% kar diya, sir."
        IntentType.SET_BRIGHTNESS -> "Brightness ${command.parameters["level"] ?: "50"}% kar di, sir."
        IntentType.PLAY_MEDIA -> "Media play kar diya, sir."
        IntentType.PAUSE_MEDIA -> "Media pause kar diya, sir."
        IntentType.STOP_MEDIA -> "Media stop kar diya, sir."
        IntentType.NEXT_MEDIA -> "Next track par chala gaya, sir."
        IntentType.PREVIOUS_MEDIA -> "Previous track par chala gaya, sir."
        IntentType.CREATE_ALARM -> "Alarm setup khol diya, sir."
        IntentType.MAKE_CALL -> "Call start ho gayi, sir."
        IntentType.SEND_MESSAGE -> "Message send ho gaya, sir."
        IntentType.UI_CLICK_TEXT -> if (command.parameters["text"].equals("send", true)) "Message send ho gaya, sir." else "Click ho gaya, sir."
        IntentType.UI_TYPE_TEXT -> "Text enter ho gaya, sir."
        IntentType.UI_FOCUS_INPUT -> "Input ready hai, sir."
        IntentType.UI_SCROLL -> "Scroll ho gaya, sir."
        IntentType.OPEN_NETWORK_SETTINGS -> "Network settings khol diye, sir."
        IntentType.OPEN_WIFI_SETTINGS -> "Wi-Fi settings khol diye, sir."
        IntentType.OPEN_BLUETOOTH_SETTINGS -> "Bluetooth settings khol diye, sir."
        IntentType.SET_FLASHLIGHT -> if (command.parameters["enabled"] == "false") "Torch band kar diya, sir." else "Torch on kar diya, sir."
        IntentType.CALCULATE -> "Calculation complete, sir."
        else -> "Done, sir."
    }

    fun lastHistory(): List<ActionHistory.Entry> = history.read()
}
