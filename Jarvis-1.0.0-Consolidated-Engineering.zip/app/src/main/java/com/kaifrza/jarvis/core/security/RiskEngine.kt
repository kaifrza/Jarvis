package com.kaifrza.jarvis.core.security

import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.model.RiskLevel
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.tools.ToolRegistry

/**
 * Execution policy. Jarvis uses a one-time setup model: once Android permissions/services
 * are granted, normal commands execute directly without repetitive confirmation dialogs.
 * Android-enforced runtime/system permissions cannot be bypassed by an app.
 */
class RiskEngine(private val tools: ToolRegistry) {
    fun plan(command: JarvisCommand): ActionPlan {
        val descriptor = tools.find(command.intent)
        val risk = descriptor?.risk ?: when (command.intent) {
            IntentType.UNKNOWN -> RiskLevel.CRITICAL
            else -> RiskLevel.HIGH
        }
        // User-configured direct-execution mode: no per-action approval gate.
        // The operating system still enforces CALL_PHONE, SEND_SMS, WRITE_SETTINGS, etc.
        return ActionPlan(
            command = command,
            risk = risk,
            requiresConfirmation = false
        )
    }
}
