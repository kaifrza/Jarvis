package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import java.util.Locale
import java.util.UUID

/**
 * Offline-first language normalizer. It intentionally accepts English + Roman Urdu/Hinglish
 * variants and maps them into stable structured commands. The execution layer never parses text.
 */
class IntentParser {
    fun parse(raw: String): JarvisCommand {
        val text = raw.trim().replace(Regex("\\s+"), " ")
        val n = normalize(text)
        val intent = when {
            isCancel(n) -> IntentType.UNKNOWN
            isReadNotifications(n) -> IntentType.READ_NOTIFICATIONS
            isNotifications(n) -> IntentType.OPEN_NOTIFICATIONS
            isBack(n) -> IntentType.NAVIGATE_BACK
            isHome(n) -> IntentType.HOME
            isRecents(n) -> IntentType.RECENTS
            looksLikeMessage(n) -> IntentType.SEND_MESSAGE
            looksLikeCall(n) -> IntentType.MAKE_CALL
            looksLikeCalculate(n) -> IntentType.CALCULATE
            looksLikeBrightness(n) -> IntentType.SET_BRIGHTNESS
            looksLikeVolume(n) -> IntentType.SET_VOLUME
            looksLikeMedia(n) -> mediaIntent(n)
            looksLikeWifiToggle(n) -> IntentType.TOGGLE_WIFI
            looksLikeBluetoothToggle(n) -> IntentType.TOGGLE_BLUETOOTH
            looksLikeNetworkToggle(n) -> IntentType.TOGGLE_MOBILE_DATA
            looksLikeNetwork(n) -> IntentType.OPEN_NETWORK_SETTINGS
            looksLikeWifi(n) -> IntentType.OPEN_WIFI_SETTINGS
            looksLikeBluetooth(n) -> IntentType.OPEN_BLUETOOTH_SETTINGS
            looksLikeFlashlight(n) -> IntentType.SET_FLASHLIGHT
            looksLikeAlarm(n) -> IntentType.CREATE_ALARM
            looksLikeScreenRead(n) -> IntentType.ACCESS_SCREEN
            looksLikeOpenApp(n) -> IntentType.OPEN_APP
            else -> IntentType.UNKNOWN
        }

        val params = when (intent) {
            IntentType.OPEN_APP -> extractAppName(n)?.let { mapOf("app_name" to it) } ?: emptyMap()
            IntentType.CALCULATE -> mapOf("expression" to extractExpression(text))
            IntentType.SET_FLASHLIGHT -> mapOf("enabled" to if (looksLikeOff(n)) "false" else "true")
            IntentType.TOGGLE_WIFI, IntentType.TOGGLE_MOBILE_DATA, IntentType.TOGGLE_BLUETOOTH -> mapOf("enabled" to if (looksLikeOff(n)) "false" else "true")
            IntentType.SET_VOLUME -> mapOf("level" to extractPercent(n, default = 50))
            IntentType.SET_BRIGHTNESS -> mapOf("level" to extractPercent(n, default = 50))
            IntentType.PLAY_MEDIA -> emptyMap()
            IntentType.PAUSE_MEDIA -> emptyMap()
            IntentType.STOP_MEDIA -> emptyMap()
            IntentType.NEXT_MEDIA -> emptyMap()
            IntentType.PREVIOUS_MEDIA -> emptyMap()
            IntentType.CREATE_ALARM -> extractAlarmParams(n)
            IntentType.MAKE_CALL -> extractCallParams(text, n)
            IntentType.SEND_MESSAGE -> {
                val target = extractMessageTarget(n)
                val body = extractMessageBody(text)
                buildMap {
                    if (target != null) put("contact_name", target)
                    target?.let { extractPhoneNumber(it)?.let { number -> put("phone_number", number) } }
                    if (body != null) put("message", body)
                }
            }
            else -> emptyMap()
        }

        return JarvisCommand(UUID.randomUUID().toString(), text, intent, params)
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace('’', '\'').replace('“', '"').replace('”', '"')
        .replace(Regex("[!?]+$"), "").trim()

    private fun isCancel(n: String) = n in setOf("cancel", "cancel karo", "cancel kar do", "rehne do", "chhodo", "stop this", "stop karo")
    private fun isBack(n: String) = n in setOf("back", "go back", "back jao", "peeche jao", "piche jao", "wapas jao", "wapis jao") || n.contains("previous page") || n.contains("pichle page")
    private fun isHome(n: String) = n in setOf("home", "home jao", "home kholo", "home screen", "home screen kholo") || n.contains("home screen par") || n.contains("ghar screen")
    private fun isRecents(n: String) = n.contains("recent apps") || n == "recents" || n.contains("recent kholo") || n.contains("recent dikhao")
    private fun isNotifications(n: String) = n.contains("notification kholo") || n.contains("notifications kholo") || n.contains("notification dikhao") || n.contains("notifications dikhao") || n.contains("notification panel") || n.contains("notification shade")
    private fun isReadNotifications(n: String) = (n.contains("notification") && (n.contains("read") || n.contains("batao") || n.contains("padho") || n.contains("dekho") || n.contains("important")))
    private fun looksLikeScreenRead(n: String) = n.contains("screen") && (n.contains("read") || n.contains("dekho") || n.contains("batao") || n.contains("kya hai"))

    private fun looksLikeCalculate(n: String) = n.matches(Regex(".*\\b(calculate|calc|hisab|kitna|multiply|plus|minus|divide|times|into|x)\\b.*[0-9].*")) || n.matches(Regex(".*[0-9]+\\s*[+x×*\\-/]\\s*[0-9]+.*"))
    private fun extractExpression(text: String): String = text
        .replace(Regex("(?i)\\b(calculate|calc|hisab|kitna|please|karo|kar do|batao|result|nikalo)\\b"), " ")
        .replace(Regex("(?i)\\b(multiply|times|into)\\b"), "*")
        .replace(Regex("(?i)\\b(plus)\\b"), "+")
        .replace(Regex("(?i)\\b(minus)\\b"), "-")
        .replace(Regex("(?i)\\b(divide|divided by)\\b"), "/")
        .replace('×','*').replace(Regex("\\s+x\\s+", RegexOption.IGNORE_CASE), " * ")
        .replace(Regex("\\s+"), " ").trim()

    private fun looksLikeVolume(n: String) = n.contains("volume") || n.contains("awaz") || n.contains("awaaz") || n.contains("sound") || n.contains("loud") || Regex("\\bvolume\\s+\\d{1,3}").containsMatchIn(n)
    private fun looksLikeBrightness(n: String) = n.contains("brightness") || n.contains("screen light") || n.contains("display light") || n.contains("roshni")
    private fun looksLikeMedia(n: String) = n in setOf("play", "pause", "stop music", "next", "next song", "previous", "previous song", "agla gana", "pichla gana") || n.contains("play music") || n.contains("pause music") || n.contains("next song") || n.contains("previous song")
    private fun mediaIntent(n: String) = when {
        n.contains("pause") -> IntentType.PAUSE_MEDIA
        n.contains("stop") -> IntentType.STOP_MEDIA
        n.contains("next") || n.contains("agla") -> IntentType.NEXT_MEDIA
        n.contains("previous") || n.contains("pichla") -> IntentType.PREVIOUS_MEDIA
        else -> IntentType.PLAY_MEDIA
    }
    private fun extractPercent(n: String, default: Int): String {
        val explicit = Regex("(?<!\\d)(\\d{1,3})\\s*%?").find(n)?.groupValues?.getOrNull(1)?.toIntOrNull()
        return (explicit ?: default).coerceIn(0, 100).toString()
    }

    private fun looksLikeOff(n: String) = listOf(" off", " band", " bujha", " disable", " disabled").any(n::contains) || n.endsWith("off") || n.endsWith("band")
    private fun looksLikeNetworkToggle(n: String) = listOf("network on", "network chalu", "network chalao", "network off", "network band", "internet on", "internet chalu", "internet chalao", "internet off", "internet band", "mobile data on", "mobile data chalu", "mobile data chalao", "mobile data off", "mobile data band", "data on", "data chalu", "data chalao", "data off", "data band", "enable mobile data", "disable mobile data", "turn mobile data on", "turn mobile data off").any(n::contains)
    private fun looksLikeWifiToggle(n: String) = listOf("wifi on", "wi-fi on", "wifi chalu", "wi-fi chalu", "wifi chalao", "wi-fi chalao", "wifi off", "wi-fi off", "wifi band", "wi-fi band", "enable wifi", "enable wi-fi", "disable wifi", "disable wi-fi", "switch on wifi", "switch off wifi", "turn wifi on", "turn wifi off").any(n::contains)
    private fun looksLikeBluetoothToggle(n: String) = listOf("bluetooth on", "bluetooth chalu", "bluetooth chalao", "bluetooth off", "bluetooth band", "enable bluetooth", "disable bluetooth", "turn bluetooth on", "turn bluetooth off", "switch on bluetooth", "switch off bluetooth").any(n::contains)
    private fun looksLikeNetwork(n: String) = listOf("network settings", "internet settings", "mobile data settings").any(n::contains)
    private fun looksLikeWifi(n: String) = listOf("wifi settings", "wi-fi settings").any(n::contains)
    private fun looksLikeBluetooth(n: String) = listOf("bluetooth settings").any(n::contains)
    private fun looksLikeFlashlight(n: String) = listOf("flashlight", "torch", "flash light").any(n::contains)
    private fun looksLikeAlarm(n: String) = n.contains("alarm") && (n.contains("set") || n.contains("lag") || n.contains("baja") || n.contains("wake"))
    private fun extractAlarmParams(n: String): Map<String, String> {
        val match = Regex("\\b(?:at|@)?\\s*(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?\\b").find(n)
        return buildMap {
            if (match != null) {
                put("hour", match.groupValues[1])
                put("minute", match.groupValues.getOrNull(2)?.ifBlank { "0" } ?: "0")
                put("ampm", match.groupValues.getOrNull(3).orEmpty())
            }
        }
    }

    private fun looksLikeMessage(n: String) = listOf("message", "msg", "sms", "text message", "text karo", "text bhejo").any(n::contains) && !n.startsWith("open message")
    private fun looksLikeCall(n: String): Boolean {
        val words = listOf("call ", "call karo", "call kar", "phone karo", "phone kar", "phone lagao", "dial ", "dial karo", "ring karo", "number pe call", "number par call")
        return words.any(n::contains) || n.startsWith("call") || n.startsWith("dial") || (extractPhoneNumber(n) != null && (n.contains("phone") || n.contains("call") || n.contains("dial")))
    }
    private fun looksLikeOpenApp(n: String): Boolean {
        val verbs = listOf("open ", "open karo", " kholo", "kholo", "khol do", "kholna", "chalao", "launch ", "launch karo", "start ", "start karo", "run ", "run karo", "chalu karo")
        return verbs.any(n::contains) || knownAppAlias(n)?.let { alias -> n == alias || (n.contains(alias) && verbs.any(n::contains)) } == true
    }

    private fun extractAppName(n: String): String? {
        knownAppAlias(n)?.let { return it }
        var value = n
        listOf("open ", "launch ", "start ", "run ", "open karo ", "launch karo ", "start karo ", "run karo ", "khol do ", "kholna ", "kholo ", "chalao ", "chalu karo ").forEach { value = value.removePrefix(it) }
        value = value.replace(Regex("\\b(please|zara|plz|app|application|ko|karo|kar do|open|kholo|khol do|launch|start|run|chalu|chalao)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        return value.ifBlank { null }
    }
    private fun knownAppAlias(n: String): String? {
        val aliases = linkedMapOf(
            "youtube" to listOf("youtube", "you tube", "yt"), "whatsapp" to listOf("whatsapp", "what's app", "whats app", "whatsap"),
            "instagram" to listOf("instagram", "insta"), "chrome" to listOf("chrome", "google chrome"),
            "calculator" to listOf("calculator", "calc", "calcu"), "settings" to listOf("settings", "setting", "setings"),
            "telegram" to listOf("telegram", "tele gram"), "facebook" to listOf("facebook", "fb"), "maps" to listOf("google maps", "maps", "map"),
            "gmail" to listOf("gmail", "mail")
        )
        return aliases.entries.firstOrNull { (_, words) -> words.any(n::contains) }?.key
    }

    private fun extractCallParams(text: String, n: String): Map<String, String> = extractPhoneNumber(text)?.let { mapOf("phone_number" to it) } ?: extractCallTarget(n)?.let { mapOf("contact_name" to it) } ?: emptyMap()
    private fun extractPhoneNumber(value: String): String? = Regex("(?<!\\d)(?:\\+?\\d[\\d\\s().-]{6,18}\\d)(?!\\d)").findAll(value).map { it.value.filter(Char::isDigit) }.firstOrNull { it.length in 7..15 }

    private fun extractCallTarget(n: String): String? {
        var value = n
        listOf("^please ", "^zara ", "^mujhe ", "^mere liye ", "^can you ", "^please call ", "^please phone ").forEach { value = value.replace(Regex(it), "") }
        value = value.replace(Regex("^call\\s+"), "").replace(Regex("^dial\\s+"), "").replace(Regex("^phone\\s+"), "").replace(Regex("^ring\\s+"), "")
            .replace(Regex("\\b(ko|k[o0]|please|zara|se|par|pe)\\b"), " ").replace(Regex("\\b(call|phone|lagao|lagana|karo|karna|kar do|dial|ring)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        return value.ifBlank { null }
    }

    private fun extractMessageTarget(n: String): String? {
        Regex("(?i)^(.+?)\\s+ko\\s+(?:message|msg|sms|text)\\b").find(n)?.groupValues?.getOrNull(1)?.let { cleanContactTarget(it)?.let { target -> return target } }
        Regex("\\bto\\s+(.+?)\\s+\\b(?:saying|that)\\b").find(n)?.groupValues?.getOrNull(1)?.let { cleanContactTarget(it)?.let { target -> return target } }
        val marker = Regex("\\b(?:message|msg|sms|text)\\b").find(n)
        if (marker != null) {
            val after = n.substring(marker.range.last + 1).trim()
            val targetPart = after.substringBefore(":").substringBefore(" saying ").substringBefore(" that ").trim()
            if (targetPart.isNotBlank() && !targetPart.contains(" ")) cleanContactTarget(targetPart)?.let { return it }
        }
        val before = marker?.let { n.substring(0, it.range.first) } ?: n
        val beforeTrimmed = before.trim()
        if (beforeTrimmed.endsWith(" ko")) return cleanContactTarget(beforeTrimmed.removeSuffix(" ko"))
        Regex("(?i)^(.+?)\\s+ko$").find(beforeTrimmed)?.groupValues?.getOrNull(1)?.let { return cleanContactTarget(it) }
        Regex("(?i)\\bto\\s+(.+)$").find(before)?.groupValues?.getOrNull(1)?.let { cleanContactTarget(it)?.let { target -> return target } }
        return null
    }
    private fun cleanContactTarget(value: String): String? = value.replace(Regex("\\b(please|zara|mujhe|mere liye|to|ko|ke liye|par|pe|bhejo|send|do|karo|kar do|message|msg|sms|text)\\b"), " ").replace(Regex("\\s+"), " ").trim().ifBlank { null }
    private fun extractMessageBody(text: String): String? {
        val colon = text.indexOf(':')
        if (colon >= 0 && listOf("message", "msg", "sms", "text", "bhejo").any(text.substring(0, colon).lowercase()::contains)) return text.substring(colon + 1).trim().ifBlank { null }
        Regex("(?i)\\b(?:message|msg|sms|text)\\s*:\\s*").find(text)?.let { return text.substring(it.range.last + 1).trim().ifBlank { null } }
        Regex("(?i)\\bbhejo\\s*:\\s*").find(text)?.let { return text.substring(it.range.last + 1).trim().ifBlank { null } }
        Regex("(?i)\\bsaying\\s+(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().ifBlank { null } }
        Regex("(?i)\\b(?:bolo|batao|keh do)\\s*[:,-]?\\s*(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().removeSurrounding("\"").removeSurrounding("'").ifBlank { null } }
        Regex("(?i)\\bbhejo\\b\\s*(.*)$").find(text)?.groupValues?.getOrNull(1)?.let { val body = it.removePrefix(":").trim(); if (body.isNotBlank()) return body }
        Regex("(?i)\\bko\\s+(?:message|msg|sms|text)\\s+(?:karo|kar do|bhejo)\\s*:??\\s*(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().removePrefix(":").trim().ifBlank { null } }
        return null
    }
}
