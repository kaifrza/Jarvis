package com.kaifrza.jarvis.core.actions

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.provider.AlarmClock
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.wifi.WifiManager
import android.bluetooth.BluetoothAdapter
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import kotlin.math.roundToInt

class UtilityAction(private val context: Context) : JarvisAction {
    override val id = "android.utility"

    override fun validate(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.CALCULATE -> if (plan.command.parameters["expression"].isNullOrBlank()) ActionResult.Failure("Mujhe calculation expression nahi mila.") else ActionResult.Success
        IntentType.SET_FLASHLIGHT -> if (Build.VERSION.SDK_INT >= 23) ActionResult.Success else ActionResult.Failure("Torch control is not available on this Android version.")
        IntentType.SET_VOLUME, IntentType.SET_BRIGHTNESS -> ActionResult.Success
        IntentType.PLAY_MEDIA, IntentType.PAUSE_MEDIA, IntentType.STOP_MEDIA, IntentType.NEXT_MEDIA, IntentType.PREVIOUS_MEDIA -> ActionResult.Success
        IntentType.CREATE_ALARM -> if (plan.command.parameters["hour"].isNullOrBlank()) ActionResult.Failure("Alarm ke liye time batao, e.g. 7:30 AM.") else ActionResult.Success
        IntentType.TOGGLE_WIFI, IntentType.TOGGLE_MOBILE_DATA, IntentType.TOGGLE_BLUETOOTH -> if (JarvisAccessibilityService.instance == null) ActionResult.Failure("Accessibility Service is required for system toggle control.") else ActionResult.Success
        else -> ActionResult.Success
    }

    override fun execute(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.OPEN_NETWORK_SETTINGS -> open(Settings.ACTION_WIRELESS_SETTINGS)
        IntentType.OPEN_WIFI_SETTINGS -> open(Settings.ACTION_WIFI_SETTINGS)
        IntentType.OPEN_BLUETOOTH_SETTINGS -> open(Settings.ACTION_BLUETOOTH_SETTINGS)
        IntentType.SET_FLASHLIGHT -> setTorch(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_WIFI -> toggleWifi(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_MOBILE_DATA -> toggleMobileData(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_BLUETOOTH -> toggleBluetooth(plan.command.parameters["enabled"] != "false")
        IntentType.SET_VOLUME -> setVolume(plan.command.parameters["level"]?.toIntOrNull() ?: 50)
        IntentType.SET_BRIGHTNESS -> setBrightness(plan.command.parameters["level"]?.toIntOrNull() ?: 50)
        IntentType.PLAY_MEDIA -> media(AudioManager.KEYCODE_MEDIA_PLAY)
        IntentType.PAUSE_MEDIA -> media(AudioManager.KEYCODE_MEDIA_PAUSE)
        IntentType.STOP_MEDIA -> media(AudioManager.KEYCODE_MEDIA_STOP)
        IntentType.NEXT_MEDIA -> media(AudioManager.KEYCODE_MEDIA_NEXT)
        IntentType.PREVIOUS_MEDIA -> media(AudioManager.KEYCODE_MEDIA_PREVIOUS)
        IntentType.CREATE_ALARM -> createAlarm(plan)
        IntentType.CALCULATE -> {
            val expression = plan.command.parameters["expression"].orEmpty()
            val result = SimpleCalculator.evaluate(expression)
            if (result == null) ActionResult.Failure("Main calculation ko samajh nahi paaya: $expression") else ActionResult.SuccessWithMessage("$expression = $result")
        }
        else -> ActionResult.Failure("Unsupported utility action.")
    }

    override fun verify(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.TOGGLE_WIFI -> verifyWifi(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_BLUETOOTH -> verifyBluetooth(plan.command.parameters["enabled"] != "false")
        else -> ActionResult.Success
    }

    private fun setVolume(percent: Int): ActionResult = runCatching {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        val max = audio.getStreamMaxVolume(stream)
        val value = (max * percent.coerceIn(0, 100) / 100f).roundToInt()
        audio.setStreamVolume(stream, value, 0)
        ActionResult.SuccessWithMessage("Volume ${percent.coerceIn(0, 100)}% kar diya.")
    }.getOrElse { ActionResult.Failure("Volume control fail hua: ${it.message ?: "unknown"}") }

    private fun setBrightness(percent: Int): ActionResult {
        if (!Settings.System.canWrite(context)) return ActionResult.Failure("Brightness direct control ke liye Jarvis ko 'Modify system settings' ek baar allow karo.")
        return runCatching {
            val value = (255 * percent.coerceIn(0, 100) / 100f).roundToInt()
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, value)
            ActionResult.SuccessWithMessage("Brightness ${percent.coerceIn(0, 100)}% kar di.")
        }.getOrElse { ActionResult.Failure("Brightness control fail hua: ${it.message ?: "unknown"}") }
    }

    private fun media(keyCode: Int): ActionResult = runCatching {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode))
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Media control fail hua: ${it.message ?: "unknown"}") }

    private fun createAlarm(plan: ActionPlan): ActionResult = runCatching {
        var hour = plan.command.parameters["hour"]!!.toInt()
        val minute = plan.command.parameters["minute"]?.toIntOrNull() ?: 0
        val ampm = plan.command.parameters["ampm"].orEmpty()
        if (ampm == "pm" && hour < 12) hour += 12
        if (ampm == "am" && hour == 12) hour = 0
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        ActionResult.SuccessWithMessage("Alarm setup ${String.format("%02d:%02d", hour, minute)} ke liye khol diya.")
    }.getOrElse { ActionResult.Failure("Alarm app open nahi ho saki.") }

    private fun toggleWifi(enabled: Boolean): ActionResult {
        val manager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        if (manager != null && manager.isWifiEnabled == enabled) return ActionResult.Success
        return JarvisAccessibilityService.instance?.openQuickSettingsAndToggle(listOf("Wi-Fi", "Wifi"), enabled)?.let { if (it) ActionResult.Success else ActionResult.Failure("Wi-Fi toggle control could not be located.") }
            ?: ActionResult.Failure("Accessibility Service is unavailable.")
    }
    private fun toggleMobileData(enabled: Boolean): ActionResult = JarvisAccessibilityService.instance?.openQuickSettingsAndToggle(listOf("Mobile data", "Mobile Data", "Internet", "Data"), enabled)?.let { if (it) ActionResult.Success else ActionResult.Failure("Mobile-data/Internet toggle could not be located on this device.") } ?: ActionResult.Failure("Accessibility Service is unavailable.")
    private fun toggleBluetooth(enabled: Boolean): ActionResult {
        val adapter = runCatching { BluetoothAdapter.getDefaultAdapter() }.getOrNull()
        if (adapter != null && adapter.isEnabled == enabled) return ActionResult.Success
        return JarvisAccessibilityService.instance?.openQuickSettingsAndToggle(listOf("Bluetooth"), enabled)?.let { if (it) ActionResult.Success else ActionResult.Failure("Bluetooth toggle control could not be located.") } ?: ActionResult.Failure("Accessibility Service is unavailable.")
    }
    private fun verifyWifi(enabled: Boolean): ActionResult {
        val manager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return ActionResult.Success
        val deadline = android.os.SystemClock.uptimeMillis() + 2_500L
        while (android.os.SystemClock.uptimeMillis() < deadline) { if (manager.isWifiEnabled == enabled) return ActionResult.Success; android.os.SystemClock.sleep(120) }
        return ActionResult.Failure("Wi-Fi state could not be verified.")
    }
    private fun verifyBluetooth(enabled: Boolean): ActionResult {
        val adapter = runCatching { BluetoothAdapter.getDefaultAdapter() }.getOrNull() ?: return ActionResult.Success
        val deadline = android.os.SystemClock.uptimeMillis() + 2_500L
        while (android.os.SystemClock.uptimeMillis() < deadline) { if (adapter.isEnabled == enabled) return ActionResult.Success; android.os.SystemClock.sleep(120) }
        return ActionResult.Failure("Bluetooth state could not be verified.")
    }
    private fun open(action: String): ActionResult = runCatching { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ActionResult.Success }.getOrElse { ActionResult.Failure("Settings open nahi ho sakin.") }
    private fun setTorch(enabled: Boolean): ActionResult = runCatching {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id -> manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return ActionResult.Failure("Torch camera nahi mila.")
        manager.setTorchMode(cameraId, enabled); ActionResult.Success
    }.getOrElse { ActionResult.Failure("Torch control fail hua: ${it.message ?: "unknown"}") }
}

private object SimpleCalculator {
    fun evaluate(raw: String): String? {
        val s = raw.replace(" ", "")
        val m = Regex("^(-?\\d+(?:\\.\\d+)?)([+\\-*/])(-?\\d+(?:\\.\\d+)?)$").matchEntire(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val v = when (m.groupValues[2]) { "+" -> a+b; "-" -> a-b; "*" -> a*b; "/" -> if (b == 0.0) return null else a/b; else -> return null }
        return if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
    }
}
