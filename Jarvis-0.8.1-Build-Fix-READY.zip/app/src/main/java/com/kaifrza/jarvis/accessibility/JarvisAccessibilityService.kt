package com.kaifrza.jarvis.accessibility

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.ui.JarvisWebViewHost
import com.kaifrza.jarvis.ui.MainActivity
import com.kaifrza.jarvis.voice.JarvisSpeaker
import com.kaifrza.jarvis.voice.JarvisVoiceController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Cross-app capability boundary. The J bubble opens a real, draggable, focusable assistant overlay. */
class JarvisAccessibilityService : android.accessibilityservice.AccessibilityService() {
    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
            private set
    }

    @Volatile var foregroundPackage: String? = null
        private set

    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var overlayRoot: FrameLayout? = null
    private var overlayWebView: WebView? = null
    private var overlayHost: JarvisWebViewHost? = null
    private var overlayVoice: JarvisVoiceController? = null
    private var overlaySpeaker: JarvisSpeaker? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val container get() = (application as JarvisApplication).container

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        foregroundPackage = rootInActiveWindow?.packageName?.toString()
        addBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            foregroundPackage = event.packageName?.toString()
        }
    }

    override fun onInterrupt() = Unit

    fun openJarvisUi() = showAssistantOverlay()

    fun performGlobalActionBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalActionHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalActionRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performGlobalActionNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun clickText(text: String): Boolean = clickBestMatchingNode(text)

    fun clickContentDescription(description: String): Boolean {
        val target = normalize(description)
        val deadline = SystemClock.uptimeMillis() + 1_800L
        while (SystemClock.uptimeMillis() < deadline) {
            val root = rootInActiveWindow
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && normalize(n.contentDescription?.toString().orEmpty()).contains(target) }.firstOrNull() }
            if (node != null && clickNodeOrClickableParent(node)) return true
            SystemClock.sleep(120)
        }
        return false
    }

    fun focusEditable(): Boolean {
        val root = rootInActiveWindow ?: return false
        val editable = findNodes(root) { it.isVisibleToUser && it.isEditable }
        val node = editable.firstOrNull { it.isFocused } ?: editable.firstOrNull() ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) || node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun typeText(text: String): Boolean {
        val deadline = SystemClock.uptimeMillis() + 1_500L
        while (SystemClock.uptimeMillis() < deadline) {
            val root = rootInActiveWindow
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && n.isEditable && n.isFocused }.firstOrNull() }
                ?: root?.let { findNodes(it) { n -> n.isVisibleToUser && n.isEditable }.firstOrNull() }
            if (node != null) {
                val arguments = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
                if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)) return true
            }
            SystemClock.sleep(120)
        }
        return false
    }

    fun scrollForward(): Boolean = scroll(true)
    fun scrollBackward(): Boolean = scroll(false)

    fun searchCurrentScreen(query: String): Boolean {
        if (query.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        val editables = findNodes(root) { it.isVisibleToUser && it.isEditable }
        val field = editables.firstOrNull {
            val hint = normalize(it.hintText?.toString().orEmpty())
            val desc = normalize(it.contentDescription?.toString().orEmpty())
            hint.contains("search") || desc.contains("search")
        } ?: editables.firstOrNull() ?: return false
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, query) }
        if (!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return false
        // On Android 11+ use the IME-enter accessibility action when exposed. On Android 10
        // fall back to a visible Search/Go/Enter button if the app exposes one.
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            runCatching { if (field.performAction(AccessibilityNodeInfo.ACTION_IME_ENTER)) return true }
        }
        return clickBestMatchingNode("Search") || clickContentDescription("Search") ||
            clickBestMatchingNode("Go") || clickBestMatchingNode("Enter") ||
            clickContentDescription("Go") || clickContentDescription("Enter")
    }

    fun findVisibleText(text: String): List<AccessibilityNodeInfo> {
        val root = rootInActiveWindow ?: return emptyList()
        val target = normalize(text)
        return findNodes(root) { it.isVisibleToUser && normalize(it.text?.toString().orEmpty()).contains(target) }
    }

    fun isTextVisible(text: String, timeoutMs: Long = 1_200L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            if (findVisibleText(text).isNotEmpty()) return true
            SystemClock.sleep(120)
        }
        return findVisibleText(text).isNotEmpty()
    }

    fun waitForForegroundPackage(packageName: String, timeoutMs: Long = 2_500L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            if (foregroundPackage == packageName) return true
            SystemClock.sleep(100)
        }
        return foregroundPackage == packageName
    }

    private fun addBubble() {
        val view = TextView(this).apply {
            text = "J"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = rounded(Color.rgb(70, 150, 190), 100)
            elevation = 20f
        }
        bubble = view
        val params = WindowManager.LayoutParams(dp(60), dp(60), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = dp(14); y = dp(220) }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(6)) moved = true
                    params.x = (startX - dx).coerceAtLeast(0); params.y = (startY + dy).coerceAtLeast(0)
                    runCatching { windowManager.updateViewLayout(view, params) }; true
                }
                MotionEvent.ACTION_UP -> { if (!moved) showAssistantOverlay(); true }
                else -> true
            }
        }
        windowManager.addView(view, params)
    }

    private fun showAssistantOverlay() {
        if (overlayRoot != null) { hideAssistantOverlay(); return }
        val web = WebView(this)
        val root = FrameLayout(this).apply { background = rounded(Color.rgb(9, 13, 18), 26) }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        val drag = TextView(this).apply {
            text = "≡  JARVIS"
            setTextColor(Color.rgb(160, 220, 240)); textSize = 10f; gravity = Gravity.CENTER
            background = rounded(Color.argb(235, 16, 23, 31), 18)
        }
        val dragLp = FrameLayout.LayoutParams(-1, dp(28), Gravity.TOP)
        dragLp.leftMargin = dp(80); dragLp.rightMargin = dp(80)
        root.addView(drag, dragLp)
        overlayRoot = root; overlayWebView = web
        val width = (resources.displayMetrics.widthPixels * 0.90f).toInt()
        val height = (resources.displayMetrics.heightPixels * 0.22f).toInt().coerceIn(dp(180), dp(360))
        val params = WindowManager.LayoutParams(width, height, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(90) }
        overlayParams = params
        windowManager.addView(root, params)

        overlayHost = JarvisWebViewHost(web).also { host ->
            host.attach(object : JarvisWebViewHost.Listener {
                override fun onCommand(text: String) = processOverlay(text)
                override fun onMic() = startOverlayMic()
                override fun onApprove() = processOverlayResult(container.brainTaskRunner.approve())
                override fun onCancel() = processOverlayResult(container.brainTaskRunner.cancel())
                override fun onOpenSettings() = openMainSettings()
            })
        }
        container.brainTaskRunner.setProgressListener { steps -> sendOverlayTasks(steps) }
        overlaySpeaker = JarvisSpeaker(this)
        overlayVoice = JarvisVoiceController(this, object : JarvisVoiceController.Listener {
            override fun onReady() {
                overlayHost?.send("voice", "Listening…", "LISTENING", true, true)
            }
            override fun onListening() {
                overlayHost?.send("voice", "I'm listening…", "LISTENING", true, true)
            }
            override fun onPartial(text: String) {
                overlayHost?.send("voice", text, "LISTENING", true, true)
            }
            override fun onResult(text: String) {
                processOverlay(text)
            }
            override fun onError(message: String) {
                overlayHost?.send("voice", message, "FAILED", true, true)
            }
        })
        drag.setOnTouchListener(object : View.OnTouchListener {
            var downX=0f; var downY=0f; var startX=0; var startY=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = overlayParams ?: return false
                return when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startX = p.x
                        startY = p.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (e.rawX - downX).toInt()
                        p.y = (startY + (e.rawY - downY).toInt()).coerceAtLeast(0)
                        runCatching { windowManager.updateViewLayout(root, p) }
                        true
                    }
                    else -> true
                }
            }
        })
        web.postDelayed({ web.requestFocus(); val imm=getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.showSoftInput(web, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) }, 180)
    }

    private fun processOverlay(raw: String) {
        if (raw.isBlank()) return
        overlayHost?.send("thinking", "Thinking…", "THINKING", true, true)
        scope.launch {
            val result = runCatching { container.brainTaskRunner.handle(raw, "foreground=${foregroundPackage ?: "unknown"}") }
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown"}") }
            withContext(Dispatchers.Main) { processOverlayResult(result) }
        }
    }

    private fun processOverlayResult(result: CommandResponse) {
        overlayHost?.send("response", result.message, result.state.name, true, true)
        if (result.state == CommandState.SUCCESS) overlaySpeaker?.speak(result.message)
    }

    private fun sendOverlayTasks(steps: List<com.kaifrza.jarvis.core.brain.BrainTaskRunner.StepView>) {
        val json=JSONArray(); steps.forEach{ s -> json.put(JSONObject().put("taskId",s.taskId).put("taskLabel",s.taskLabel).put("index",s.index).put("total",s.total).put("title",s.title).put("state",s.state)) }
        mainHandler.post { overlayHost?.send("task_progress", "", "RUNNING", true, true, json) }
    }

    private fun startOverlayMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            overlayHost?.send("response", "Mic permission Jarvis ko allow karo, sir.", "SETUP", true, true); return
        }
        overlayVoice?.start()
    }

    private fun openMainSettings() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    private fun hideAssistantOverlay() {
        overlayVoice?.destroy(); overlayVoice=null; overlaySpeaker?.shutdown(); overlaySpeaker=null
        overlayHost=null; overlayWebView?.destroy(); overlayWebView=null
        overlayRoot?.let { runCatching { windowManager.removeView(it) } }; overlayRoot=null; overlayParams=null
        container.brainTaskRunner.setProgressListener(null)
    }

    override fun onDestroy() {
        hideAssistantOverlay()
        bubble?.let { runCatching { windowManager.removeView(it) } }; bubble=null
        scope.cancel(); instance=null; super.onDestroy()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=radius.toFloat() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    private fun clickBestMatchingNode(text: String): Boolean {
        val target=normalize(text); val deadline=SystemClock.uptimeMillis()+1_800L
        while(SystemClock.uptimeMillis()<deadline){
            val root=rootInActiveWindow
            val node=root?.let{findNodes(it){n->n.isVisibleToUser&&normalize(n.text?.toString().orEmpty()).contains(target)}.firstOrNull()}
            if(node!=null&&clickNodeOrClickableParent(node))return true
            SystemClock.sleep(120)
        }
        return false
    }
    private fun clickNodeOrClickableParent(node: AccessibilityNodeInfo):Boolean{
        if(node.isClickable)return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent=node.parent
        repeat(6){if(parent?.isClickable==true)return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);parent=parent?.parent}
        return false
    }
    private fun scroll(forward:Boolean):Boolean{
        val root=rootInActiveWindow?:return false; val candidates=findNodes(root){it.isVisibleToUser&&it.isScrollable}
        return candidates.firstOrNull()?.performAction(if(forward)AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)==true
    }
    private fun findNodes(root:AccessibilityNodeInfo,predicate:(AccessibilityNodeInfo)->Boolean):List<AccessibilityNodeInfo>{
        val result=mutableListOf<AccessibilityNodeInfo>(); fun visit(node:AccessibilityNodeInfo){if(predicate(node))result+=node;for(i in 0 until node.childCount)node.getChild(i)?.let(::visit)};visit(root);return result
    }
    private fun normalize(value:String)=value.lowercase().replace(Regex("\\s+")," ").trim()
}
