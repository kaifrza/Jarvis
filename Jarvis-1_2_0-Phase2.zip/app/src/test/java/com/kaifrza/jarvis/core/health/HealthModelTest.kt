package com.kaifrza.jarvis.core.health

import org.junit.Assert.assertEquals
import org.junit.Test

class HealthModelTest {
    private fun item(id: String, ok: Boolean, required: Boolean) = HealthItem(id, id, ok, required, "hint")

    @Test fun missingRequiredItemMeansSetupNeeded() {
        val items = listOf(item("accessibility", false, true), item("dnd", true, false))
        assertEquals(Readiness.NEEDS_SETUP, HealthModel.readiness(items))
    }

    @Test fun missingOptionalItemOnlyDegrades() {
        val items = listOf(item("accessibility", true, true), item("dnd", false, false))
        assertEquals(Readiness.DEGRADED, HealthModel.readiness(items))
        assertEquals(listOf("dnd"), HealthModel.missing(items).map { it.id })
    }

    @Test fun everythingOkIsReady() {
        val items = listOf(item("accessibility", true, true), item("dnd", true, false))
        assertEquals(Readiness.READY, HealthModel.readiness(items))
        assertEquals("READY", HealthModel.label(Readiness.READY))
    }
}
