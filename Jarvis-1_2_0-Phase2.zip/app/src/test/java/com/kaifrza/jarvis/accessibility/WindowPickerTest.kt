package com.kaifrza.jarvis.accessibility

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WindowPickerTest {
    private val app = WindowLite(1, WindowPicker.TYPE_APPLICATION, active = false, area = 1_000_000)
    private val statusBar = WindowLite(2, WindowPicker.TYPE_SYSTEM, active = false, area = 20_000)
    private val ime = WindowLite(3, WindowPicker.TYPE_INPUT_METHOD, active = false, area = 400_000)
    private val overlayActive = WindowLite(4, WindowPicker.TYPE_ACCESSIBILITY_OVERLAY, active = true, area = 150_000)

    @Test fun overlayAndKeyboardAreNeverTheTarget() {
        // The user typed into the Jarvis panel: the overlay is the ACTIVE window, the app is not.
        val picked = WindowPicker.pick(listOf(overlayActive, ime, statusBar, app))
        assertEquals(app.id, picked?.id)
    }

    @Test fun activeAppWindowWins() {
        val activeApp = app.copy(active = true)
        assertEquals(activeApp.id, WindowPicker.pick(listOf(statusBar, activeApp))?.id)
    }

    @Test fun quickSettingsPanelIsPickedWhenActive() {
        val panel = WindowLite(5, WindowPicker.TYPE_SYSTEM, active = true, area = 900_000)
        assertEquals(panel.id, WindowPicker.pick(listOf(app, panel, statusBar))?.id)
    }

    @Test fun nothingUsableMeansNull() {
        assertNull(WindowPicker.pick(listOf(overlayActive, ime)))
    }

    @Test fun focusSettlesOnlyAfterOverlayLetsGo() {
        assertFalse(WindowPicker.idle(listOf(overlayActive, app), imeBlocksNow = false))
        assertTrue(WindowPicker.idle(listOf(app.copy(active = true), overlayActive.copy(active = false)), imeBlocksNow = false))
    }

    @Test fun keyboardBlocksOnlyRightAfterTypingInJarvis() {
        val appActive = app.copy(active = true)
        assertFalse(WindowPicker.idle(listOf(appActive, ime), imeBlocksNow = true))
        // The user's own keyboard in another app must not slow every command down.
        assertTrue(WindowPicker.idle(listOf(appActive, ime), imeBlocksNow = false))
    }
}
