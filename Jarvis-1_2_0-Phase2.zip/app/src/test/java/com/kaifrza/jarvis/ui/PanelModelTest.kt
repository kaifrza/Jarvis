package com.kaifrza.jarvis.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PanelModelTest {
    @Test fun orbStateFollowsCommandState() {
        assertEquals(OrbState.ERROR, PanelModel.orbFor("response", "FAILED"))
        assertEquals(OrbState.LISTENING, PanelModel.orbFor("voice", "LISTENING"))
        assertEquals(OrbState.THINKING, PanelModel.orbFor("thinking", "THINKING"))
        assertEquals(OrbState.ACTING, PanelModel.orbFor("task", "RUNNING"))
        assertEquals(OrbState.IDLE, PanelModel.orbFor("response", "SUCCESS"))
        assertEquals(OrbState.IDLE, PanelModel.orbFor("status", "READY"))
    }

    @Test fun busyStatesShowStopInsteadOfInput() {
        assertTrue(PanelModel.isBusy("THINKING"))
        assertTrue(PanelModel.isBusy("RUNNING"))
        assertFalse(PanelModel.isBusy("SUCCESS"))
        assertFalse(PanelModel.isBusy("WAITING_FOR_APPROVAL"))
        assertFalse(PanelModel.isBusy("CANCELLED"))
    }

    @Test fun headlinesAreFriendly() {
        assertEquals("Soch raha hoon…", PanelModel.headline("THINKING"))
        assertEquals("Aapki ijaazat chahiye.", PanelModel.headline("WAITING_FOR_APPROVAL"))
        assertEquals("Boliye, sir.", PanelModel.headline("READY"))
    }
}
