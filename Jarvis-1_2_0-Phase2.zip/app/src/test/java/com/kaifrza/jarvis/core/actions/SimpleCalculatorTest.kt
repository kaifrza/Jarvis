package com.kaifrza.jarvis.core.actions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SimpleCalculatorTest {
    @Test fun basicArithmetic() {
        assertEquals("6000", SimpleCalculator.evaluate("125 * 48"))
        assertEquals("2.5", SimpleCalculator.evaluate("10 / 4"))
        assertNull(SimpleCalculator.evaluate("5 / 0"))
        assertNull(SimpleCalculator.evaluate("hello"))
    }
}
