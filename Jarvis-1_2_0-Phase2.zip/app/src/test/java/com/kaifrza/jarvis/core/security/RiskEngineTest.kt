package com.kaifrza.jarvis.core.security

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.tools.ToolRegistry
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RiskEngineTest {
    private val engine = RiskEngine(ToolRegistry())

    private fun cmd(intent: IntentType, vararg params: Pair<String, String>) =
        JarvisCommand("1", "raw", intent, mapOf(*params))

    @Test fun commandsTheUserGaveRunDirectly() {
        assertFalse(engine.plan(cmd(IntentType.MAKE_CALL, "phone_number" to "9876543210")).requiresConfirmation)
        assertFalse(engine.plan(cmd(IntentType.UI_CLICK_TEXT, "text" to "Send")).requiresConfirmation)
    }

    @Test fun remoteModelCallsAndMessagesNeedApproval() {
        assertTrue(engine.plan(cmd(IntentType.MAKE_CALL, "phone_number" to "9876543210"), untrusted = true).requiresConfirmation)
        assertTrue(engine.plan(cmd(IntentType.SEND_MESSAGE, "phone_number" to "9876543210", "message" to "hi"), untrusted = true).requiresConfirmation)
    }

    @Test fun remoteModelSensitiveClicksNeedApproval() {
        listOf("Send", "Pay now", "Delete", "Confirm order", "Buy").forEach { label ->
            assertTrue(label, engine.plan(cmd(IntentType.UI_CLICK_TEXT, "text" to label), untrusted = true).requiresConfirmation)
        }
    }

    @Test fun remoteModelHarmlessActionsStillRunDirectly() {
        assertFalse(engine.plan(cmd(IntentType.SET_VOLUME, "mode" to "up"), untrusted = true).requiresConfirmation)
        assertFalse(engine.plan(cmd(IntentType.OPEN_APP, "app_name" to "YouTube"), untrusted = true).requiresConfirmation)
        assertFalse(engine.plan(cmd(IntentType.UI_CLICK_TEXT, "text" to "Settings"), untrusted = true).requiresConfirmation)
    }
}
