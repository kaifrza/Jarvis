package com.kaifrza.jarvis.core.assistant

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryLabelTest {
    private val secret = "meri bank pin 1234 hai"

    @Test fun typedTextIsNeverStored() {
        val label = HistoryLabel.of(JarvisCommand("1", "likho $secret", IntentType.UI_TYPE_TEXT, mapOf("text" to secret)))
        assertFalse(label.contains("1234"))
        assertTrue(label.contains("chars"))
    }

    @Test fun messageBodiesAreNeverStored() {
        val send = JarvisCommand("2", "Zubair ko message bhejo: $secret", IntentType.SEND_MESSAGE,
            mapOf("contact_name" to "zubair", "message" to secret))
        assertEquals("Send message to zubair", HistoryLabel.of(send))
        val click = JarvisCommand("3", "WhatsApp zubair $secret", IntentType.UI_CLICK_TEXT,
            mapOf("text" to "Send", "message_preview" to secret))
        assertEquals("Send message", HistoryLabel.of(click))
    }

    @Test fun unknownCommandsAreNotStoredVerbatim() {
        val label = HistoryLabel.of(JarvisCommand("4", secret, IntentType.UNKNOWN))
        assertFalse(label.contains("1234"))
    }
}
