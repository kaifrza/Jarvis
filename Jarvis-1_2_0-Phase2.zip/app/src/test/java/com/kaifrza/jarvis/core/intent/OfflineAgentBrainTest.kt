package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.IntentType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineAgentBrainTest {
    private val brain = OfflineAgentBrain()

    @Test fun app_open_phrasing_variants() {
        listOf("YouTube kholo", "youtube open", "Open YouTube", "youtube chalu kro", "youtube launch karo")
            .forEach { text -> assertEquals(IntentType.OPEN_APP, brain.plan(text).steps.single().command.intent) }
    }

    @Test fun system_toggle_phrasing_variants() {
        assertEquals(IntentType.TOGGLE_MOBILE_DATA, brain.plan("network on kro").steps.single().command.intent)
        assertEquals("true", brain.plan("network chalu kro").steps.single().command.parameters["enabled"])
        assertEquals(IntentType.TOGGLE_WIFI, brain.plan("Wi-Fi band karo").steps.single().command.intent)
        assertEquals("false", brain.plan("Wi-Fi band karo").steps.single().command.parameters["enabled"])
        assertEquals(IntentType.TOGGLE_BLUETOOTH, brain.plan("bluetooth on karo").steps.single().command.intent)
    }

    @Test fun independent_tasks_are_kept_in_separate_lanes() {
        val plan = brain.plan("Chrome kholo aur Google par YouTube search karo saath hi Calculator kholo aur 125 x 48 calculate karo")
        assertEquals(4, plan.steps.size)
        assertEquals(listOf("task-1", "task-1", "task-2", "task-2"), plan.steps.map { it.taskId })
        assertEquals(IntentType.OPEN_APP, plan.steps[0].command.intent)
        assertEquals(IntentType.UI_SEARCH, plan.steps[1].command.intent)
        assertEquals(IntentType.OPEN_APP, plan.steps[2].command.intent)
        assertEquals(IntentType.CALCULATE, plan.steps[3].command.intent)
        assertEquals("125 * 48", plan.steps[3].command.parameters["expression"])
    }

    @Test fun whatsapp_workflow_ends_with_send_click_and_keeps_preview() {
        val plan = brain.plan("WhatsApp kholo, chat me Hasnain search kro or usko bolo main 5 minutes me aa raha hu")
        assertEquals(7, plan.steps.size)
        assertEquals(IntentType.OPEN_APP, plan.steps[0].command.intent)
        assertEquals(IntentType.UI_CLICK_TEXT, plan.steps[1].command.intent)
        assertEquals(IntentType.UI_TYPE_TEXT, plan.steps[2].command.intent)
        assertEquals("hasnain", plan.steps[2].command.parameters["text"])
        val send = plan.steps.last().command
        assertEquals(IntentType.UI_CLICK_TEXT, send.intent)
        assertEquals("Send", send.parameters["text"])
        assertEquals("main 5 minutes me aa raha hu", send.parameters["message_preview"])
        assertTrue(send.parameters["message_preview"]!!.isNotBlank())
    }

    @Test fun dictated_message_with_conjunction_is_not_split() {
        val step = brain.plan("Zubair ko message bhejo: main aur tum kal milenge").steps.single().command
        assertEquals(IntentType.SEND_MESSAGE, step.intent)
        assertEquals("main aur tum kal milenge", step.parameters["message"])
        val then = brain.plan("Zubair ko message bhejo: pehle chai pi lo then aa jana").steps.single().command
        assertEquals("pehle chai pi lo then aa jana", then.parameters["message"])
    }

    @Test fun names_joined_by_and_stay_one_call() {
        val step = brain.plan("Rahul and Priya ko call karo").steps.single().command
        assertEquals(IntentType.MAKE_CALL, step.intent)
    }

    @Test fun ordinary_sentences_are_not_turned_into_ui_actions() {
        listOf(
            "what is the best type of laptop",
            "meri laptop ki battery kharab hai",
            "entertainment ke baare mein batao"
        ).forEach { text -> assertTrue(text, brain.plan(text).steps.isEmpty()) }
    }

    @Test fun half_understood_chain_does_not_run_partially() {
        assertTrue(brain.plan("restart karo aur wifi band karo").steps.isEmpty())
    }

    @Test fun anchored_ui_clauses() {
        val search = brain.plan("Google par cricket score search karo").steps.single().command
        assertEquals(IntentType.UI_SEARCH, search.intent)
        assertEquals("cricket score", search.parameters["query"])
        val click = brain.plan("Settings pe click karo").steps.single().command
        assertEquals(IntentType.UI_CLICK_TEXT, click.intent)
        assertEquals("Settings", click.parameters["text"])
        val type = brain.plan("likho hello").steps.single().command
        assertEquals(IntentType.UI_TYPE_TEXT, type.intent)
        assertEquals("down", brain.plan("neeche scroll karo").steps.single().command.parameters["direction"])
    }

    @Test fun chained_known_commands_still_split() {
        val plan = brain.plan("WhatsApp kholo aur phir back jao")
        assertEquals(listOf(IntentType.OPEN_APP, IntentType.NAVIGATE_BACK), plan.steps.map { it.command.intent })
    }
}
