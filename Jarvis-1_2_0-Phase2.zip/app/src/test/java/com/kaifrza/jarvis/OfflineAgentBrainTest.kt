package com.kaifrza.jarvis

import com.kaifrza.jarvis.core.intent.OfflineAgentBrain
import com.kaifrza.jarvis.core.model.IntentType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineAgentBrainTest {
    @Test fun plansWhatsappMessageOffline() {
        val plan = OfflineAgentBrain().plan("WhatsApp kholo, chat me Hasnain search kro or us bolo bolo mai 5 minutes me aa rha hu")
        assertEquals("offline-agent", plan.source)
        assertEquals(IntentType.OPEN_APP, plan.steps[0].command.intent)
        assertEquals("WhatsApp", plan.steps[0].command.parameters["app_name"])
        assertTrue(plan.steps.any { it.command.intent == IntentType.UI_CLICK_TEXT && it.command.parameters["text"] == "Search" })
        assertTrue(plan.steps.any { it.command.intent == IntentType.UI_TYPE_TEXT && it.command.parameters["text"] == "hasnain" })
        assertTrue(plan.steps.any { it.command.intent == IntentType.UI_TYPE_TEXT && it.command.parameters["text"] == "mai 5 minutes me aa rha hu" })
        val send = plan.steps.last().command
        assertEquals(IntentType.UI_CLICK_TEXT, send.intent)
        assertEquals("Send", send.parameters["text"])
        assertEquals("mai 5 minutes me aa rha hu", send.parameters["message_preview"])
    }
}
