package com.kaifrza.jarvis.core.tools

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolRegistryTest {
    private val registry = ToolRegistry()

    @Test fun volumeAndBrightnessNeedLevelOrMode() {
        listOf("android_set_volume", "android_set_brightness").forEach { id ->
            assertFalse(id, registry.validate(ToolCall(id, emptyMap())).valid)
            assertTrue(id, registry.validate(ToolCall(id, mapOf("mode" to "up"))).valid)
            assertTrue(id, registry.validate(ToolCall(id, mapOf("level" to "30"))).valid)
        }
    }

    @Test fun callNeedsATarget() {
        assertFalse(registry.validate(ToolCall("communication_call", emptyMap())).valid)
        assertTrue(registry.validate(ToolCall("communication_call", mapOf("phone_number" to "9876543210"))).valid)
    }
}
