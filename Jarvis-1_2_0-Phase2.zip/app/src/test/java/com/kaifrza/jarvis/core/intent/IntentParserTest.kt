package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.IntentType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IntentParserTest {
    private val parser = IntentParser()

    @Test fun understandsOpenAppVariants() {
        listOf(
            "YouTube kholo",
            "YT open karo",
            "please open WhatsApp",
            "Instagram chalao",
            "Chrome launch karo",
            "calculator kholo",
            "open Settings"
        ).forEach { text ->
            assertEquals(IntentType.OPEN_APP, parser.parse(text).intent)
        }
    }

    @Test fun understandsNavigationVariants() {
        assertEquals(IntentType.NAVIGATE_BACK, parser.parse("wapas jao").intent)
        assertEquals(IntentType.NAVIGATE_BACK, parser.parse("previous page").intent)
        assertEquals(IntentType.HOME, parser.parse("home screen kholo").intent)
        assertEquals(IntentType.RECENTS, parser.parse("recent apps kholo").intent)
        assertEquals(IntentType.OPEN_NOTIFICATIONS, parser.parse("notifications dikhao").intent)
    }

    @Test fun extractsCallTarget() {
        assertEquals("zubair", parser.parse("Zubair ko call karo").parameters["contact_name"])
        assertEquals("zubair", parser.parse("mujhe Zubair ko phone lagao").parameters["contact_name"])
    }


    @Test fun extractsDirectPhoneNumber() {
        val a = parser.parse("9876543210 par call karo")
        assertEquals(IntentType.MAKE_CALL, a.intent)
        assertEquals("9876543210", a.parameters["phone_number"])

        val b = parser.parse("call +91 98765 43210")
        assertEquals(IntentType.MAKE_CALL, b.intent)
        assertEquals("919876543210", b.parameters["phone_number"])
    }

    @Test fun extractsMessageTargetAndBody() {
        val cases = listOf(
            "Zubair ko message bhejo: Main aa raha hoon" to ("zubair" to "Main aa raha hoon"),
            "message Zubair: Main aa raha hoon" to ("zubair" to "Main aa raha hoon"),
            "send a message to Zubair saying I am coming" to ("zubair" to "I am coming"),
            "Zubair ko sms karo: Kal milte hain" to ("zubair" to "Kal milte hain"),
            "Zubair ko msg bhejo Main aa raha hoon" to ("zubair" to "Main aa raha hoon")
        )

        cases.forEach { (input, expected) ->
            val command = parser.parse(input)
            assertEquals(IntentType.SEND_MESSAGE, command.intent)
            assertEquals(expected.first, command.parameters["contact_name"])
            assertEquals(expected.second, command.parameters["message"])
        }
    }

    @Test fun doesNotTreatOrdinaryYoutubeSentenceAsOpenApp() {
        val command = parser.parse("I watch youtube every day")
        assertTrue(command.intent != IntentType.OPEN_APP)
    }

    @Test fun dialerAndCallLogAreNotCalls() {
        listOf("dialer kholo", "call log kholo", "caller id kholo", "phone kholo").forEach { text ->
            assertEquals(text, IntentType.OPEN_APP, parser.parse(text).intent)
        }
        assertEquals("dialer", parser.parse("dialer kholo").parameters["app_name"])
        assertEquals("dialer", parser.parse("call log kholo").parameters["app_name"])
        assertTrue(parser.parse("missed call dikhao").intent != IntentType.MAKE_CALL)
    }

    @Test fun relativeVolumeAndBrightnessAreNotTurnedInto50Percent() {
        val up = parser.parse("volume badhao")
        assertEquals(IntentType.SET_VOLUME, up.intent)
        assertEquals("up", up.parameters["mode"])
        assertEquals("down", parser.parse("volume kam karo").parameters["mode"])
        assertEquals("10", parser.parse("volume thoda badhao").parameters["delta"])
        val absolute = parser.parse("volume 70")
        assertEquals("set", absolute.parameters["mode"])
        assertEquals("70", absolute.parameters["level"])
        assertEquals("0", parser.parse("volume mute").parameters["level"])
        val bright = parser.parse("brightness thodi badhao")
        assertEquals(IntentType.SET_BRIGHTNESS, bright.intent)
        assertEquals("up", bright.parameters["mode"])
        assertEquals("100", parser.parse("brightness full").parameters["level"])
    }

    @Test fun messagesAppIsOpenedNotComposed() {
        assertEquals(IntentType.OPEN_APP, parser.parse("messages kholo").intent)
        assertEquals(IntentType.OPEN_APP, parser.parse("sms kholo").intent)
    }

    @Test fun startInsideAnotherWordIsNotAnOpenVerb() {
        assertTrue(parser.parse("restart karo").intent != IntentType.OPEN_APP)
    }

    @Test fun connectivityToggleVariants() {
        val off = parser.parse("wifi ko band karo")
        assertEquals(IntentType.TOGGLE_WIFI, off.intent)
        assertEquals("false", off.parameters["enabled"])
        assertEquals(IntentType.TOGGLE_MOBILE_DATA, parser.parse("mobile data band karo").intent)
        assertEquals(IntentType.OPEN_WIFI_SETTINGS, parser.parse("wifi settings kholo").intent)
    }

    @Test fun alarmPhrasing() {
        val a = parser.parse("alarm 7 baje")
        assertEquals(IntentType.CREATE_ALARM, a.intent)
        assertEquals("7", a.parameters["hour"])
        assertEquals("pm", parser.parse("alarm shaam 6 baje laga do").parameters["ampm"])
        assertEquals("am", parser.parse("alarm subah 6:30").parameters["ampm"])
        assertEquals("30", parser.parse("alarm subah 6:30").parameters["minute"])
        assertTrue(parser.parse("alarm cancel karo").intent != IntentType.CREATE_ALARM)
    }

    @Test fun backVariants() {
        listOf("back jao", "piche jao", "peeche jaao", "wapas jao").forEach { text ->
            assertEquals(text, IntentType.NAVIGATE_BACK, parser.parse(text).intent)
        }
        assertTrue(parser.parse("back camera kholo").intent != IntentType.NAVIGATE_BACK)
    }

    @Test fun volumeStreamsAreRecognised() {
        val call = parser.parse("call ka volume badhao")
        assertEquals(IntentType.SET_VOLUME, call.intent)
        assertEquals("call", call.parameters["stream"])
        assertEquals("up", call.parameters["mode"])
        val ring = parser.parse("ringtone ki awaaz kam karo")
        assertEquals("ring", ring.parameters["stream"])
        assertEquals("down", ring.parameters["mode"])
        val alarm = parser.parse("alarm volume 50")
        assertEquals(IntentType.SET_VOLUME, alarm.intent)
        assertEquals("alarm", alarm.parameters["stream"])
        assertEquals("50", alarm.parameters["level"])
        assertEquals("notification", parser.parse("notification volume mute").parameters["stream"])
        assertEquals("0", parser.parse("notification volume mute").parameters["level"])
        assertEquals("media", parser.parse("volume badhao").parameters["stream"])
        assertEquals("unmute", parser.parse("volume unmute karo").parameters["mode"])
    }

    @Test fun ringerModesAndDnd() {
        assertEquals("silent", parser.parse("silent kar do").parameters["mode"])
        assertEquals("vibrate", parser.parse("vibrate kar do").parameters["mode"])
        assertEquals("vibrate", parser.parse("vibration on karo").parameters["mode"])
        assertEquals("normal", parser.parse("silent mode off karo").parameters["mode"])
        val ringMode = parser.parse("ring mode normal karo")
        assertEquals(IntentType.SET_RINGER_MODE, ringMode.intent)
        assertEquals("normal", ringMode.parameters["mode"])
        val dnd = parser.parse("do not disturb off karo")
        assertEquals(IntentType.SET_DND, dnd.intent)
        assertEquals("false", dnd.parameters["enabled"])
        assertEquals("true", parser.parse("dnd on karo").parameters["enabled"])
    }

    @Test fun rotationAndAutoBrightness() {
        assertEquals("true", parser.parse("auto rotate off karo").parameters["locked"])
        assertEquals("false", parser.parse("auto rotate on karo").parameters["locked"])
        assertEquals("true", parser.parse("rotation lock on karo").parameters["locked"])
        assertEquals("false", parser.parse("portrait lock off karo").parameters["locked"])
        val auto = parser.parse("auto brightness band karo")
        assertEquals(IntentType.SET_AUTO_BRIGHTNESS, auto.intent)
        assertEquals("false", auto.parameters["enabled"])
        assertEquals(IntentType.SET_BRIGHTNESS, parser.parse("brightness 40").intent)
    }

    @Test fun panelTilesAndConnectivity() {
        assertEquals(IntentType.TOGGLE_AIRPLANE, parser.parse("airplane mode on karo").intent)
        assertEquals("false", parser.parse("flight mode band karo").parameters["enabled"])
        assertEquals(IntentType.TOGGLE_HOTSPOT, parser.parse("hotspot on karo").intent)
        assertEquals(IntentType.TOGGLE_LOCATION, parser.parse("location band karo").intent)
        val eye = parser.parse("eye protection on karo")
        assertEquals(IntentType.TOGGLE_QS_TILE, eye.intent)
        assertEquals("eye protection", eye.parameters["tile"])
        assertEquals("true", eye.parameters["enabled"])
        assertEquals("low power mode", parser.parse("battery saver on").parameters["tile"])
        assertEquals("super battery saver", parser.parse("super battery saver chalu karo").parameters["tile"])
        assertEquals("dark mode", parser.parse("dark mode band karo").parameters["tile"])
    }

    @Test fun hindiAndSpellingVariants() {
        val v = parser.parse("वॉल्यूम बढ़ाओ")
        assertEquals(IntentType.SET_VOLUME, v.intent)
        assertEquals("up", v.parameters["mode"])
        val wifi = parser.parse("wify on kro")
        assertEquals(IntentType.TOGGLE_WIFI, wifi.intent)
        assertEquals("true", wifi.parameters["enabled"])
        assertEquals("false", parser.parse("वाईफाई बंद करो").parameters["enabled"])
        assertEquals(IntentType.SET_FLASHLIGHT, parser.parse("tourch on kro").intent)
        assertEquals(IntentType.SET_RINGER_MODE, parser.parse("साइलेंट कर दो").intent)
    }

    @Test fun callStillWorksAndCallVolumeIsNotACall() {
        assertEquals(IntentType.MAKE_CALL, parser.parse("Zubair ko call karo").intent)
        assertTrue(parser.parse("call volume kam karo").intent != IntentType.MAKE_CALL)
    }
}
