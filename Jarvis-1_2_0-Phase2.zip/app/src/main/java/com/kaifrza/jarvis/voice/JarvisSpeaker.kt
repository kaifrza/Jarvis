package com.kaifrza.jarvis.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class JarvisSpeaker(
    context: Context,
    private val onReady: (() -> Unit)? = null
) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    @Volatile private var ready = false
    @Volatile private var pending: String? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            ready = true
            // The first reply is often requested before the engine finished starting.
            pending?.let { tts.speak(it, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response") }
            pending = null
            onReady?.invoke()
        }
    }

    fun speak(text: String) {
        if (!ready) {
            pending = text
            return
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
