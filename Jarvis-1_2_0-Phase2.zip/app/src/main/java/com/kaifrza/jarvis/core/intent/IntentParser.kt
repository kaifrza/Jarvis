package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import java.util.Locale
import java.util.UUID

/**
 * Offline-first language normalizer. It intentionally accepts English + Roman Urdu/Hinglish
 * variants and maps them into stable structured commands. The execution layer never parses text.
 */
class IntentParser {
    fun parse(raw: String): JarvisCommand {
        val text = raw.trim().replace(Regex("\\s+"), " ")
        val n = normalize(text)
        val intent = when {
            isCancel(n) -> IntentType.UNKNOWN
            isReadNotifications(n) -> IntentType.READ_NOTIFICATIONS
            isNotifications(n) -> IntentType.OPEN_NOTIFICATIONS
            isBack(n) -> IntentType.NAVIGATE_BACK
            isHome(n) -> IntentType.HOME
            isRecents(n) -> IntentType.RECENTS
            isOpenMessagesApp(n) -> IntentType.OPEN_APP
            looksLikeMessage(n) -> IntentType.SEND_MESSAGE
            looksLikeCall(n) -> IntentType.MAKE_CALL
            looksLikeCalculate(n) -> IntentType.CALCULATE
            looksLikeAutoBrightness(n) -> IntentType.SET_AUTO_BRIGHTNESS
            looksLikeRotation(n) -> IntentType.SET_ROTATION_LOCK
            looksLikeDnd(n) -> IntentType.SET_DND
            looksLikeRinger(n) -> IntentType.SET_RINGER_MODE
            looksLikeAirplane(n) -> IntentType.TOGGLE_AIRPLANE
            looksLikeHotspot(n) -> IntentType.TOGGLE_HOTSPOT
            looksLikeLocation(n) -> IntentType.TOGGLE_LOCATION
            genericTileName(n) != null -> IntentType.TOGGLE_QS_TILE
            looksLikeBrightness(n) -> IntentType.SET_BRIGHTNESS
            looksLikeVolume(n) -> IntentType.SET_VOLUME
            looksLikeMedia(n) -> mediaIntent(n)
            looksLikeWifiToggle(n) -> IntentType.TOGGLE_WIFI
            looksLikeBluetoothToggle(n) -> IntentType.TOGGLE_BLUETOOTH
            looksLikeNetworkToggle(n) -> IntentType.TOGGLE_MOBILE_DATA
            looksLikeNetwork(n) -> IntentType.OPEN_NETWORK_SETTINGS
            looksLikeWifi(n) -> IntentType.OPEN_WIFI_SETTINGS
            looksLikeBluetooth(n) -> IntentType.OPEN_BLUETOOTH_SETTINGS
            looksLikeFlashlight(n) -> IntentType.SET_FLASHLIGHT
            looksLikeAlarm(n) -> IntentType.CREATE_ALARM
            looksLikeScreenRead(n) -> IntentType.ACCESS_SCREEN
            looksLikeOpenApp(n) -> IntentType.OPEN_APP
            else -> IntentType.UNKNOWN
        }

        val params = when (intent) {
            IntentType.OPEN_APP -> extractAppName(n)?.let { mapOf("app_name" to it) } ?: emptyMap()
            IntentType.CALCULATE -> mapOf("expression" to extractExpression(text))
            IntentType.SET_FLASHLIGHT -> mapOf("enabled" to if (looksLikeOff(n)) "false" else "true")
            IntentType.TOGGLE_WIFI, IntentType.TOGGLE_MOBILE_DATA, IntentType.TOGGLE_BLUETOOTH -> mapOf("enabled" to if (looksLikeOff(n)) "false" else "true")
            IntentType.SET_VOLUME -> levelParams(n, allowMute = true) + ("stream" to volumeStream(n))
            IntentType.SET_AUTO_BRIGHTNESS -> mapOf("enabled" to if (looksLikeOff(n)) "false" else "true")
            IntentType.SET_ROTATION_LOCK -> mapOf("locked" to rotationLocked(n).toString())
            IntentType.SET_DND -> buildMap {
                put("enabled", if (looksLikeOff(n)) "false" else "true")
                if (Regex("\\balarms?\\s+only\\b").containsMatchIn(n)) put("level", "alarms")
                if (Regex("\\btotal\\b").containsMatchIn(n)) put("level", "total")
            }
            IntentType.SET_RINGER_MODE -> mapOf("mode" to ringerMode(n))
            IntentType.TOGGLE_AIRPLANE, IntentType.TOGGLE_HOTSPOT, IntentType.TOGGLE_LOCATION ->
                mapOf("enabled" to if (looksLikeOff(n)) "false" else "true")
            IntentType.TOGGLE_QS_TILE -> buildMap {
                put("tile", genericTileName(n).orEmpty())
                if (stateRegex.containsMatchIn(n)) put("enabled", if (looksLikeOff(n)) "false" else "true")
            }
            IntentType.SET_BRIGHTNESS -> levelParams(n, allowMute = false)
            IntentType.PLAY_MEDIA -> emptyMap()
            IntentType.PAUSE_MEDIA -> emptyMap()
            IntentType.STOP_MEDIA -> emptyMap()
            IntentType.NEXT_MEDIA -> emptyMap()
            IntentType.PREVIOUS_MEDIA -> emptyMap()
            IntentType.CREATE_ALARM -> extractAlarmParams(n)
            IntentType.MAKE_CALL -> extractCallParams(text, n)
            IntentType.SEND_MESSAGE -> {
                val target = extractMessageTarget(n)
                val body = extractMessageBody(text)
                buildMap {
                    if (target != null) put("contact_name", target)
                    target?.let { extractPhoneNumber(it)?.let { number -> put("phone_number", number) } }
                    if (body != null) put("message", body)
                }
            }
            else -> emptyMap()
        }

        return JarvisCommand(UUID.randomUUID().toString(), text, intent, params)
    }

    private val canon: Map<String, String> = mapOf(
        "badaao" to "badhao", "badhaao" to "badhao", "bdhao" to "badhao", "badao" to "badhao",
        "kum" to "kam", "chaalu" to "chalu", "kro" to "karo", "kijiye" to "karo", "kijiyega" to "karo",
        "khole" to "kholo", "kholiye" to "kholo", "kholen" to "kholo",
        "niche" to "neeche", "nichey" to "neeche", "neechey" to "neeche", "oopar" to "upar", "ooper" to "upar", "upr" to "upar",
        "peeche" to "piche", "pichhe" to "piche", "pechhe" to "piche", "vapas" to "wapas", "waapas" to "wapas", "wapis" to "wapas",
        "vibration" to "vibrate", "vibrating" to "vibrate", "vibrator" to "vibrate", "sailent" to "silent", "silant" to "silent",
        "tourch" to "torch", "torchh" to "torch", "bluetoth" to "bluetooth", "blutooth" to "bluetooth", "bleutooth" to "bluetooth",
        "wify" to "wifi", "waifai" to "wifi", "brightnes" to "brightness", "alaram" to "alarm", "awaaj" to "awaaz",
        // Hindi (Devanagari) voice typing
        "खोलो" to "kholo", "खोल" to "khol", "चालू" to "chalu", "बंद" to "band", "पीछे" to "piche", "वापस" to "wapas",
        "कॉल" to "call", "वॉल्यूम" to "volume", "आवाज़" to "awaaz", "आवाज" to "awaaz", "बढ़ाओ" to "badhao", "बढ़ा" to "badhao",
        "घटाओ" to "kam", "कम" to "kam", "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "वाईफाई" to "wifi",
        "ब्लूटूथ" to "bluetooth", "टॉर्च" to "torch", "नीचे" to "neeche", "ऊपर" to "upar", "स्क्रॉल" to "scroll",
        "होम" to "home", "बैक" to "back", "साइलेंट" to "silent", "वाइब्रेट" to "vibrate", "रिंगटोन" to "ringtone",
        "अलार्म" to "alarm", "नोटिफिकेशन" to "notification", "ब्राइटनेस" to "brightness", "करो" to "karo", "कर" to "karo",
        "दो" to "do", "ऑन" to "on", "ऑफ" to "off", "लोकेशन" to "location", "हॉटस्पॉट" to "hotspot",
        "एयरप्लेन" to "airplane", "मोड" to "mode"
    )

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace('’', '\'').replace('“', '"').replace('”', '"')
        .replace(Regex("[!?]+$"), "").trim()
        .split(Regex("\\s+")).joinToString(" ") { canon[it] ?: it }

    private fun isCancel(n: String) = n in setOf("cancel", "cancel karo", "cancel kar do", "rehne do", "chhodo", "stop this", "stop karo")

    private val backRegex = Regex("^(?:go\\s+)?(?:back|piche|peeche|pichhe|wapas|wapis|vapas)(?:\\s+(?:jao|jaao|chalo|ja|karo|kro))?$")
    private fun isBack(n: String) = backRegex.matches(n) || n.contains("previous page") || n.contains("pichle page")
    private fun isHome(n: String) = n in setOf("home", "home jao", "home kholo", "home screen", "home screen kholo") || n.contains("home screen par") || n.contains("ghar screen")
    private fun isRecents(n: String) = n.contains("recent apps") || n == "recents" || n.contains("recent kholo") || n.contains("recent dikhao")
    private fun isNotifications(n: String) = n.contains("notification kholo") || n.contains("notifications kholo") || n.contains("notification dikhao") || n.contains("notifications dikhao") || n.contains("notification panel") || n.contains("notification shade")
    private fun isReadNotifications(n: String) = (n.contains("notification") && (n.contains("read") || n.contains("batao") || n.contains("padho") || n.contains("dekho") || n.contains("important")))
    private fun looksLikeScreenRead(n: String) = n.contains("screen") && (n.contains("read") || n.contains("dekho") || n.contains("batao") || n.contains("kya hai"))

    private fun looksLikeCalculate(n: String) = n.matches(Regex(".*\\b(calculate|calc|hisab|kitna|multiply|plus|minus|divide|times|into|x)\\b.*[0-9].*")) || n.matches(Regex(".*[0-9]+\\s*[+x×*\\-/]\\s*[0-9]+.*"))
    private fun extractExpression(text: String): String = text
        .replace(Regex("(?i)\\b(calculate|calc|hisab|kitna|please|karo|kar do|batao|result|nikalo)\\b"), " ")
        .replace(Regex("(?i)\\b(multiply|times|into)\\b"), "*")
        .replace(Regex("(?i)\\b(plus)\\b"), "+")
        .replace(Regex("(?i)\\b(minus)\\b"), "-")
        .replace(Regex("(?i)\\b(divide|divided by)\\b"), "/")
        .replace('×','*').replace(Regex("\\s+x\\s+", RegexOption.IGNORE_CASE), " * ")
        .replace(Regex("\\s+"), " ").trim()

    // ---------------------------------------------------------------- volume / brightness

    private fun looksLikeVolume(n: String) = Regex("\\b(volume|awaz|awaaz|aawaz|avaz|sound|louder|loud)\\b").containsMatchIn(n)
    private fun looksLikeBrightness(n: String) = n.contains("brightness") || n.contains("screen light") || n.contains("display light") || n.contains("roshni")

    /**
     * Produces mode/level/delta so relative commands ("volume badhao") change the current value
     * instead of being silently turned into an absolute 50%.
     */
    private fun levelParams(n: String, allowMute: Boolean): Map<String, String> {
        val explicit = Regex("(?<!\\d)(\\d{1,3})\\s*(?:%|percent|pc)?").find(n)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (explicit != null) return mapOf("mode" to "set", "level" to explicit.coerceIn(0, 100).toString())
        if (Regex("\\b(full|max|maximum|puri|poori|pura|hundred)\\b").containsMatchIn(n)) return mapOf("mode" to "set", "level" to "100")
        if (allowMute && Regex("\\bunmute\\b|\\bmute\\s+(?:off|hatao|hata)\\b").containsMatchIn(n)) return mapOf("mode" to "unmute")
        if (allowMute && Regex("\\b(mute|silent|zero)\\b").containsMatchIn(n)) return mapOf("mode" to "set", "level" to "0")
        if (Regex("\\b(min|minimum|lowest)\\b").containsMatchIn(n)) return mapOf("mode" to "min")
        val delta = when {
            Regex("\\b(thoda|thodi|zara|little|slightly)\\b").containsMatchIn(n) -> "10"
            Regex("\\b(bahut|bohot|kaafi|much|lot)\\b").containsMatchIn(n) -> "40"
            else -> "20"
        }
        return when {
            Regex("\\b(badhao|badhaao|badao|bdhao|badha|increase|up|zyada|tez|louder|high|higher|raise)\\b").containsMatchIn(n) ->
                mapOf("mode" to "up", "delta" to delta)
            Regex("\\b(kam|kum|ghatao|ghata|decrease|down|dheere|low|lower|halka|halke|reduce)\\b").containsMatchIn(n) ->
                mapOf("mode" to "down", "delta" to delta)
            else -> mapOf("mode" to "get")
        }
    }

    private fun looksLikeMedia(n: String) = n in setOf("play", "pause", "stop music", "next", "next song", "previous", "previous song", "agla gana", "pichla gana") || n.contains("play music") || n.contains("pause music") || n.contains("next song") || n.contains("previous song")
    private fun mediaIntent(n: String) = when {
        n.contains("pause") -> IntentType.PAUSE_MEDIA
        n.contains("stop") -> IntentType.STOP_MEDIA
        n.contains("next") || n.contains("agla") -> IntentType.NEXT_MEDIA
        n.contains("previous") || n.contains("pichla") -> IntentType.PREVIOUS_MEDIA
        else -> IntentType.PLAY_MEDIA
    }

    // ---------------------------------------------------------------- connectivity

    private val offRegex = Regex("\\b(off|band|bandh|bujha|bujhao|disable|disabled)\\b")
    private val stateRegex = Regex("\\b(on|off|chalu|chaalu|chalao|band|bandh|enable|disable|disabled|bujha|bujhao)\\b")
    private val wifiName = Regex("\\bwi-?\\s?fi\\b|\\bwlan\\b")
    private val bluetoothName = Regex("\\bblue\\s?tooth\\b|\\bbt\\b")
    private val networkName = Regex("\\b(?:mobile\\s+data|network|internet|data)\\b")

    private fun looksLikeOff(n: String) = offRegex.containsMatchIn(n)
    private fun isToggle(n: String, name: Regex) = name.containsMatchIn(n) && stateRegex.containsMatchIn(n) && !n.contains("settings")
    private fun looksLikeWifiToggle(n: String) = isToggle(n, wifiName)
    private fun looksLikeBluetoothToggle(n: String) = isToggle(n, bluetoothName)
    private fun looksLikeNetworkToggle(n: String) = isToggle(n, networkName)
    private fun looksLikeNetwork(n: String) = listOf("network settings", "internet settings", "mobile data settings").any(n::contains)
    private fun looksLikeWifi(n: String) = wifiName.containsMatchIn(n) && (n.contains("settings") || hasOpenVerb(n))
    private fun looksLikeBluetooth(n: String) = bluetoothName.containsMatchIn(n) && (n.contains("settings") || hasOpenVerb(n))
    private fun looksLikeFlashlight(n: String) = listOf("flashlight", "torch", "flash light").any(n::contains)

    // ---------------------------------------------------------------- Phase 2 controls

    /** media (default) / ring / alarm / notification / call / system */
    private fun volumeStream(n: String): String = when {
        Regex("\\b(ringtone|ringer|ring)\\b").containsMatchIn(n) -> "ring"
        Regex("\\balarm\\b").containsMatchIn(n) -> "alarm"
        Regex("\\b(notification|notifications|notif)\\b").containsMatchIn(n) -> "notification"
        Regex("\\b(call|calling|incall|in-call)\\b").containsMatchIn(n) -> "call"
        Regex("\\bsystem\\b").containsMatchIn(n) -> "system"
        else -> "media"
    }

    private val ringerWord = Regex("\\b(silent|vibrate|ringer|ring mode|normal mode|sound mode|general mode)\\b")
    private fun looksLikeRinger(n: String) = ringerWord.containsMatchIn(n) && !looksLikeVolume(n)
    private fun ringerMode(n: String): String {
        val off = looksLikeOff(n)
        return when {
            n.contains("silent") -> if (off) "normal" else "silent"
            n.contains("vibrate") -> if (off) "normal" else "vibrate"
            else -> "normal"
        }
    }

    private fun looksLikeDnd(n: String) = Regex("\\b(dnd|do not disturb|don't disturb|disturb mat)\\b").containsMatchIn(n)
    private fun looksLikeAutoBrightness(n: String) =
        Regex("\\b(auto|automatic|adaptive)\\s+brightness\\b|\\bbrightness\\s+(auto|automatic|adaptive)\\b").containsMatchIn(n)

    private val rotationWord = Regex("\\b(auto\\s?rotate|autorotate|rotation|rotate|orientation|portrait)\\b")
    private fun looksLikeRotation(n: String) = rotationWord.containsMatchIn(n)
    /** "rotation lock on" / "auto rotate off" -> locked; "auto rotate on" / "rotation lock off" -> unlocked. */
    private fun rotationLocked(n: String): Boolean {
        val off = looksLikeOff(n)
        return if (n.contains("lock")) !off else off
    }

    private fun looksLikeAirplane(n: String) = Regex("\\b(airplane|aeroplane)\\b|\\bflight\\s?mode\\b").containsMatchIn(n)
    private fun looksLikeHotspot(n: String) = Regex("\\bhot\\s?spot\\b|\\btethering\\b").containsMatchIn(n)
    private fun looksLikeLocation(n: String) =
        Regex("\\b(location|gps)\\b").containsMatchIn(n) && stateRegex.containsMatchIn(n) && !n.contains("settings") && !n.contains("share")

    private val tileNames = listOf(
        Regex("\\beye\\s(protection|comfort|care)\\b") to "eye protection",
        Regex("\\bsuper\\s(battery\\s)?saver\\b") to "super battery saver",
        Regex("\\b(low power|power saving|battery saver)\\b") to "low power mode",
        Regex("\\b(dark|night)\\smode\\b") to "dark mode",
        Regex("\\bbedtime\\b") to "bedtime mode",
        Regex("\\bscreen\\srecord(ing|er)?\\b") to "screen recording"
    )
    private fun genericTileName(n: String): String? = tileNames.firstOrNull { it.first.containsMatchIn(n) }?.second

    // ---------------------------------------------------------------- alarm

    private fun looksLikeAlarm(n: String) =
        (n.contains("alarm") || n.contains("wake me")) && !Regex("\\b(cancel|delete|hatao|hata|remove|off|band)\\b").containsMatchIn(n)

    private fun extractAlarmParams(n: String): Map<String, String> {
        val match = Regex("\\b(?:at|@)?\\s*(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?\\b").find(n)
        return buildMap {
            if (match != null) {
                val hour = match.groupValues[1]
                put("hour", hour)
                put("minute", match.groupValues.getOrNull(2)?.ifBlank { "0" } ?: "0")
                var ampm = match.groupValues.getOrNull(3).orEmpty()
                if (ampm.isBlank()) {
                    val night = Regex("\\b(raat|night)\\b").containsMatchIn(n)
                    ampm = when {
                        Regex("\\b(subah|morning|savere)\\b").containsMatchIn(n) -> "am"
                        night && hour == "12" -> "am"
                        Regex("\\b(shaam|sham|evening|raat|night|dopahar|afternoon)\\b").containsMatchIn(n) -> "pm"
                        else -> ""
                    }
                }
                put("ampm", ampm)
            }
        }
    }

    // ---------------------------------------------------------------- messages / calls

    private val openMessagesRegex = Regex("^(?:open\\s+)?(?:text\\s+)?(?:messages?|messaging|sms|msg)(?:\\s+app)?(?:\\s+(?:kholo|khol do|open|chalao|chalu karo|launch karo))?$")
    private fun isOpenMessagesApp(n: String) = openMessagesRegex.matches(n)

    private fun looksLikeMessage(n: String) = listOf("message", "msg", "sms", "text message", "text karo", "text bhejo").any(n::contains) && !n.startsWith("open message")

    private val callWord = Regex("\\b(?:call|dial|ring)\\b")
    private val phoneVerb = Regex("\\bphone\\s+(?:karo|kro|kar|lagao|lagana|laga)\\b")
    private val callNoise = Regex("\\b(?:missed|history|logs?|recordings?|blocked?|forwarding|waiting)\\b")
    private val callAppWord = Regex("\\b(?:call|dial|phone)\\s+(?:log|logs|history|app|screen|settings)\\b|\\b(?:dialer|caller)\\b")

    private fun looksLikeCall(n: String): Boolean {
        if (callAppWord.containsMatchIn(n) || callNoise.containsMatchIn(n) || looksLikeVolume(n) || ringerWord.containsMatchIn(n)) return false
        val hasNumber = extractPhoneNumber(n) != null
        if (hasOpenVerb(n) && !hasNumber) return false
        return callWord.containsMatchIn(n) || phoneVerb.containsMatchIn(n) || (hasNumber && n.contains("phone"))
    }

    // ---------------------------------------------------------------- apps

    private val openVerbRegex = Regex("(?:^|\\s)(?:open|launch|start|run|kholo|khol\\s+do|khol\\s+de|kholna|chalao|chalu\\s+(?:karo|kro))(?:\\s|$)")
    private fun hasOpenVerb(n: String) = openVerbRegex.containsMatchIn(n)

    private val aliases: Map<String, List<String>> = linkedMapOf(
        "youtube" to listOf("youtube", "you tube", "yt"),
        "whatsapp" to listOf("whatsapp", "what's app", "whats app", "whatsap"),
        "instagram" to listOf("instagram", "insta"),
        "chrome" to listOf("chrome", "google chrome"),
        "calculator" to listOf("calculator", "calc", "calcu"),
        "settings" to listOf("settings", "setting", "setings"),
        "telegram" to listOf("telegram", "tele gram"),
        "facebook" to listOf("facebook", "fb"),
        "maps" to listOf("google maps", "maps", "map"),
        "gmail" to listOf("gmail", "mail"),
        "dialer" to listOf("dialer", "phone app", "phone", "call log", "call logs", "call history", "caller id"),
        "messages" to listOf("messages", "messaging", "message app", "sms app"),
        "camera" to listOf("camera"),
        "gallery" to listOf("gallery"),
        "contacts" to listOf("contacts"),
        "clock" to listOf("clock")
    )

    private fun wordRegex(word: String) = Regex("\\b" + Regex.escape(word) + "\\b")

    private fun looksLikeOpenApp(n: String): Boolean =
        hasOpenVerb(n) || aliases.values.any { words -> words.any { it == n } }

    private fun extractAppName(n: String): String? {
        knownAppAlias(n)?.let { return it }
        val value = n.replace(Regex("\\b(please|zara|plz|app|application|ko|karo|kro|kar do|kar de|open|kholo|khol do|khol de|kholna|launch|start|run|chalu|chalao)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return value.ifBlank { null }
    }

    private fun knownAppAlias(n: String): String? =
        aliases.entries.firstOrNull { (_, words) -> words.any { wordRegex(it).containsMatchIn(n) } }?.key

    // ---------------------------------------------------------------- calls / numbers

    private fun extractCallParams(text: String, n: String): Map<String, String> = extractPhoneNumber(text)?.let { mapOf("phone_number" to it) } ?: extractCallTarget(n)?.let { mapOf("contact_name" to it) } ?: emptyMap()
    private fun extractPhoneNumber(value: String): String? = Regex("(?<!\\d)(?:\\+?\\d[\\d\\s().-]{6,18}\\d)(?!\\d)").findAll(value).map { it.value.filter(Char::isDigit) }.firstOrNull { it.length in 7..15 }

    private fun extractCallTarget(n: String): String? {
        var value = n
        listOf("^please ", "^zara ", "^mujhe ", "^mere liye ", "^can you ", "^please call ", "^please phone ").forEach { value = value.replace(Regex(it), "") }
        value = value.replace(Regex("^call\\s+"), "").replace(Regex("^dial\\s+"), "").replace(Regex("^phone\\s+"), "").replace(Regex("^ring\\s+"), "")
            .replace(Regex("\\b(ko|k[o0]|please|zara|se|par|pe)\\b"), " ").replace(Regex("\\b(call|phone|lagao|lagana|karo|karna|kar do|dial|ring)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        return value.ifBlank { null }
    }

    private fun extractMessageTarget(n: String): String? {
        Regex("(?i)^(.+?)\\s+ko\\s+(?:message|msg|sms|text)\\b").find(n)?.groupValues?.getOrNull(1)?.let { cleanContactTarget(it)?.let { target -> return target } }
        Regex("\\bto\\s+(.+?)\\s+\\b(?:saying|that)\\b").find(n)?.groupValues?.getOrNull(1)?.let { cleanContactTarget(it)?.let { target -> return target } }
        val marker = Regex("\\b(?:message|msg|sms|text)\\b").find(n)
        if (marker != null) {
            val after = n.substring(marker.range.last + 1).trim()
            val targetPart = after.substringBefore(":").substringBefore(" saying ").substringBefore(" that ").trim()
            if (targetPart.isNotBlank() && !targetPart.contains(" ")) cleanContactTarget(targetPart)?.let { return it }
        }
        val before = marker?.let { n.substring(0, it.range.first) } ?: n
        val beforeTrimmed = before.trim()
        if (beforeTrimmed.endsWith(" ko")) return cleanContactTarget(beforeTrimmed.removeSuffix(" ko"))
        Regex("(?i)^(.+?)\\s+ko$").find(beforeTrimmed)?.groupValues?.getOrNull(1)?.let { return cleanContactTarget(it) }
        Regex("(?i)\\bto\\s+(.+)$").find(before)?.groupValues?.getOrNull(1)?.let { cleanContactTarget(it)?.let { target -> return target } }
        return null
    }
    private fun cleanContactTarget(value: String): String? = value.replace(Regex("\\b(please|zara|mujhe|mere liye|to|ko|ke liye|par|pe|bhejo|send|do|karo|kar do|message|msg|sms|text)\\b"), " ").replace(Regex("\\s+"), " ").trim().ifBlank { null }
    private fun extractMessageBody(text: String): String? {
        val colon = text.indexOf(':')
        if (colon >= 0 && listOf("message", "msg", "sms", "text", "bhejo").any(text.substring(0, colon).lowercase()::contains)) return text.substring(colon + 1).trim().ifBlank { null }
        Regex("(?i)\\b(?:message|msg|sms|text)\\s*:\\s*").find(text)?.let { return text.substring(it.range.last + 1).trim().ifBlank { null } }
        Regex("(?i)\\bbhejo\\s*:\\s*").find(text)?.let { return text.substring(it.range.last + 1).trim().ifBlank { null } }
        Regex("(?i)\\bsaying\\s+(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().ifBlank { null } }
        Regex("(?i)\\b(?:bolo|batao|keh do)\\s*[:,-]?\\s*(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().removeSurrounding("\"").removeSurrounding("'").ifBlank { null } }
        Regex("(?i)\\bbhejo\\b\\s*(.*)$").find(text)?.groupValues?.getOrNull(1)?.let { val body = it.removePrefix(":").trim(); if (body.isNotBlank()) return body }
        Regex("(?i)\\bko\\s+(?:message|msg|sms|text)\\s+(?:karo|kar do|bhejo)\\s*:??\\s*(.+)$").find(text)?.groupValues?.getOrNull(1)?.let { return it.trim().removePrefix(":").trim().ifBlank { null } }
        return null
    }
}
