package com.kaifrza.jarvis.accessibility

import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Drives the notification panel's Quick Settings tiles.
 *
 * On the Vivo Y1s the panel opens COLLAPSED (about 6 tiles); one more pull-down reveals the full 12-tile
 * page, and there are further pages to the side. This navigator opens the panel, expands it, finds a tile
 * by its label on whichever page it lives, taps it only when the real state differs from the requested one
 * (state is read through official APIs where they exist) and always closes the panel afterwards.
 */
object QuickSettingsNavigator {
    private val anchors = listOf("Wi-Fi", "Bluetooth", "Flashlight", "Airplane mode", "Data network", "Location", "Silent mode")

    fun open(s: JarvisAccessibilityService): Boolean {
        s.awaitIdleFocus()
        if (!s.performGlobalActionQuickSettings()) return false
        SystemClock.sleep(650L)
        return true
    }

    /** Pull the collapsed panel down to its full tile grid. Harmless if it is already expanded. */
    fun expand(s: JarvisAccessibilityService) {
        val d = s.resources.displayMetrics
        s.swipeBy(d.widthPixels / 2f, d.heightPixels * 0.05f, d.widthPixels / 2f, d.heightPixels * 0.62f, 420L)
        SystemClock.sleep(550L)
    }

    /** Vertical centre of the tile grid, taken from a known tile; used to place sideways swipes. */
    private fun gridY(s: JarvisAccessibilityService): Float {
        val node = s.findTileNode(anchors)
        if (node != null) {
            val r = Rect()
            node.getBoundsInScreen(r)
            return r.exactCenterY()
        }
        return s.resources.displayMetrics.heightPixels * 0.33f
    }

    fun page(s: JarvisAccessibilityService, forward: Boolean): Boolean {
        if (s.scrollPager(forward)) {
            SystemClock.sleep(450L)
            return true
        }
        val w = s.resources.displayMetrics.widthPixels.toFloat()
        val y = gridY(s)
        val ok = if (forward) s.swipeBy(w * 0.88f, y, w * 0.12f, y, 450L) else s.swipeBy(w * 0.12f, y, w * 0.88f, y, 450L)
        SystemClock.sleep(550L)
        return ok
    }

    /** Looks for the tile on the current page, then on up to 3 more pages, then returns to the first page. */
    fun findTile(s: JarvisAccessibilityService, labels: List<String>): AccessibilityNodeInfo? {
        s.findTileNode(labels)?.let { return it }
        repeat(3) {
            page(s, true)
            s.findTileNode(labels)?.let { return it }
        }
        repeat(3) { page(s, false) }
        return null
    }

    /**
     * Toggles a tile. Returns null on success or a short Hinglish error message.
     * desired = true/false when the user said on/off, null for a plain toggle.
     * readState = official-API reading of the real state (or null when the OS does not expose it).
     */
    fun toggleTile(
        s: JarvisAccessibilityService,
        labels: List<String>,
        desired: Boolean?,
        readState: (() -> Boolean?)?
    ): String? {
        if (!open(s)) return "Notification panel nahi khul paya."
        try {
            var node: AccessibilityNodeInfo? = s.findTileNode(labels)
            if (node == null) {
                expand(s)
                node = findTile(s, labels)
            }
            val tile = node ?: return "Tile nahi mila (${labels.first()}). Panel ke pages mein check karo."
            val before = readState?.invoke()
            if (desired != null && before != null && before == desired) return null
            if (!s.clickNodeSafely(tile)) return "Tile dab nahi paya (${labels.first()})."
            SystemClock.sleep(700L)
            if (desired != null && readState != null && readState.invoke() != null) {
                val deadline = SystemClock.uptimeMillis() + 3_000L
                while (SystemClock.uptimeMillis() < deadline) {
                    if (readState.invoke() == desired) return null
                    SystemClock.sleep(150L)
                }
                return "Tile dabaya, par ${labels.first()} ki state badli nahi."
            }
            return null
        } finally {
            s.closeQuickSettings()
        }
    }
}
