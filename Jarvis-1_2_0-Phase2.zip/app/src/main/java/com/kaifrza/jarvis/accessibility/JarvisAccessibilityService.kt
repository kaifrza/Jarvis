package com.kaifrza.jarvis.accessibility

import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.kaifrza.jarvis.service.AlertNotifier
import com.kaifrza.jarvis.service.JarvisKeepAliveService

/** Cross-app capability boundary: reads the screen, taps, types, and hosts the native orb/overlay. */
class JarvisAccessibilityService : android.accessibilityservice.AccessibilityService() {
    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
            private set
    }

    @Volatile var foregroundPackage: String? = null
        private set

    private var overlay: OverlayController? = null
    @Volatile private var lastInputActivityAt = 0L

    /** Called by the Jarvis input box: the keyboard may still be on screen for a moment after submit. */
    fun markInputActivity() {
        lastInputActivityAt = SystemClock.uptimeMillis()
    }

    private fun windowsLite(): Pair<List<AccessibilityWindowInfo>, List<WindowLite>> {
        val ws = runCatching { windows }.getOrNull().orEmpty()
        val lite = ws.map { w ->
            val r = Rect()
            w.getBoundsInScreen(r)
            WindowLite(w.id, w.type, w.isActive, r.width().toLong() * r.height())
        }
        return ws to lite
    }

    /**
     * Root of the window Jarvis should act on: the real app (or the Quick Settings panel), never the
     * Jarvis overlay or the keyboard. Falls back to the active window when window info is unavailable.
     */
    fun targetRoot(): AccessibilityNodeInfo? {
        val (ws, lite) = windowsLite()
        if (ws.isEmpty()) return rootInActiveWindow
        val chosen = WindowPicker.pick(lite) ?: return rootInActiveWindow
        return ws.firstOrNull { it.id == chosen.id }?.root ?: rootInActiveWindow
    }

    /**
     * Waits until Jarvis' own overlay/keyboard no longer holds focus. Without this, "back jao" typed in the
     * panel only closed the keyboard and "scroll" scrolled the panel instead of the app underneath.
     */
    fun awaitIdleFocus(timeoutMs: Long = 1_500L) {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        var waited = false
        while (SystemClock.uptimeMillis() < deadline) {
            val lite = windowsLite().second
            if (lite.isEmpty()) return
            val imeBlocks = SystemClock.uptimeMillis() - lastInputActivityAt < 4_000L
            if (WindowPicker.idle(lite, imeBlocks)) {
                if (waited) SystemClock.sleep(200L)
                return
            }
            waited = true
            SystemClock.sleep(60L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        foregroundPackage = targetRoot()?.packageName?.toString()
        overlay = OverlayController(this).also { it.start() }
        // Watchdog + process priority: a tiny foreground service keeps Jarvis alive on aggressive OEMs.
        AlertNotifier.clear(this)
        JarvisKeepAliveService.startIfEnabled(this)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        // The moment the service is switched off (by the user or by a battery manager) tell the user.
        runCatching { AlertNotifier.showAccessibilityOff(this) }
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            foregroundPackage = targetRoot()?.packageName?.toString() ?: event.packageName?.toString()
        }
    }

    override fun onInterrupt() = Unit

    fun openJarvisUi() { overlay?.togglePanel() }

    fun applyBubbleSetting() { overlay?.applyBubbleSetting() }

    fun performGlobalActionBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalActionHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalActionRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performGlobalActionNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun performGlobalActionQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    /**
     * Opens Quick Settings and taps the matching tile only when its visible state differs from the
     * requested one. Exact label matches win over prefix matches; "saver" tiles are ignored.
     * If the tile is not visible (collapsed panel on some OEMs) it swipes the shade down once more.
     */
    fun openQuickSettingsAndToggle(labels: List<String>, desiredEnabled: Boolean): Boolean {
        awaitIdleFocus()
        if (!performGlobalActionQuickSettings()) return false
        SystemClock.sleep(550)
        val normalizedLabels = labels.map(::normalize)
        for (attempt in 0..1) {
            val deadline = SystemClock.uptimeMillis() + 1_800L
            while (SystemClock.uptimeMillis() < deadline) {
                val root = targetRoot()
                val node = root?.let { findToggleNode(it, normalizedLabels) }
                if (node != null) {
                    val current = readableToggleState(node)
                    if (current == desiredEnabled) return true
                    if (clickNodeOrClickableParent(node)) {
                        SystemClock.sleep(650)
                        return true
                    }
                }
                SystemClock.sleep(120)
            }
            if (attempt == 0) {
                expandQuickSettingsBySwipe()
                SystemClock.sleep(500)
            }
        }
        return false
    }

    private fun findToggleNode(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        val visible = findNodes(root) { it.isVisibleToUser }
        fun labelsOf(n: AccessibilityNodeInfo) = listOf(
            normalize(n.text?.toString().orEmpty()),
            normalize(n.contentDescription?.toString().orEmpty())
        )
        visible.firstOrNull { n -> labelsOf(n).any { l -> labels.any { it == l } } }?.let { return it }
        return visible.firstOrNull { n ->
            labelsOf(n).any { l -> l.isNotEmpty() && !l.contains("saver") && labels.any { lab -> l.startsWith(lab) } }
        }
    }

    private fun expandQuickSettingsBySwipe() {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val path = android.graphics.Path().apply { moveTo(w / 2, h * 0.04f); lineTo(w / 2, h * 0.6f) }
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun findTileNode(labels: List<String>): AccessibilityNodeInfo? {
        val root = targetRoot() ?: return null
        return findToggleNode(root, labels.map(::normalize))
    }

    fun clickNodeSafely(node: AccessibilityNodeInfo): Boolean = clickNodeOrClickableParent(node)

    /** Pages the Quick Settings tile grid through the pager's own scroll action (more reliable than a swipe). */
    fun scrollPager(forward: Boolean): Boolean {
        val root = targetRoot() ?: return false
        val minWidth = resources.displayMetrics.widthPixels * 0.6f
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val candidates = findNodes(root) { it.isVisibleToUser && it.isScrollable }
            .filter { n ->
                val r = Rect()
                n.getBoundsInScreen(r)
                r.width() >= minWidth
            }
            .sortedByDescending { (it.className?.toString() ?: "").contains("Pager") }
        for (n in candidates) if (n.performAction(action)) return true
        return false
    }

    /** Closes the Quick Settings / notification shade if it is still open after a toggle. */
    fun closeQuickSettings() {
        val pkg = targetRoot()?.packageName?.toString().orEmpty()
        if (pkg.contains("systemui")) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            SystemClock.sleep(250)
        }
    }

    /** Taps the first visible switch/checkbox (used for one-time "Modify system settings" style pages). */
    fun setFirstSwitch(enabled: Boolean, timeoutMs: Long = 2_500L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            val root = targetRoot()
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && n.isCheckable }.firstOrNull() }
            if (node != null) {
                if (node.isChecked == enabled) return true
                if (clickNodeOrClickableParent(node)) {
                    SystemClock.sleep(500)
                    return true
                }
            }
            SystemClock.sleep(150)
        }
        return false
    }

    private fun readableToggleState(node: AccessibilityNodeInfo): Boolean? {
        if (node.isCheckable) return node.isChecked
        val value = normalize(listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" "))
        return when {
            Regex("\\b(on|enabled|connected|active)\\b").containsMatchIn(value) -> true
            Regex("\\b(off|disabled|disconnected|inactive)\\b").containsMatchIn(value) -> false
            else -> null
        }
    }

    fun clickText(text: String): Boolean = clickBestMatchingNode(text)

    fun clickContentDescription(description: String): Boolean {
        val target = normalize(description)
        val deadline = SystemClock.uptimeMillis() + 1_800L
        while (SystemClock.uptimeMillis() < deadline) {
            val root = targetRoot()
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && normalize(n.contentDescription?.toString().orEmpty()).contains(target) }.firstOrNull() }
            if (node != null && clickNodeOrClickableParent(node)) return true
            SystemClock.sleep(120)
        }
        return false
    }

    fun focusEditable(): Boolean {
        val root = targetRoot() ?: return false
        val editable = findNodes(root) { it.isVisibleToUser && it.isEditable }
        val node = editable.firstOrNull { it.isFocused } ?: editable.firstOrNull() ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) || node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun typeText(text: String): Boolean {
        val deadline = SystemClock.uptimeMillis() + 1_500L
        while (SystemClock.uptimeMillis() < deadline) {
            val root = targetRoot()
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && n.isEditable && n.isFocused }.firstOrNull() }
                ?: root?.let { findNodes(it) { n -> n.isVisibleToUser && n.isEditable }.firstOrNull() }
            if (node != null) {
                val arguments = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
                if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)) return true
            }
            SystemClock.sleep(120)
        }
        return false
    }

    fun scrollForward(): Boolean = scroll(true)
    fun scrollBackward(): Boolean = scroll(false)

    fun searchCurrentScreen(query: String): Boolean {
        if (query.isBlank()) return false
        repeat(2) { attempt ->
            val field = findSearchField()
            if (field != null) {
                field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, query) }
                if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                    SystemClock.sleep(300L)
                    if (submitSearch()) return true
                }
            } else if (attempt == 0) {
                // No input yet (Chrome home box, YouTube magnifier...): open the search UI, then look again.
                if (clickBestMatchingNode("Search") || clickContentDescription("Search")) SystemClock.sleep(800L)
            }
        }
        // Browser fallback: some browsers expose no usable Search/Enter control.
        val browser = targetRoot()?.packageName?.toString() ?: foregroundPackage.orEmpty()
        if (browser in setOf("com.android.chrome", "org.mozilla.firefox", "com.microsoft.emmx", "com.brave.browser")) {
            return runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            }.getOrDefault(false)
        }
        return false
    }

    private fun findSearchField(): AccessibilityNodeInfo? {
        val root = targetRoot() ?: return null
        val editables = findNodes(root) { n -> n.isVisibleToUser && n.isEditable }
        return editables.firstOrNull {
            normalize(it.hintText?.toString().orEmpty()).contains("search") ||
                normalize(it.contentDescription?.toString().orEmpty()).contains("search")
        } ?: editables.firstOrNull()
    }

    /** Presses the keyboard's action key (Search/Go/Enter/Done) or an on-screen Search/Go button. */
    private fun submitSearch(): Boolean {
        val keyLabels = setOf("search", "go", "enter", "done", "send")
        val ime = runCatching { windows }.getOrNull().orEmpty().firstOrNull { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }?.root
        if (ime != null) {
            val key = findNodes(ime) { n ->
                n.isVisibleToUser && (normalize(n.contentDescription?.toString().orEmpty()) in keyLabels ||
                    normalize(n.text?.toString().orEmpty()) in keyLabels)
            }.firstOrNull()
            if (key != null && clickNodeOrClickableParent(key)) return true
        }
        return clickBestMatchingNode("Search") || clickContentDescription("Search") ||
            clickBestMatchingNode("Go") || clickContentDescription("Go") ||
            clickBestMatchingNode("Enter") || clickContentDescription("Enter")
    }

    /** Returns a compact semantic snapshot for the planner/verifier. */
    fun visibleScreenSnapshot(maxChars: Int = 4000): String {
        val root = targetRoot() ?: return ""
        val out = StringBuilder()
        val seen = HashSet<String>()
        fun visit(node: AccessibilityNodeInfo) {
            if (out.length >= maxChars) return
            if (node.isVisibleToUser) {
                val value = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
                    .joinToString(" ").trim().replace(Regex("\\s+"), " ")
                if (value.isNotBlank() && seen.add(value.lowercase())) {
                    if (out.isNotEmpty()) out.append("\n")
                    out.append(value)
                }
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let(::visit)
        }
        visit(root)
        return out.toString().take(maxChars)
    }

    fun findVisibleText(text: String): List<AccessibilityNodeInfo> {
        val root = targetRoot() ?: return emptyList()
        val target = normalize(text)
        return findNodes(root) { it.isVisibleToUser && normalize(it.text?.toString().orEmpty()).contains(target) }
    }

    fun isTextVisible(text: String, timeoutMs: Long = 1_200L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            if (findVisibleText(text).isNotEmpty()) return true
            SystemClock.sleep(120)
        }
        return findVisibleText(text).isNotEmpty()
    }

    fun waitForForegroundPackage(packageName: String, timeoutMs: Long = 2_500L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            // Poll the real window instead of waiting for an event that may have fired too early.
            val current = targetRoot()?.packageName?.toString() ?: foregroundPackage
            if (current == packageName) {
                foregroundPackage = current
                return true
            }
            SystemClock.sleep(120)
        }
        return false
    }

    override fun onDestroy() {
        overlay?.stop()
        overlay = null
        instance = null
        super.onDestroy()
    }

    /** Exact (case/space-insensitive) label match. Used for dialogs where "Allow" must never hit "Don't allow". */
    fun clickExactText(vararg labels: String, timeoutMs: Long = 1_500L): Boolean {
        val targets = labels.map(::normalize)
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            val root = targetRoot()
            val node = root?.let { r ->
                findNodes(r) { n ->
                    n.isVisibleToUser && (
                        normalize(n.text?.toString().orEmpty()) in targets ||
                            normalize(n.contentDescription?.toString().orEmpty()) in targets
                        )
                }.firstOrNull()
            }
            if (node != null && clickNodeOrClickableParent(node)) return true
            SystemClock.sleep(120)
        }
        return false
    }

    /** Finger swipe in screen pixels (used for Quick Settings pages and recon). */
    fun swipeBy(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 320L): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun clickBestMatchingNode(text: String): Boolean {
        val target=normalize(text); val deadline=SystemClock.uptimeMillis()+1_800L
        while(SystemClock.uptimeMillis()<deadline){
            val root=targetRoot()
            val node=root?.let{findNodes(it){n->n.isVisibleToUser&&normalize(n.text?.toString().orEmpty()).contains(target)}.firstOrNull()}
            if(node!=null&&clickNodeOrClickableParent(node))return true
            SystemClock.sleep(120)
        }
        return false
    }
    private fun clickNodeOrClickableParent(node: AccessibilityNodeInfo):Boolean{
        if(node.isClickable)return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent=node.parent
        repeat(6){if(parent?.isClickable==true)return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);parent=parent?.parent}
        return false
    }
    private fun scroll(forward: Boolean): Boolean {
        val root = targetRoot() ?: return false
        val candidates = findNodes(root) { it.isVisibleToUser && it.isScrollable }
            .sortedByDescending { n ->
                val r = Rect()
                n.getBoundsInScreen(r)
                r.width().toLong() * r.height()
            }
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        // The biggest list is the real content; tab strips / chip bars are small and tried last.
        for (node in candidates) if (node.performAction(action)) return true
        // Some feeds do not expose scroll actions: use a real finger swipe in the middle of the window.
        val r = Rect()
        root.getBoundsInScreen(r)
        val x = r.exactCenterX()
        val h = r.height().toFloat()
        val from = r.top + h * (if (forward) 0.72f else 0.30f)
        val to = r.top + h * (if (forward) 0.30f else 0.72f)
        return swipeBy(x, from, x, to, 380L)
    }
    private fun findNodes(root:AccessibilityNodeInfo,predicate:(AccessibilityNodeInfo)->Boolean):List<AccessibilityNodeInfo>{
        val result=mutableListOf<AccessibilityNodeInfo>(); fun visit(node:AccessibilityNodeInfo){if(predicate(node))result+=node;for(i in 0 until node.childCount)node.getChild(i)?.let(::visit)};visit(root);return result
    }
    private fun normalize(value:String)=value.lowercase().replace(Regex("\\s+")," ").trim()
}
