package com.kaifrza.jarvis.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.ui.MainActivity
import com.kaifrza.jarvis.ui.PermissionCenter

/**
 * Tiny foreground service with two jobs:
 *  1. raise process priority so Vivo/Funtouch is far less likely to kill Jarvis in the background;
 *  2. watchdog: every 20 s it checks that the Accessibility service is still ON and, if the system or a
 *     battery manager switched it off, posts a one-tap notification to turn it back on.
 * It does no polling work beyond one cheap settings read, so it costs almost no battery or RAM.
 */
class JarvisKeepAliveService : Service() {
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            checkHealth()
            handler.postDelayed(this, CHECK_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannels()
        val notification = baseNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ONGOING_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ONGOING_ID, notification)
        }
        handler.postDelayed(tick, CHECK_INTERVAL_MS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun checkHealth() {
        if (PermissionCenter.isAccessibilityEnabled(this)) AlertNotifier.clear(this) else AlertNotifier.showIfMissing(this)
    }

    private fun ensureChannels() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ONGOING, "Jarvis running", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Keeps Jarvis alive in the background"
                setShowBadge(false)
            }
        )
        AlertNotifier.ensureChannel(this)
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun baseNotification(): Notification =
        Notification.Builder(this, CHANNEL_ONGOING)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis active")
            .setContentText("Bubble se bulao. Tap karke app kholo.")
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .build()

    companion object {
        private const val CHANNEL_ONGOING = "jarvis_ongoing"
        private const val ONGOING_ID = 7001
        private const val CHECK_INTERVAL_MS = 20_000L

        fun isEnabled(context: Context): Boolean =
            context.getSharedPreferences("jarvis_ui", Context.MODE_PRIVATE).getBoolean("keep_alive", true)

        fun setEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences("jarvis_ui", Context.MODE_PRIVATE).edit().putBoolean("keep_alive", enabled).apply()
            if (enabled) startIfEnabled(context) else context.stopService(Intent(context, JarvisKeepAliveService::class.java))
        }

        fun startIfEnabled(context: Context) {
            if (!isEnabled(context)) return
            runCatching { ContextCompat.startForegroundService(context, Intent(context, JarvisKeepAliveService::class.java)) }
        }
    }
}
