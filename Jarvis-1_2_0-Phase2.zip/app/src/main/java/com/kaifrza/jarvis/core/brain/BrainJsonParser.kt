package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.tools.ToolRegistry
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Pure parser for Jarvis's provider-neutral JSON planning contract. */
object BrainJsonParser {
    private val tools = ToolRegistry()

    fun parsePlan(content: String): BrainPlan {
        val json = extractJson(content)
        val stepsJson = json.optJSONArray("steps") ?: JSONArray()
        val steps = buildList {
            for (i in 0 until stepsJson.length()) {
                val item = stepsJson.optJSONObject(i) ?: continue
                val intent = resolveIntent(item) ?: continue
                val params = mutableMapOf<String, String>()
                item.optJSONObject("parameters")?.let { obj ->
                    obj.keys().forEach { key -> params[key] = obj.optString(key) }
                }
                item.optJSONObject("arguments")?.let { obj ->
                    obj.keys().forEach { key -> params[key] = obj.optString(key) }
                }
                val raw = item.optString("rawText").ifBlank { item.optString("raw_text") }.ifBlank { intent.name }
                add(BrainStep(
                    JarvisCommand(UUID.randomUUID().toString(), raw, intent, params),
                    item.optString("rationale").ifBlank { null }
                ))
            }
        }
        return BrainPlan(reply = json.optString("reply").ifBlank { null }, steps = steps, source = "remote")
    }

    fun parseToolCalls(toolCalls: JSONArray): BrainPlan {
        val steps = buildList {
            for (i in 0 until toolCalls.length()) {
                val call = toolCalls.optJSONObject(i) ?: continue
                val fn = call.optJSONObject("function") ?: continue
                val toolId = fn.optString("name")
                val intent = tools.find(toolId)?.intent ?: continue
                val arguments = fn.optString("arguments", "{}")
                val params = mutableMapOf<String, String>()
                runCatching { JSONObject(arguments) }.getOrNull()?.let { obj ->
                    obj.keys().forEach { key -> params[key] = obj.optString(key) }
                }
                add(BrainStep(
                    JarvisCommand(UUID.randomUUID().toString(), toolId, intent, params),
                    "Model function/tool call"
                ))
            }
        }
        return BrainPlan(steps = steps, source = "remote-tool-call")
    }

    private fun resolveIntent(item: JSONObject): IntentType? {
        val toolId = item.optString("tool").ifBlank { item.optString("tool_id") }
        if (toolId.isNotBlank()) return tools.find(toolId)?.intent
        return runCatching { IntentType.valueOf(item.optString("intent").uppercase()) }.getOrNull()
    }

    private fun extractJson(text: String): JSONObject {
        val cleaned = text.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        require(start >= 0 && end > start) { "Brain did not return JSON." }
        return JSONObject(cleaned.substring(start, end + 1))
    }
}
