package com.kaifrza.jarvis.ui

/** Visual state of the Jarvis orb. Pure model so it can be unit-tested without Android. */
enum class OrbState { IDLE, LISTENING, THINKING, ACTING, ERROR }

object PanelModel {
    /** Maps a (message type, command state) pair coming from the brain/voice layers to an orb state. */
    fun orbFor(type: String, state: String): OrbState = when {
        state == "FAILED" -> OrbState.ERROR
        type == "voice" || state == "LISTENING" -> OrbState.LISTENING
        type == "thinking" || state == "THINKING" -> OrbState.THINKING
        state == "RUNNING" || state == "EXECUTING" || state == "VERIFYING" || state == "APPROVED" -> OrbState.ACTING
        else -> OrbState.IDLE
    }

    fun headline(state: String): String = when (state) {
        "THINKING" -> "Soch raha hoon…"
        "LISTENING" -> "Sun raha hoon…"
        "RUNNING", "EXECUTING", "VERIFYING" -> "Kaam chal raha hai…"
        "FAILED" -> "Kuch gadbad hui."
        "WAITING_FOR_APPROVAL" -> "Aapki ijaazat chahiye."
        "WAITING_FOR_CHOICE" -> "Ek option chuniye."
        "CANCELLED" -> "Roka gaya."
        else -> "Boliye, sir."
    }

    /** True while a command is in flight, i.e. the panel should show STOP instead of the input row. */
    fun isBusy(state: String): Boolean = state in setOf("THINKING", "RUNNING", "EXECUTING", "VERIFYING", "APPROVED")
}
