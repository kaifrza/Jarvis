package com.kaifrza.jarvis.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * "Jarvis is OFF" alert. It is posted instantly from AccessibilityService.onUnbind (the moment the user or
 * the system switches the service off) and re-posted by the watchdog if it is missing, so it works every
 * time, not only on the first on/off cycle.
 */
object AlertNotifier {
    const val CHANNEL_ALERT = "jarvis_alert"
    const val ALERT_ID = 7002

    private fun manager(context: Context) = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannel(context: Context) {
        manager(context).createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Jarvis alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Tells you when Jarvis loses a permission or service"
            }
        )
    }

    fun showAccessibilityOff(context: Context) {
        ensureChannel(context)
        val enable = PendingIntent.getActivity(
            context, 2, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(context, CHANNEL_ALERT)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Jarvis band ho gaya")
            .setContentText("Accessibility service OFF hai. Tap karke ON karo.")
            .setContentIntent(enable)
            .setAutoCancel(true)
            .build()
        manager(context).notify(ALERT_ID, n)
    }

    /** Re-posts the alert only if it is not currently on screen (user swiped it away, or it was never shown). */
    fun showIfMissing(context: Context) {
        val present = runCatching { manager(context).activeNotifications.any { it.id == ALERT_ID } }.getOrDefault(false)
        if (!present) showAccessibilityOff(context)
    }

    fun clear(context: Context) {
        manager(context).cancel(ALERT_ID)
    }
}
