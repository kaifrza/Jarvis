package com.kaifrza.jarvis.core.model

enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }

enum class CommandState {
    RECEIVED, PLANNED, PREPARED, WAITING_FOR_CHOICE, WAITING_FOR_APPROVAL,
    APPROVED, EXECUTING, VERIFYING, SUCCESS, FAILED, CANCELLED
}

enum class IntentType {
    UNKNOWN,
    OPEN_APP,
    NAVIGATE_BACK,
    HOME,
    RECENTS,
    OPEN_NOTIFICATIONS,
    READ_NOTIFICATIONS,
    SET_VOLUME,
    SET_BRIGHTNESS,
    PLAY_MEDIA,
    PAUSE_MEDIA,
    STOP_MEDIA,
    NEXT_MEDIA,
    PREVIOUS_MEDIA,
    MAKE_CALL,
    SEND_MESSAGE,
    DELETE_FILE,
    CREATE_ALARM,
    CREATE_REMINDER,
    ACCESS_SCREEN,
    UI_CLICK_TEXT,
    UI_TYPE_TEXT,
    UI_FOCUS_INPUT,
    UI_SCROLL,
    UI_SEARCH,
    CALCULATE,
    OPEN_NETWORK_SETTINGS,
    OPEN_WIFI_SETTINGS,
    OPEN_BLUETOOTH_SETTINGS,
    TOGGLE_WIFI,
    TOGGLE_MOBILE_DATA,
    TOGGLE_BLUETOOTH,
    SET_FLASHLIGHT,
    SET_RINGER_MODE,
    SET_DND,
    SET_AUTO_BRIGHTNESS,
    SET_ROTATION_LOCK,
    TOGGLE_AIRPLANE,
    TOGGLE_LOCATION,
    TOGGLE_HOTSPOT,
    TOGGLE_QS_TILE
}

data class JarvisCommand(
    val id: String,
    val rawText: String,
    val intent: IntentType,
    val parameters: Map<String, String> = emptyMap()
)

data class ActionPlan(
    val command: JarvisCommand,
    val risk: RiskLevel,
    val requiresConfirmation: Boolean
)
