package com.kaifrza.jarvis.core.actions

import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType

/** Generic cross-app UI tool boundary. The service owns all Accessibility interaction. */
class AccessibilityAction : JarvisAction {
    override val id = "android.accessibility_ui"

    override fun validate(plan: ActionPlan): ActionResult =
        if (JarvisAccessibilityService.instance == null)
            ActionResult.Failure("Accessibility Service is not enabled. Enable Jarvis Accessibility first.")
        else when (plan.command.intent) {
            IntentType.UI_CLICK_TEXT -> if (plan.command.parameters["text"].isNullOrBlank()) ActionResult.Failure("Tell me what to click.") else ActionResult.Success
            IntentType.UI_TYPE_TEXT -> if (plan.command.parameters["text"].isNullOrEmpty()) ActionResult.Failure("Tell me what to type.") else ActionResult.Success
            IntentType.UI_FOCUS_INPUT -> ActionResult.Success
            IntentType.UI_SCROLL -> if (plan.command.parameters["direction"].isNullOrBlank()) ActionResult.Failure("Tell me whether to scroll up or down.") else ActionResult.Success
            IntentType.UI_SEARCH -> if (plan.command.parameters["query"].isNullOrBlank()) ActionResult.Failure("Tell me what to search.") else ActionResult.Success
            else -> ActionResult.Failure("Unsupported UI action.")
        }

    override fun execute(plan: ActionPlan): ActionResult {
        val service = JarvisAccessibilityService.instance ?: return ActionResult.Failure("Accessibility Service is unavailable.")
        service.awaitIdleFocus()
        val ok = when (plan.command.intent) {
            IntentType.UI_CLICK_TEXT -> {
                val text = plan.command.parameters["text"] ?: return ActionResult.Failure("Missing click text.")
                service.clickText(text) || service.clickContentDescription(text)
            }
            IntentType.UI_TYPE_TEXT -> service.typeText(plan.command.parameters["text"] ?: return ActionResult.Failure("Missing text."))
            IntentType.UI_FOCUS_INPUT -> service.focusEditable()
            IntentType.UI_SCROLL -> if (plan.command.parameters["direction"].equals("up", true)) service.scrollBackward() else service.scrollForward()
            IntentType.UI_SEARCH -> service.searchCurrentScreen(plan.command.parameters["query"].orEmpty())
            else -> false
        }
        return if (ok) ActionResult.Success else ActionResult.Failure("I couldn't perform that UI action on the current screen.")
    }

    override fun verify(plan: ActionPlan): ActionResult {
        if (plan.command.intent == IntentType.UI_CLICK_TEXT && plan.command.parameters["text"].equals("send", true)) {
            val preview = plan.command.parameters["message_preview"]
            if (!preview.isNullOrBlank()) {
                val service = JarvisAccessibilityService.instance ?: return ActionResult.Failure("Accessibility Service disappeared before message verification.")
                return if (service.isTextVisible(preview)) ActionResult.Success
                else ActionResult.Failure("Send button was pressed, but I could not verify the message on screen.")
            }
        }
        return ActionResult.Success
    }
}
