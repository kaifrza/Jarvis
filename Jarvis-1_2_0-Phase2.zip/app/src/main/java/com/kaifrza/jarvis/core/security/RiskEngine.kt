package com.kaifrza.jarvis.core.security

import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.model.RiskLevel
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.tools.ToolRegistry

/**
 * Execution policy (tiered).
 *
 * - Commands the user typed or spoke run directly: Android's own permission grants are the gate,
 *   so there are no repetitive "are you sure?" dialogs for normal use.
 * - Steps proposed by a REMOTE model are untrusted (the model may have been steered by text it
 *   read on screen or in a notification). HIGH-risk tools (calls, SMS) and sensitive UI clicks
 *   (Send, Pay, Delete, Buy ...) therefore need explicit approval.
 */
class RiskEngine(private val tools: ToolRegistry) {
    private val sensitiveClick = Regex(
        "(?i)\\b(send|pay|pay now|transfer|delete|remove|buy|purchase|order|place order|confirm|submit|uninstall|reset|erase|bhejo|bhej)\\b"
    )

    fun plan(command: JarvisCommand, untrusted: Boolean = false): ActionPlan {
        val descriptor = tools.find(command.intent)
        val risk = descriptor?.risk ?: when (command.intent) {
            IntentType.UNKNOWN -> RiskLevel.CRITICAL
            else -> RiskLevel.HIGH
        }
        val needsApproval = untrusted && (
            risk >= RiskLevel.HIGH ||
                descriptor?.requiresConfirmation == true ||
                isSensitiveClick(command)
            )
        return ActionPlan(command = command, risk = risk, requiresConfirmation = needsApproval)
    }

    private fun isSensitiveClick(command: JarvisCommand): Boolean =
        command.intent == IntentType.UI_CLICK_TEXT &&
            sensitiveClick.containsMatchIn(command.parameters["text"].orEmpty())
}
