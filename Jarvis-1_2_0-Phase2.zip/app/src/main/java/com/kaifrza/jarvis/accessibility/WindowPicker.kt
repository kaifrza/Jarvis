package com.kaifrza.jarvis.accessibility

/** Minimal, Android-free view of an accessibility window so the choice logic can be unit-tested. */
data class WindowLite(val id: Int, val type: Int, val active: Boolean, val area: Long)

/**
 * Which window is "the screen the user wants Jarvis to work on"?
 *
 * Jarvis' own overlay panel and the keyboard are also accessibility windows, and while the user types a
 * command the overlay is the ACTIVE window. Reading/clicking/scrolling/pressing Back against that window
 * hits Jarvis itself (Back just closes the keyboard, scroll scrolls Jarvis' message list). So commands
 * always target the real app (or Quick Settings) window and never the overlay or the IME.
 */
object WindowPicker {
    // Same values as AccessibilityWindowInfo.TYPE_*
    const val TYPE_APPLICATION = 1
    const val TYPE_INPUT_METHOD = 2
    const val TYPE_SYSTEM = 3
    const val TYPE_ACCESSIBILITY_OVERLAY = 4
    const val TYPE_SPLIT_SCREEN_DIVIDER = 5

    private fun usable(w: WindowLite) =
        w.type != TYPE_ACCESSIBILITY_OVERLAY && w.type != TYPE_INPUT_METHOD && w.type != TYPE_SPLIT_SCREEN_DIVIDER

    /** The active usable window if there is one, otherwise the biggest one (status/nav bars are small). */
    fun pick(windows: List<WindowLite>): WindowLite? {
        val candidates = windows.filter(::usable)
        return candidates.firstOrNull { it.active } ?: candidates.maxByOrNull { it.area }
    }

    fun imeVisible(windows: List<WindowLite>): Boolean = windows.any { it.type == TYPE_INPUT_METHOD }

    /** True while Jarvis' overlay (or the keyboard) still holds focus. */
    fun focusIsOurs(windows: List<WindowLite>): Boolean {
        val active = windows.firstOrNull { it.active } ?: return false
        return active.type == TYPE_ACCESSIBILITY_OVERLAY || active.type == TYPE_INPUT_METHOD
    }

    /**
     * Focus is settled when Jarvis does not hold it. If the user just typed into a Jarvis input box
     * (imeBlocksNow), the keyboard must also be gone, otherwise Back would only close the keyboard.
     */
    fun idle(windows: List<WindowLite>, imeBlocksNow: Boolean): Boolean =
        !focusIsOurs(windows) && !(imeBlocksNow && imeVisible(windows))
}
