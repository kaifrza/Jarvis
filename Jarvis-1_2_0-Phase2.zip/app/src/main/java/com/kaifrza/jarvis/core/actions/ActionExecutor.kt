package com.kaifrza.jarvis.core.actions

import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.security.ApprovalManager
import com.kaifrza.jarvis.core.security.RiskEngine

class ActionExecutor(
    private val riskEngine: RiskEngine,
    private val approvalManager: ApprovalManager,
    private val registry: ActionRegistry
) {
    data class PreparedAction(val plan: ActionPlan, val approvalToken: String?)

    fun prepare(plan: ActionPlan): PreparedAction {
        val token = if (plan.requiresConfirmation) approvalManager.request(plan.command.id) else null
        return PreparedAction(plan, token)
    }

    fun execute(prepared: PreparedAction, approvalToken: String? = null): ActionResult {
        val plan = prepared.plan
        if (plan.requiresConfirmation) {
            if (approvalToken == null || prepared.approvalToken == null || approvalToken != prepared.approvalToken || !approvalManager.approve(approvalToken, plan.command.id)) {
                return ActionResult.RequiresApproval
            }
        }

        val action = registry.resolve(plan.command.intent)
            ?: return ActionResult.Failure("No executor registered for ${plan.command.intent}.")

        val validation = action.validate(plan)
        if (validation !is ActionResult.Success) return validation

        // Recovery is intentionally conservative: never blindly retry communication or a Send click.
        val attempts = if (isSafeToRetry(plan)) 2 else 1
        var lastFailure: ActionResult.Failure? = null
        repeat(attempts) { attempt ->
            val execution = action.execute(plan)
            if (execution is ActionResult.Failure) {
                lastFailure = execution
                if (attempt + 1 < attempts) Thread.sleep(180L)
                return@repeat
            }
            val verification = action.verify(plan)
            if (verification is ActionResult.Success) return execution
            if (verification is ActionResult.Failure) {
                lastFailure = verification
                if (attempt + 1 < attempts) Thread.sleep(180L)
            }
        }
        return lastFailure ?: ActionResult.Failure("Action failed without a diagnostic result.")
    }

    private fun isSafeToRetry(plan: ActionPlan): Boolean = when (plan.command.intent) {
        IntentType.NAVIGATE_BACK, IntentType.HOME, IntentType.RECENTS,
        IntentType.OPEN_NOTIFICATIONS, IntentType.READ_NOTIFICATIONS, IntentType.ACCESS_SCREEN,
        IntentType.UI_FOCUS_INPUT, IntentType.UI_SCROLL, IntentType.UI_SEARCH,
        IntentType.TOGGLE_WIFI, IntentType.TOGGLE_MOBILE_DATA, IntentType.TOGGLE_BLUETOOTH,
        IntentType.SET_VOLUME, IntentType.SET_BRIGHTNESS, IntentType.PLAY_MEDIA,
        IntentType.PAUSE_MEDIA, IntentType.STOP_MEDIA, IntentType.NEXT_MEDIA, IntentType.PREVIOUS_MEDIA,
        IntentType.SET_FLASHLIGHT -> true
        IntentType.UI_CLICK_TEXT -> !plan.command.parameters["text"].equals("send", true)
        else -> false
    }

    fun revoke(token: String) = approvalManager.revoke(token)
}
