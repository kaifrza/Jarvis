package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.JarvisCommand

/**
 * Provider-neutral command understanding boundary.
 *
 * The rest of Jarvis consumes only JarvisCommand. A future LLM adapter can
 * implement this contract without receiving Context, Android services,
 * permissions, or the ability to execute actions.
 */
interface CommandUnderstandingEngine {
    fun understand(rawText: String): JarvisCommand
}

class LocalCommandUnderstandingEngine(
    private val parser: IntentParser = IntentParser()
) : CommandUnderstandingEngine {
    override fun understand(rawText: String): JarvisCommand = parser.parse(rawText)
}
