package com.kaifrza.jarvis.core.actions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** A lightweight contact lookup boundary. */
data class ContactMatch(
    val displayName: String,
    val phoneNumber: String
) {
    val normalizedNumber: String
        get() = phoneNumber.filter(Char::isDigit)

    val nationalNumber: String
        get() = normalizedNumber.takeLast(10)
}

class ContactResolver(private val context: Context) {

    fun find(name: String): List<ContactMatch> {
        if (!hasPermission()) return emptyList()
        val query = name.trim()
        if (query.isBlank()) return emptyList()

        val results = mutableListOf<ContactMatch>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        context.contentResolver.query(
            uri,
            projection,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$query%"),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            if (nameIndex < 0 || phoneIndex < 0) return@use

            while (cursor.moveToNext()) {
                val display = cursor.getString(nameIndex)?.trim().orEmpty()
                val phone = cursor.getString(phoneIndex)?.trim().orEmpty()
                if (display.isNotBlank() && phone.isNotBlank()) {
                    results += ContactMatch(display, phone)
                }
            }
        }
        return results.distinctBy { it.normalizedNumber }
    }

    fun findByNumber(number: String): ContactMatch? {
        val digits = number.filter(Char::isDigit)
        if (digits.isBlank() || !hasPermission()) return null
        return findAll().firstOrNull { it.normalizedNumber == digits || it.nationalNumber == digits.takeLast(10) }
    }

    fun chooseByHint(matches: List<ContactMatch>, hint: String): List<ContactMatch> {
        val n = hint.lowercase().trim()
        val digits = n.filter(Char::isDigit)
        if (digits.isBlank()) return emptyList()

        val isLast = n.contains("last") || n.contains("ending") || n.contains("end") || n.contains("aakhir")
        return matches.filter { match ->
            val full = match.normalizedNumber
            val national = match.nationalNumber
            if (isLast) {
                full.endsWith(digits) || national.endsWith(digits)
            } else {
                full.startsWith(digits) || national.startsWith(digits)
            }
        }
    }

    fun describe(matches: List<ContactMatch>): String = matches.mapIndexed { index, match ->
        "${index + 1}. ${match.displayName} — ${mask(match.phoneNumber)}"
    }.joinToString("\n")

    fun mask(number: String): String {
        val digits = number.filter(Char::isDigit)
        if (digits.length <= 4) return number
        return "•••• " + digits.takeLast(4)
    }

    private fun findAll(): List<ContactMatch> {
        if (!hasPermission()) return emptyList()
        val results = mutableListOf<ContactMatch>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            if (nameIndex < 0 || phoneIndex < 0) return@use
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameIndex)?.trim().orEmpty()
                val number = cursor.getString(phoneIndex)?.trim().orEmpty()
                if (name.isNotBlank() && number.isNotBlank()) {
                    results += ContactMatch(name, number)
                }
            }
        }
        return results.distinctBy { it.normalizedNumber }
    }

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED
}
