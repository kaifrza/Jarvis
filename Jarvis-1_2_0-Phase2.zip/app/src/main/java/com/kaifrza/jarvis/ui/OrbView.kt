package com.kaifrza.jarvis.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import kotlin.math.min
import kotlin.math.sin

/**
 * The Jarvis bubble/orb. One circle, one ring, one letter, drawn with Canvas.
 * It only animates (about 30 fps) while the assistant is listening/thinking/acting and is completely
 * static when idle, so it costs nothing on a low-RAM phone.
 */
class OrbView(context: Context) : View(context) {
    var orbState: OrbState = OrbState.IDLE
        set(value) {
            if (field == value) return
            field = value
            updateAnimation()
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        color = Ui.ACCENT_TEXT
    }
    private var phase = 0f
    private var animating = false

    private val tick = object : Runnable {
        override fun run() {
            if (!animating) return
            phase = (phase + 0.045f) % 1f
            invalidate()
            postOnAnimationDelayed(this, 33L)
        }
    }

    private fun colorFor(state: OrbState): Int = when (state) {
        OrbState.IDLE -> Ui.ACCENT_DIM
        OrbState.LISTENING -> Ui.OK
        OrbState.THINKING -> Ui.ACCENT
        OrbState.ACTING -> Ui.WARN
        OrbState.ERROR -> Ui.DANGER
    }

    private fun updateAnimation() {
        val shouldAnimate = orbState != OrbState.IDLE && orbState != OrbState.ERROR && isAttachedToWindow
        if (shouldAnimate && !animating) {
            animating = true
            postOnAnimationDelayed(tick, 33L)
        } else if (!shouldAnimate) {
            animating = false
            removeCallbacks(tick)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnimation()
    }

    override fun onDetachedFromWindow() {
        animating = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val base = min(w, h) / 2f
        val color = colorFor(orbState)
        val pulse = if (animating) (0.5f + 0.5f * sin(phase * 6.2831855f)) else 0f

        ring.color = color
        ring.alpha = if (animating) (90 + (pulse * 110f).toInt()) else 110
        ring.strokeWidth = base * 0.10f
        canvas.drawCircle(cx, cy, base * (0.88f + 0.10f * pulse), ring)

        fill.color = color
        canvas.drawCircle(cx, cy, base * 0.70f, fill)

        letter.textSize = base * 0.85f
        val baseline = cy - (letter.descent() + letter.ascent()) / 2f
        canvas.drawText("J", cx, baseline, letter)
    }
}
