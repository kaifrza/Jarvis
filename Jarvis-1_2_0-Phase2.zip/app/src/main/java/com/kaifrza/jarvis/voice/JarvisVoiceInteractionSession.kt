package com.kaifrza.jarvis.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.view.View
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.brain.BrainTaskRunner
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.ui.JarvisPanel
import com.kaifrza.jarvis.ui.MainActivity
import com.kaifrza.jarvis.ui.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** System-assistant entry point (long-press home). Uses the same native panel as the app and the overlay. */
class JarvisVoiceInteractionSession(private val sessionContext: VoiceInteractionSessionService) : VoiceInteractionSession(sessionContext) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var panel: JarvisPanel? = null
    private var speaker: JarvisSpeaker? = null
    private var voiceController: JarvisVoiceController? = null

    private val container get() = (sessionContext.application as JarvisApplication).container
    private val progress = BrainTaskRunner.ProgressListener { steps -> panel?.post { panel?.showTasks(steps) } }

    override fun onCreateContentView(): View {
        val p = JarvisPanel(sessionContext)
        p.setMessagesHeightPx(Ui.dp(sessionContext, 150))
        p.attach(object : JarvisPanel.Listener {
            override fun onCommand(text: String) = process(text)
            override fun onMic() = startMic()
            override fun onApprove() = processAsync { container.brainTaskRunner.approve() }
            override fun onCancel() = processAsync { container.brainTaskRunner.cancel() }
            override fun onStop() {
                container.brainTaskRunner.requestAbort()
                panel?.show("response", "Rok raha hoon…", "CANCELLED")
            }
            override fun onOpenSettings() = openMain()
        })
        panel = p
        speaker = JarvisSpeaker(sessionContext)
        container.brainTaskRunner.addProgressListener(progress)
        return p
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        panel?.show("status", "", "READY")
    }

    private fun process(text: String) {
        if (text.isBlank()) return
        panel?.show("thinking", "", "THINKING")
        scope.launch {
            val result = runCatching { container.brainTaskRunner.handle(text, "voice-session=true") }
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown error"}") }
            withContext(Dispatchers.Main) { deliver(result) }
        }
    }

    private fun processAsync(block: () -> CommandResponse) {
        scope.launch {
            val result = runCatching(block)
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown error"}") }
            withContext(Dispatchers.Main) { deliver(result) }
        }
    }

    private fun deliver(result: CommandResponse) {
        panel?.show("response", result.message, result.state.name)
        if (result.state == CommandState.SUCCESS) speaker?.speak(result.message)
    }

    private fun startMic() {
        if (ContextCompat.checkSelfPermission(sessionContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            panel?.show("response", "Mic permission nahi hai. Jarvis app kholke Setup chalao, sir.", "FAILED")
            return
        }
        val controller = JarvisVoiceController(sessionContext, object : JarvisVoiceController.Listener {
            override fun onReady() { panel?.show("voice", "Bolo…", "LISTENING") }
            override fun onListening() { panel?.show("voice", "Sun raha hoon…", "LISTENING") }
            override fun onPartial(text: String) { panel?.show("voice", text, "LISTENING") }
            override fun onResult(text: String) {
                panel?.addUserMessage(text)
                process(text)
            }
            override fun onError(message: String) { panel?.show("response", message, "FAILED") }
        })
        voiceController?.destroy()
        voiceController = controller
        controller.start()
    }

    private fun openMain() {
        sessionContext.startActivity(Intent(sessionContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onDestroy() {
        container.brainTaskRunner.removeProgressListener(progress)
        scope.cancel()
        voiceController?.destroy()
        voiceController = null
        speaker?.shutdown()
        speaker = null
        super.onDestroy()
    }
}
