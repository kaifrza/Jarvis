package com.kaifrza.jarvis.core.tools

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.RiskLevel

/** Single source of truth for the capabilities Jarvis may expose to a brain. */
class ToolRegistry {
    private val tools = listOf(
        ToolDescriptor("android_open_app", "Open an installed application by name or alias.", IntentType.OPEN_APP, RiskLevel.LOW, false,
            listOf(ToolParameter("app_name", "Application name", true))),
        ToolDescriptor("android_back", "Navigate back in the foreground application.", IntentType.NAVIGATE_BACK, RiskLevel.LOW, false),
        ToolDescriptor("android_home", "Go to the Android home screen.", IntentType.HOME, RiskLevel.LOW, false),
        ToolDescriptor("android_recents", "Open Android recent apps.", IntentType.RECENTS, RiskLevel.LOW, false),
        ToolDescriptor("android_notifications", "Open the Android notification shade.", IntentType.OPEN_NOTIFICATIONS, RiskLevel.LOW, false),
        ToolDescriptor("android_read_notifications", "Read recent notifications exposed through Notification Access.", IntentType.READ_NOTIFICATIONS, RiskLevel.MEDIUM, false),
        ToolDescriptor("android_screen_observe", "Read a compact semantic snapshot of the visible screen through Accessibility.", IntentType.ACCESS_SCREEN, RiskLevel.MEDIUM, false),
        ToolDescriptor("android_set_volume", "Set or adjust a volume stream. stream: media (default), ring, alarm, notification, call, system. Use level (0-100) for an absolute value, or mode=up/down/min/unmute with optional delta.", IntentType.SET_VOLUME, RiskLevel.LOW, false,
            listOf(ToolParameter("stream", "media, ring, alarm, notification, call or system (default media)", false), ToolParameter("level", "0-100 absolute level", false), ToolParameter("mode", "set, up, down, min or unmute", false), ToolParameter("delta", "Percent to change when mode is up/down", false))),
        ToolDescriptor("android_set_brightness", "Set or adjust screen brightness. Use level (1-100) for an absolute value, or mode=up/down with optional delta.", IntentType.SET_BRIGHTNESS, RiskLevel.LOW, false,
            listOf(ToolParameter("level", "1-100 absolute level", false), ToolParameter("mode", "set, up, down or min", false), ToolParameter("delta", "Percent to change when mode is up/down", false))),
        ToolDescriptor("android_ringer_mode", "Set the ringer mode: normal, vibrate or silent.", IntentType.SET_RINGER_MODE, RiskLevel.LOW, false, listOf(ToolParameter("mode", "normal, vibrate or silent", true))),
        ToolDescriptor("android_dnd", "Turn Do Not Disturb on or off.", IntentType.SET_DND, RiskLevel.LOW, false, listOf(ToolParameter("enabled", "true or false", true), ToolParameter("level", "priority, alarms or total (optional)", false))),
        ToolDescriptor("android_auto_brightness", "Turn adaptive/auto brightness on or off.", IntentType.SET_AUTO_BRIGHTNESS, RiskLevel.LOW, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("android_rotation_lock", "Lock (portrait) or unlock auto-rotate.", IntentType.SET_ROTATION_LOCK, RiskLevel.LOW, false, listOf(ToolParameter("locked", "true or false", true))),
        ToolDescriptor("android_toggle_airplane", "Turn airplane mode on or off through the Quick Settings tile.", IntentType.TOGGLE_AIRPLANE, RiskLevel.MEDIUM, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("android_toggle_location", "Turn location on or off through the Quick Settings tile.", IntentType.TOGGLE_LOCATION, RiskLevel.MEDIUM, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("android_toggle_hotspot", "Turn the personal hotspot on or off through the Quick Settings tile.", IntentType.TOGGLE_HOTSPOT, RiskLevel.MEDIUM, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("android_toggle_tile", "Tap a named Quick Settings tile (eye protection, dark mode, low power mode, super battery saver, bedtime mode).", IntentType.TOGGLE_QS_TILE, RiskLevel.LOW, false, listOf(ToolParameter("tile", "Tile name", true), ToolParameter("enabled", "true or false (optional)", false))),
        ToolDescriptor("android_media_play", "Resume media playback.", IntentType.PLAY_MEDIA, RiskLevel.LOW, false),
        ToolDescriptor("android_media_pause", "Pause media playback.", IntentType.PAUSE_MEDIA, RiskLevel.LOW, false),
        ToolDescriptor("android_media_stop", "Stop media playback.", IntentType.STOP_MEDIA, RiskLevel.LOW, false),
        ToolDescriptor("android_media_next", "Skip to the next media item.", IntentType.NEXT_MEDIA, RiskLevel.LOW, false),
        ToolDescriptor("android_media_previous", "Go to the previous media item.", IntentType.PREVIOUS_MEDIA, RiskLevel.LOW, false),
        ToolDescriptor("android_create_alarm", "Open the system alarm creation flow for a requested time.", IntentType.CREATE_ALARM, RiskLevel.LOW, false, listOf(ToolParameter("hour", "Hour", true), ToolParameter("minute", "Minute", false), ToolParameter("ampm", "am or pm", false))),
        ToolDescriptor("communication_call", "Place a phone call directly after one-time Android permission setup.", IntentType.MAKE_CALL, RiskLevel.HIGH, true,
            listOf(ToolParameter("contact_name", "Contact name", false), ToolParameter("phone_number", "Phone number", false))),
        ToolDescriptor("communication_send_message", "Send an SMS directly after one-time Android permission setup.", IntentType.SEND_MESSAGE, RiskLevel.HIGH, true,
            listOf(ToolParameter("contact_name", "Contact name", false), ToolParameter("phone_number", "Phone number", false), ToolParameter("message", "Message body", true))),
        ToolDescriptor("ui_click_text", "Click visible text in the foreground app through Accessibility.", IntentType.UI_CLICK_TEXT, RiskLevel.LOW, false,
            listOf(ToolParameter("text", "Visible text to click", true), ToolParameter("message_preview", "Optional message preview for verification", false), ToolParameter("contact_name", "Optional recipient label", false))),
        ToolDescriptor("ui_type_text", "Type or replace text in the focused editable field through Accessibility.", IntentType.UI_TYPE_TEXT, RiskLevel.LOW, false,
            listOf(ToolParameter("text", "Text to type", true))),
        ToolDescriptor("ui_focus_input", "Focus the most likely editable text field in the foreground app.", IntentType.UI_FOCUS_INPUT, RiskLevel.LOW, false),
        ToolDescriptor("ui_scroll", "Scroll the foreground app through Accessibility.", IntentType.UI_SCROLL, RiskLevel.LOW, false,
            listOf(ToolParameter("direction", "up or down", true))),
        ToolDescriptor("ui_search", "Search the current foreground app or page using its visible search/input UI.", IntentType.UI_SEARCH, RiskLevel.LOW, false,
            listOf(ToolParameter("query", "Search query", true))),
        ToolDescriptor("android_network_settings", "Open Android network settings. Direct mobile-data switching remains OS restricted.", IntentType.OPEN_NETWORK_SETTINGS, RiskLevel.LOW, false),
        ToolDescriptor("android_wifi_settings", "Open Android Wi-Fi settings.", IntentType.OPEN_WIFI_SETTINGS, RiskLevel.LOW, false),
        ToolDescriptor("android_bluetooth_settings", "Open Android Bluetooth settings.", IntentType.OPEN_BLUETOOTH_SETTINGS, RiskLevel.LOW, false),
        ToolDescriptor("android_toggle_wifi", "Turn Wi-Fi on or off using Android/Accessibility controls.", IntentType.TOGGLE_WIFI, RiskLevel.MEDIUM, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("android_toggle_mobile_data", "Turn mobile data on or off using available Android/Accessibility controls.", IntentType.TOGGLE_MOBILE_DATA, RiskLevel.MEDIUM, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("android_toggle_bluetooth", "Turn Bluetooth on or off using Android/Accessibility controls.", IntentType.TOGGLE_BLUETOOTH, RiskLevel.MEDIUM, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("android_flashlight", "Turn the phone flashlight on or off.", IntentType.SET_FLASHLIGHT, RiskLevel.LOW, false, listOf(ToolParameter("enabled", "true or false", true))),
        ToolDescriptor("calculator", "Perform a simple arithmetic calculation offline.", IntentType.CALCULATE, RiskLevel.LOW, false, listOf(ToolParameter("expression", "Arithmetic expression", true)))
    )

    private val byId = tools.associateBy { it.id }
    private val byIntent = tools.associateBy { it.intent }

    fun all(): List<ToolDescriptor> = tools
    fun find(id: String): ToolDescriptor? = byId[id]
    fun find(intent: IntentType): ToolDescriptor? = byIntent[intent]

    fun validate(call: ToolCall): ToolValidation {
        val descriptor = find(call.toolId)
            ?: return ToolValidation(false, "Unknown tool: ${call.toolId}")
        val missing = descriptor.parameters.filter { it.required && call.arguments[it.name].isNullOrBlank() }
        if (missing.isNotEmpty()) return ToolValidation(false, "Missing required parameter(s): ${missing.joinToString { it.name }}")
        if ((call.toolId == "android_set_volume" || call.toolId == "android_set_brightness") &&
            call.arguments["level"].isNullOrBlank() && call.arguments["mode"].isNullOrBlank()) {
            return ToolValidation(false, "Provide level or mode.")
        }
        if (call.toolId == "communication_call" &&
            call.arguments["contact_name"].isNullOrBlank() && call.arguments["phone_number"].isNullOrBlank()) {
            return ToolValidation(false, "A call needs either contact_name or phone_number.")
        }
        if (call.toolId == "communication_send_message" &&
            call.arguments["contact_name"].isNullOrBlank() && call.arguments["phone_number"].isNullOrBlank()) {
            return ToolValidation(false, "A message needs either contact_name or phone_number.")
        }
        return ToolValidation(true)
    }

    /** OpenAI-compatible function schema. Providers that support tools can consume this directly. */
    fun openAiToolsJson(): org.json.JSONArray = org.json.JSONArray().apply {
        tools.forEach { tool ->
            val properties = org.json.JSONObject()
            val required = org.json.JSONArray()
            tool.parameters.forEach { parameter ->
                properties.put(parameter.name, org.json.JSONObject().put("type", "string").put("description", parameter.description))
                if (parameter.required) required.put(parameter.name)
            }
            put(org.json.JSONObject()
                .put("type", "function")
                .put("function", org.json.JSONObject()
                    .put("name", tool.id)
                    .put("description", tool.description)
                    .put("parameters", org.json.JSONObject()
                        .put("type", "object")
                        .put("properties", properties)
                        .put("required", required)
                        .put("additionalProperties", false))))
        }
    }

    /** Compact schema text for provider prompts; intentionally provider-neutral. */
    fun promptSchema(): String = buildString {
        appendLine("Available tools:")
        tools.forEach { tool ->
            append("- ").append(tool.id).append(": ").append(tool.description)
            if (tool.parameters.isNotEmpty()) {
                append(" params=")
                append(tool.parameters.joinToString(",") { "${it.name}${if (it.required) "*" else ""}" })
            }
            appendLine()
        }
        appendLine("Return only JSON: {\"reply\":string,\"steps\":[{\"tool\":string,\"arguments\":{string:string},\"rationale\":string?}]}")
    }
}
