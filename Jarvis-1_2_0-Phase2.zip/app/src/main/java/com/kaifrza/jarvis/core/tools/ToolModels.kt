package com.kaifrza.jarvis.core.tools

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.RiskLevel

/**
 * Public contract exposed to the planning brain. Tools describe capabilities;
 * they do not contain Android execution code.
 */
data class ToolDescriptor(
    val id: String,
    val description: String,
    val intent: IntentType,
    val risk: RiskLevel,
    val requiresConfirmation: Boolean,
    val parameters: List<ToolParameter> = emptyList()
)

data class ToolParameter(
    val name: String,
    val description: String,
    val required: Boolean = false
)

data class ToolCall(
    val toolId: String,
    val arguments: Map<String, String> = emptyMap()
)

data class ToolValidation(
    val valid: Boolean,
    val reason: String? = null
)
