package com.kaifrza.jarvis.core.health

import android.content.Context
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.ui.PermissionCenter

/** Live permission/service health. Every check is a cheap system call, safe to poll once a second. */
object JarvisHealth {
    fun snapshot(context: Context): List<HealthItem> {
        val accessibility = PermissionCenter.isAccessibilityEnabled(context)
        val connected = JarvisAccessibilityService.instance != null
        return listOf(
            HealthItem(
                "accessibility", "Accessibility service",
                accessibility && connected, true,
                if (!accessibility) "ON karo (Settings > Accessibility > Jarvis)" else "Enabled hai par connect nahi hui, ON-OFF karke dekho"
            ),
            HealthItem(
                "runtime", "Mic, Contacts, Call, SMS",
                PermissionCenter.runtimePermissionsReady(context), true,
                "Allow karna baaki hai"
            ),
            HealthItem(
                "write_settings", "System settings badalna (brightness, rotation)",
                PermissionCenter.canWriteSettings(context), false,
                "Modify system settings allow karo"
            ),
            HealthItem(
                "dnd", "Do Not Disturb / Silent control",
                PermissionCenter.isDndAccessGranted(context), false,
                "Do Not Disturb access allow karo"
            ),
            HealthItem(
                "notifications", "Notification access",
                PermissionCenter.isNotificationAccessEnabled(context), false,
                "Notification access allow karo"
            ),
            HealthItem(
                "battery", "Battery restriction hata di",
                PermissionCenter.isIgnoringBatteryOptimizations(context), false,
                "Battery optimization se Jarvis ko bahar karo (warna Vivo band kar dega)"
            )
        )
    }
}
