package com.kaifrza.jarvis.core.brain

data class BrainConfig(
    val enabled: Boolean = false,
    val endpoint: String = "",
    val model: String = "",
    val apiKey: String = ""
)
