package com.kaifrza.jarvis.core.actions

import android.os.SystemClock

/**
 * Navigation is intentionally kept behind a controller boundary.
 *
 * Accessibility-based back/home execution will be wired here rather than
 * granting the AI direct access to AccessibilityService.
 */
class NavigationController {
    fun canNavigate(): Boolean = true

    fun noteNavigationRequested() {
        // Controller hook for the accessibility implementation.
        // No direct hidden/system API is used here.
        SystemClock.uptimeMillis()
    }
}
