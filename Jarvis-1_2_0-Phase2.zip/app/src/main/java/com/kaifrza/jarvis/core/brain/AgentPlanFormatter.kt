package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.model.BrainPlan
import org.json.JSONArray
import org.json.JSONObject

/** Converts the internal plan into a stable, inspectable representation for logs/UI. */
object AgentPlanFormatter {
    fun toJson(plan: BrainPlan): String {
        val steps = JSONArray()
        plan.steps.forEach { step ->
            steps.put(JSONObject()
                .put("command_id", step.command.id)
                .put("intent", step.command.intent.name)
                .put("raw_text", step.command.rawText)
                .put("parameters", JSONObject(step.command.parameters))
                .put("rationale", step.rationale ?: JSONObject.NULL)
                .put("task_id", step.taskId)
                .put("task_label", step.taskLabel))
        }
        return JSONObject()
            .put("plan_id", plan.id)
            .put("reply", plan.reply ?: JSONObject.NULL)
            .put("source", plan.source)
            .put("steps", steps)
            .toString()
    }
}
