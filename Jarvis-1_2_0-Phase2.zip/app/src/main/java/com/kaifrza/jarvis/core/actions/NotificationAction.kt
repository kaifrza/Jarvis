package com.kaifrza.jarvis.core.actions

import android.content.Context
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.notifications.JarvisNotificationListenerService

class NotificationAction(private val context: Context) : JarvisAction {
    override val id = "android.notifications.read"
    override fun validate(plan: ActionPlan): ActionResult = if (JarvisNotificationListenerService.instance == null) {
        ActionResult.Failure("Notification access ek baar Android Settings mein Jarvis ke liye enable karo.")
    } else ActionResult.Success

    override fun execute(plan: ActionPlan): ActionResult {
        if (plan.command.intent != IntentType.READ_NOTIFICATIONS) return ActionResult.Failure("Unsupported notification action.")
        val items = JarvisNotificationListenerService.instance?.recentNotifications().orEmpty()
        if (items.isEmpty()) return ActionResult.SuccessWithMessage("Abhi koi recent notification nahi mili.")
        val text = items.take(8).joinToString("\n") { "• ${it.app}: ${it.title}${if (it.text.isBlank()) "" else " — ${it.text}"}" }
        return ActionResult.SuccessWithMessage("Recent notifications:\n$text")
    }

    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success
}
