package com.kaifrza.jarvis.core.conversation

import java.util.ArrayDeque

/** Small in-memory conversation window. Sensitive values are deliberately not persisted. */
class ConversationManager(private val maxTurns: Int = 12) {
    data class Turn(val user: String, val assistant: String)

    private val turns = ArrayDeque<Turn>()

    @Synchronized
    fun add(user: String, assistant: String) {
        turns.addLast(Turn(user.trim(), assistant.trim()))
        while (turns.size > maxTurns) turns.removeFirst()
    }

    @Synchronized
    fun recent(limit: Int = maxTurns): List<Turn> = turns.toList().takeLast(limit.coerceAtLeast(0))

    @Synchronized
    fun context(): String = recent().joinToString("\n") { "User: ${it.user}\nJarvis: ${it.assistant}" }

    @Synchronized
    fun clear() = turns.clear()
}
