package com.kaifrza.jarvis.core.health

data class HealthItem(
    val id: String,
    val title: String,
    val ok: Boolean,
    /** Required items block normal use; optional ones only disable specific features. */
    val required: Boolean,
    val hint: String
)

enum class Readiness { READY, DEGRADED, NEEDS_SETUP }

object HealthModel {
    fun readiness(items: List<HealthItem>): Readiness = when {
        items.any { it.required && !it.ok } -> Readiness.NEEDS_SETUP
        items.any { !it.ok } -> Readiness.DEGRADED
        else -> Readiness.READY
    }

    fun missing(items: List<HealthItem>): List<HealthItem> = items.filter { !it.ok }

    fun label(readiness: Readiness): String = when (readiness) {
        Readiness.READY -> "READY"
        Readiness.DEGRADED -> "KUCH FEATURES BAND"
        Readiness.NEEDS_SETUP -> "SETUP BAAKI"
    }
}
