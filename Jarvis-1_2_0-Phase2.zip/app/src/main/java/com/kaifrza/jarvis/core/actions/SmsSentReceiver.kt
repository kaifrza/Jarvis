package com.kaifrza.jarvis.core.actions

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.concurrent.ConcurrentHashMap

/** Receives Android SMS sent results so Jarvis does not report a blind success. */
class SmsSentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val commandId = action.substringAfter(".SMS_SENT.", "").substringBefore(".part.")
        if (commandId.isBlank()) return
        Results.complete(commandId, resultCode == android.app.Activity.RESULT_OK)
    }

    companion object Results {
        private data class Pending(val expected: Int, var received: Int = 0, var success: Boolean = true)
        private val pending = ConcurrentHashMap<String, Pending>()

        fun register(commandId: String, expected: Int) {
            pending[commandId] = Pending(expected.coerceAtLeast(1))
        }

        @Synchronized
        fun complete(commandId: String, success: Boolean) {
            val item = pending[commandId] ?: return
            item.received++
            item.success = item.success && success
        }

        fun await(commandId: String, timeoutMs: Long = 15_000L): Boolean? {
            val deadline = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < deadline) {
                val item = pending[commandId]
                if (item != null && item.received >= item.expected) {
                    pending.remove(commandId)
                    return item.success
                }
                Thread.sleep(100L)
            }
            pending.remove(commandId)
            return null
        }

        fun cancel(commandId: String) {
            pending.remove(commandId)
        }
    }
}
