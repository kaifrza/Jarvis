package com.kaifrza.jarvis.accessibility

import android.Manifest
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.brain.BrainTaskRunner
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.ui.JarvisPanel
import com.kaifrza.jarvis.ui.MainActivity
import com.kaifrza.jarvis.ui.OrbState
import com.kaifrza.jarvis.ui.OrbView
import com.kaifrza.jarvis.ui.PanelModel
import com.kaifrza.jarvis.ui.Ui
import com.kaifrza.jarvis.voice.JarvisSpeaker
import com.kaifrza.jarvis.voice.JarvisVoiceController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Cross-app surface: a draggable native orb bubble and a light native panel.
 *
 * - The orb is static when idle and only animates while Jarvis is busy.
 * - The panel window is NOT focusable by default, so the app underneath keeps focus (and the
 *   accessibility tree keeps pointing at it). It becomes focusable only while the user types.
 * - Voice engine and TTS are created when the panel opens and released when it closes.
 */
class OverlayController(private val service: JarvisAccessibilityService) {
    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val container get() = (service.application as JarvisApplication).container
    private val prefs = service.getSharedPreferences("jarvis_ui", Context.MODE_PRIVATE)

    private var orb: OrbView? = null
    private var orbParams: WindowManager.LayoutParams? = null
    private var panel: JarvisPanel? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var voice: JarvisVoiceController? = null
    private var speaker: JarvisSpeaker? = null
    private var docked = false
    private var dockAnim: ValueAnimator? = null
    private val dockRunnable = Runnable { dockBubble() }

    private val progress = BrainTaskRunner.ProgressListener { steps ->
        main.post {
            panel?.showTasks(steps)
            if (steps.any { it.state == "RUNNING" }) setOrb(OrbState.ACTING)
        }
    }

    fun start() {
        addBubble()
        container.brainTaskRunner.addProgressListener(progress)
    }

    fun stop() {
        main.removeCallbacks(dockRunnable)
        container.brainTaskRunner.removeProgressListener(progress)
        hidePanel()
        orb?.let { runCatching { windowManager.removeView(it) } }
        orb = null
        orbParams = null
        scope.cancel()
    }

    /** Shows or hides the bubble according to the saved setting. */
    fun applyBubbleSetting() {
        val visible = prefs.getBoolean("bubble_visible", true)
        main.post { orb?.visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE }
    }

    fun togglePanel() { if (panel != null) hidePanel() else showPanel() }

    // ---------------------------------------------------------------- bubble

    private fun addBubble() {
        if (orb != null) return
        val size = Ui.dp(service, 54)
        val dm = service.resources.displayMetrics
        val view = OrbView(service)
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("bubble_x", dm.widthPixels - size - Ui.dp(service, 4))
            y = prefs.getInt("bubble_y", dm.heightPixels / 3)
        }
        val slop = ViewConfiguration.get(service).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var downTime = 0L
        view.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    main.removeCallbacks(dockRunnable)
                    if (docked) undockNow()
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    downTime = SystemClock.uptimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) + abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = (startX + dx).coerceIn(0, (dm.widthPixels - size).coerceAtLeast(0))
                        params.y = (startY + dy).coerceIn(0, (dm.heightPixels - size).coerceAtLeast(0))
                        runCatching { windowManager.updateViewLayout(v, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        // Snap to the nearest vertical screen edge and remember the spot.
                        params.x = if (params.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
                        runCatching { windowManager.updateViewLayout(v, params) }
                        prefs.edit().putInt("bubble_x", params.x).putInt("bubble_y", params.y).apply()
                    } else if (SystemClock.uptimeMillis() - downTime > 700L) {
                        openApp()
                    } else {
                        togglePanel()
                    }
                    scheduleDock()
                    true
                }
                else -> true
            }
        }
        windowManager.addView(view, params)
        orb = view
        orbParams = params
        applyBubbleSetting()
        scheduleDock()
    }

    // ---------------------------------------------------------------- edge docking

    /** After the user lets go: rest fully visible at the edge for ~1.5 s, then slide half-way into the edge. */
    private fun scheduleDock() {
        main.removeCallbacks(dockRunnable)
        main.postDelayed(dockRunnable, 1_500L)
    }

    private fun dockBubble() {
        val view = orb ?: return
        val params = orbParams ?: return
        // Stay fully visible while Jarvis is busy or its panel is open; try again later.
        if (panel != null || view.orbState != OrbState.IDLE) {
            scheduleDock()
            return
        }
        val dm = service.resources.displayMetrics
        val size = params.width
        val leftSide = params.x + size / 2 < dm.widthPixels / 2
        val target = if (leftSide) -size / 2 else dm.widthPixels - size / 2
        docked = true
        animateX(params, target)
        params.alpha = 0.7f
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    private fun undockNow() {
        dockAnim?.cancel()
        val view = orb ?: return
        val params = orbParams ?: return
        val dm = service.resources.displayMetrics
        val size = params.width
        params.x = if (params.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
        params.alpha = 1f
        docked = false
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    private fun animateX(params: WindowManager.LayoutParams, target: Int) {
        val view = orb ?: return
        dockAnim?.cancel()
        dockAnim = ValueAnimator.ofInt(params.x, target).apply {
            duration = 160L
            addUpdateListener {
                params.x = it.animatedValue as Int
                runCatching { windowManager.updateViewLayout(view, params) }
            }
            start()
        }
    }

    private fun setOrb(state: OrbState) {
        orb?.orbState = state
        panel?.setOrb(state)
    }

    // ---------------------------------------------------------------- panel

    private fun showPanel() {
        if (panel != null) return
        main.removeCallbacks(dockRunnable)
        if (docked) undockNow()
        val dm = service.resources.displayMetrics
        val p = JarvisPanel(service)
        p.setMessageLimit(10)
        p.setMessagesHeightPx(Ui.dp(service, 130))
        val panelWidth = (dm.widthPixels * 0.94f).toInt()
        val params = WindowManager.LayoutParams(
            panelWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("panel_x", (dm.widthPixels - panelWidth) / 2)
            y = prefs.getInt("panel_y", Ui.dp(service, 60))
        }
        p.setCloseVisible(true)
        p.onClose = { hidePanel() }
        var dragX = 0f
        var dragY = 0f
        var startX = 0
        var startY = 0
        p.dragHandle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragX = e.rawX; dragY = e.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX + (e.rawX - dragX).toInt()).coerceIn(0, (dm.widthPixels - panelWidth).coerceAtLeast(0))
                    params.y = (startY + (e.rawY - dragY).toInt()).coerceIn(0, (dm.heightPixels - Ui.dp(service, 120)).coerceAtLeast(0))
                    runCatching { windowManager.updateViewLayout(p, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("panel_x", params.x).putInt("panel_y", params.y).apply()
                    true
                }
                else -> true
            }
        }
        p.onInputTouched = {
            setPanelFocusable(true)
            main.postDelayed({ p.focusInput() }, 140L)
        }
        p.attach(object : JarvisPanel.Listener {
            override fun onCommand(text: String) {
                setPanelFocusable(false)
                process(text)
            }
            override fun onMic() = startMic()
            override fun onApprove() = runAsync { container.brainTaskRunner.approve() }
            override fun onCancel() = runAsync { container.brainTaskRunner.cancel() }
            override fun onStop() {
                container.brainTaskRunner.requestAbort()
                show("response", "Rok raha hoon…", "CANCELLED")
            }
            override fun onOpenSettings() = openApp()
        })
        windowManager.addView(p, params)
        panel = p
        panelParams = params
        show("status", "", "READY")
    }

    private fun hidePanel() {
        voice?.destroy(); voice = null
        speaker?.shutdown(); speaker = null
        panel?.let {
            it.hideKeyboard()
            runCatching { windowManager.removeView(it) }
        }
        panel = null
        panelParams = null
        setOrb(OrbState.IDLE)
        scheduleDock()
    }

    private fun setPanelFocusable(focusable: Boolean) {
        val params = panelParams ?: return
        val view = panel ?: return
        params.flags = if (focusable) {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    private fun show(type: String, message: String, state: String) {
        panel?.show(type, message, state)
        orb?.orbState = PanelModel.orbFor(type, state)
    }

    // ---------------------------------------------------------------- running commands

    private fun process(raw: String) {
        if (raw.isBlank()) return
        // Give focus back to the app underneath (keyboard down, panel non-focusable) before acting.
        panel?.hideKeyboard()
        setPanelFocusable(false)
        show("thinking", "", "THINKING")
        scope.launch {
            val result = runCatching {
                container.brainTaskRunner.handle(raw, "foreground=${service.foregroundPackage ?: "unknown"}")
            }.getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown"}") }
            withContext(Dispatchers.Main) { deliver(result) }
        }
    }

    private fun runAsync(block: () -> CommandResponse) {
        scope.launch {
            val result = runCatching(block)
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown"}") }
            withContext(Dispatchers.Main) { deliver(result) }
        }
    }

    private fun deliver(result: CommandResponse) {
        show("response", result.message, result.state.name)
        if (result.state == CommandState.SUCCESS) speak(result.message)
    }

    private fun speak(text: String) {
        if (panel == null) return
        val s = speaker ?: JarvisSpeaker(service).also { speaker = it }
        s.speak(text)
    }

    private fun startMic() {
        panel?.hideKeyboard()
        setPanelFocusable(false)
        if (ContextCompat.checkSelfPermission(service, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            show("response", "Mic permission nahi hai. Jarvis app kholke Setup chalao, sir.", "FAILED")
            return
        }
        val v = voice ?: JarvisVoiceController(service, object : JarvisVoiceController.Listener {
            override fun onReady() = show("voice", "Bolo…", "LISTENING")
            override fun onListening() = show("voice", "Sun raha hoon…", "LISTENING")
            override fun onPartial(text: String) = show("voice", text, "LISTENING")
            override fun onResult(text: String) {
                panel?.addUserMessage(text)
                process(text)
            }
            override fun onError(message: String) = show("response", message, "FAILED")
        }).also { voice = it }
        v.start()
    }

    private fun openApp() {
        service.startActivity(
            Intent(service, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }
}
