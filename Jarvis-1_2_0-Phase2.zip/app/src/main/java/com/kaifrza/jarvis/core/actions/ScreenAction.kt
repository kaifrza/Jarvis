package com.kaifrza.jarvis.core.actions

import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType

class ScreenAction : JarvisAction {
    override val id = "android.screen.observe"
    override fun validate(plan: ActionPlan): ActionResult = if (JarvisAccessibilityService.instance == null) ActionResult.Failure("Accessibility Service is unavailable.") else ActionResult.Success
    override fun execute(plan: ActionPlan): ActionResult {
        if (plan.command.intent != IntentType.ACCESS_SCREEN) return ActionResult.Failure("Unsupported screen action.")
        val snapshot = JarvisAccessibilityService.instance?.visibleScreenSnapshot().orEmpty()
        return if (snapshot.isBlank()) ActionResult.SuccessWithMessage("Screen par readable text nahi mila.") else ActionResult.SuccessWithMessage(snapshot)
    }
    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success
}
