package com.kaifrza.jarvis.accessibility

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.kaifrza.jarvis.ui.MainActivity
import com.kaifrza.jarvis.ui.PermissionCenter

/**
 * One-time guided setup. After the user switches Accessibility ON (the only step Android never lets an
 * app do itself), Jarvis opens every remaining permission page and taps the switch / "Allow" itself.
 * It never turns a permission OFF, and every step is idempotent (already-granted steps are skipped).
 */
object PermissionAutopilot {
    enum class State { PENDING, RUNNING, OK, FAILED, SKIPPED }

    data class Step(val id: String, val title: String, val state: State, val note: String = "")

    const val EXTRA_REQUEST_RUNTIME = "jarvis_request_runtime"

    @Volatile var running = false
        private set

    @Volatile var steps: List<Step> = emptyList()
        private set

    fun start(service: JarvisAccessibilityService): Boolean {
        if (running) return false
        running = true
        steps = definitions().map { Step(it.first, it.second, State.PENDING) }
        Thread({ runAll(service) }, "jarvis-autopilot").start()
        return true
    }

    private fun definitions(): List<Pair<String, String>> = buildList {
        add("runtime" to "Mic, Contacts, Call, SMS")
        add("write_settings" to "System settings badalna")
        add("notifications" to "Notification access")
        add("dnd" to "Do Not Disturb access")
        add("battery" to "Battery restriction")
        if (PermissionCenter.isVivoFamily()) add("autostart" to "Vivo autostart (best effort)")
    }

    private fun update(id: String, state: State, note: String = "") {
        steps = steps.map { if (it.id == id) it.copy(state = state, note = note) else it }
    }

    private fun runAll(service: JarvisAccessibilityService) {
        val ctx: Context = service.applicationContext
        try {
            for ((id, _) in definitions()) {
                update(id, State.RUNNING)
                val result = runCatching { runStep(id, service, ctx) }
                    .getOrElse { State.FAILED to (it.message ?: "error") }
                update(id, result.first, result.second)
                SystemClock.sleep(300)
            }
        } finally {
            running = false
            // Bring Jarvis back to the front so the user sees the result.
            runCatching {
                service.startActivity(
                    Intent(service, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            }
        }
    }

    private fun runStep(id: String, s: JarvisAccessibilityService, ctx: Context): Pair<State, String> = when (id) {
        "runtime" -> runtimeStep(s, ctx)
        "write_settings" -> pageStep(s, ctx, { PermissionCenter.canWriteSettings(ctx) }, PermissionCenter.writeSettingsIntent(ctx), rowToTap = false)
        "notifications" -> pageStep(s, ctx, { PermissionCenter.isNotificationAccessEnabled(ctx) }, PermissionCenter.notificationListenerIntent(), rowToTap = true)
        "dnd" -> pageStep(s, ctx, { PermissionCenter.isDndAccessGranted(ctx) }, PermissionCenter.dndAccessIntent(), rowToTap = true)
        "battery" -> batteryStep(s, ctx)
        "autostart" -> autostartStep(s, ctx)
        else -> State.SKIPPED to "unknown step"
    }

    private fun runtimeStep(s: JarvisAccessibilityService, ctx: Context): Pair<State, String> {
        if (PermissionCenter.runtimePermissionsReady(ctx)) return State.OK to "already granted"
        // The Activity owns the runtime-permission request; we only tap "Allow" on the system dialogs.
        s.startActivity(
            Intent(s, MainActivity::class.java)
                .putExtra(EXTRA_REQUEST_RUNTIME, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
        val deadline = SystemClock.uptimeMillis() + 30_000L
        while (SystemClock.uptimeMillis() < deadline) {
            if (PermissionCenter.runtimePermissionsReady(ctx)) return State.OK to "granted"
            s.clickExactText("allow", "always allow", "while using the app", "allow only while using the app", timeoutMs = 600L)
            SystemClock.sleep(250)
        }
        return State.FAILED to "popup allow nahi hua - app mein 'Fix' dabao"
    }

    /**
     * Generic special-permission page. Some pages show a list of apps (tap Jarvis first), some show a
     * single switch. A confirmation dialog with an exact "Allow" button may follow.
     */
    private fun pageStep(
        s: JarvisAccessibilityService,
        ctx: Context,
        granted: () -> Boolean,
        intent: Intent,
        rowToTap: Boolean
    ): Pair<State, String> {
        if (granted()) return State.OK to "already granted"
        repeat(2) { attempt ->
            s.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            SystemClock.sleep(1_000L)
            if (rowToTap) s.clickText("Jarvis")
            SystemClock.sleep(700L)
            if (!s.clickExactText("allow", timeoutMs = 1_200L)) {
                s.setFirstSwitch(true, 1_800L)
                s.clickExactText("allow", timeoutMs = 1_500L)
            }
            SystemClock.sleep(600L)
            if (granted()) {
                backOut(s)
                return State.OK to "granted"
            }
            backOut(s)
            SystemClock.sleep(400L + attempt * 300L)
        }
        return State.FAILED to "page par switch nahi mila - manually allow karo"
    }

    private fun batteryStep(s: JarvisAccessibilityService, ctx: Context): Pair<State, String> {
        if (PermissionCenter.isIgnoringBatteryOptimizations(ctx)) return State.OK to "already granted"
        s.startActivity(PermissionCenter.batteryExemptionIntent(ctx).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        SystemClock.sleep(900L)
        s.clickExactText("allow", "yes", timeoutMs = 2_000L)
        SystemClock.sleep(600L)
        return if (PermissionCenter.isIgnoringBatteryOptimizations(ctx)) State.OK to "granted"
        else State.FAILED to "popup allow nahi hua - Battery settings mein Jarvis ko Unrestricted karo"
    }

    /** Vivo's autostart page is a private OEM screen and its state cannot be read, so this is best effort. */
    private fun autostartStep(s: JarvisAccessibilityService, ctx: Context): Pair<State, String> {
        val components = listOf(
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.PurviewTabActivity"
        )
        var opened = false
        for ((pkg, cls) in components) {
            opened = runCatching {
                s.startActivity(Intent().setClassName(pkg, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            }.getOrDefault(false)
            if (opened) break
        }
        if (!opened) return State.SKIPPED to "Vivo autostart page nahi khuli - manually allow karo"
        SystemClock.sleep(1_000L)
        s.clickText("Jarvis")
        SystemClock.sleep(500L)
        s.setFirstSwitch(true, 1_500L)
        SystemClock.sleep(500L)
        backOut(s)
        return State.SKIPPED to "koshish ki, par check nahi ho sakta - Autostart me Jarvis ON dekh lo"
    }

    private fun backOut(s: JarvisAccessibilityService) {
        repeat(2) {
            s.performGlobalActionBack()
            SystemClock.sleep(350L)
        }
    }
}
