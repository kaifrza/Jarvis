package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.intent.CommandUnderstandingEngine
import com.kaifrza.jarvis.core.intent.OfflineAgentBrain
import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.IntentType
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

interface BrainEngine {
    fun plan(rawText: String, context: String = ""): BrainPlan
}

class HybridBrainEngine(
    private val local: CommandUnderstandingEngine,
    private val remote: RemoteBrainEngine,
    private val validator: BrainPlanValidator,
    private val offlineAgent: OfflineAgentBrain = OfflineAgentBrain()
) : BrainEngine {
    override fun plan(rawText: String, context: String): BrainPlan {
        // Offline agent is always first. Cloud is an optional accelerator, never a dependency.
        val offline = offlineAgent.plan(rawText, context)
        if (offline.steps.isNotEmpty()) return offline

        val localCommand = local.understand(rawText)
        if (localCommand.intent != IntentType.UNKNOWN) {
            return BrainPlan(steps = listOf(BrainStep(localCommand)), source = "offline-local")
        }

        return runCatching { validator.validate(remote.plan(rawText, context)) }
            .getOrElse { BrainPlan(source = "offline-fallback") }
    }
}

/** OpenAI-compatible transport with a provider-neutral JSON fallback contract. */
class RemoteBrainEngine(private val store: BrainStore) : BrainEngine {
    override fun plan(rawText: String, context: String): BrainPlan {
        val cfg = store.read()
        require(cfg.enabled && cfg.endpoint.isNotBlank() && cfg.model.isNotBlank() && cfg.apiKey.isNotBlank()) {
            "Brain is not configured yet."
        }

        val payload = JSONObject()
            .put("model", cfg.model)
            .put("temperature", 0.1)
            .put("tools", com.kaifrza.jarvis.core.tools.ToolRegistry().openAiToolsJson())
            .put("tool_choice", "auto")
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", systemPrompt()))
                .put(JSONObject().put("role", "user").put("content", "Context: $context\n\nCommand: $rawText")))

        val connection = (URL(cfg.endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer ${cfg.apiKey}")
        }
        return try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
            if (connection.responseCode !in 200..299) error("Brain HTTP ${connection.responseCode}")
            parseResponse(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseResponse(body: String): BrainPlan {
        val outer = JSONObject(body)
        val message = outer.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
        val toolCalls = message?.optJSONArray("tool_calls")
        if (toolCalls != null && toolCalls.length() > 0) {
            return BrainJsonParser.parseToolCalls(toolCalls)
        }
        val content = message?.optString("content") ?: outer.optString("output_text", "")
        require(content.isNotBlank()) { "Brain returned no content." }
        return runCatching { BrainJsonParser.parsePlan(content) }
            .getOrElse { BrainPlan(reply = content.trim(), source = "remote") }
    }

    private fun systemPrompt(): String = """
You are Jarvis's planning brain. You do NOT execute actions and you do NOT have Android access.
Return ONLY valid JSON when using the text contract. Never claim an action was executed.
Prefer the tool field over intent.
Schema: {"reply":string,"steps":[{"tool":string,"arguments":{string:string},"rationale":string?}]}
Never invent phone numbers, contact IDs, permissions, or execution results.
${com.kaifrza.jarvis.core.tools.ToolRegistry().promptSchema()}
""".trimIndent()
}
