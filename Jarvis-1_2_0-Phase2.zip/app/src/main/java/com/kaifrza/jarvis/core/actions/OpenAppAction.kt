package com.kaifrza.jarvis.core.actions

import android.content.Context
import android.content.Intent
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan

class OpenAppAction(private val context: Context) : JarvisAction {
    override val id = "android.open_app"

    override fun validate(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["app_name"]
            ?: return ActionResult.Failure("Tell me which app to open.")
        return if (AppResolver(context).findLaunchable(name) != null) {
            ActionResult.Success
        } else {
            ActionResult.Failure("I couldn't find $name among your launchable apps.")
        }
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["app_name"] ?: return ActionResult.Failure("Missing app.")
        val resolved = AppResolver(context).findLaunchable(name)
            ?: return ActionResult.Failure("The app is no longer available.")

        return try {
            resolved.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(resolved)
            ActionResult.Success
        } catch (e: Exception) {
            ActionResult.Failure("Android could not open $name.")
        }
    }

    override fun verify(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["app_name"] ?: return ActionResult.Failure("Missing app.")
        val resolved = AppResolver(context).findLaunchable(name)
            ?: return ActionResult.Failure("The app is no longer available.")
        val expectedPackage = resolved.component?.packageName
            ?: return ActionResult.Failure("I couldn't determine the app package.")
        val service = JarvisAccessibilityService.instance
            ?: return ActionResult.Success // Accessibility is optional for app launching.
        return if (service.waitForForegroundPackage(expectedPackage, 6_000L)) {
            ActionResult.Success
        } else {
            ActionResult.Failure("$name was launched, but I couldn't verify it became the active app.")
        }
    }
}

class AppResolver(private val context: Context) {
    private data class Entry(val label: String, val pkg: String, val activity: String)

    private val synonyms = mapOf(
        "dialer" to listOf("dialer", "phone"),
        "messages" to listOf("messages", "messaging", "message", "sms"),
        "gallery" to listOf("gallery", "photos"),
        "clock" to listOf("clock", "alarm")
    )

    fun findLaunchable(query: String): Intent? {
        val target = query.trim().lowercase()
        if (target.isEmpty()) return null
        val apps = installedApps()
        val candidates = synonyms[target] ?: listOf(target)
        // Exact label first, then prefix, then substring, so "maps" never opens "Google Maps Go Beta Tools".
        val match = candidates.firstNotNullOfOrNull { c -> apps.firstOrNull { it.label == c } }
            ?: candidates.firstNotNullOfOrNull { c -> apps.firstOrNull { it.label.startsWith(c) } }
            ?: candidates.firstNotNullOfOrNull { c -> apps.firstOrNull { it.label.contains(c) } }
            ?: return null
        return Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(match.pkg, match.activity)
        }
    }

    /** The launcher list is cached briefly: a command resolves the same app several times and each scan is slow on low-RAM phones. */
    private fun installedApps(): List<Entry> {
        val now = System.currentTimeMillis()
        cache?.let { if (now - cacheTime < 60_000L) return it }
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(launcher, 0).map {
            Entry(it.loadLabel(pm).toString().lowercase(), it.activityInfo.packageName, it.activityInfo.name)
        }
        cache = list
        cacheTime = now
        return list
    }

    private companion object {
        @Volatile private var cache: List<Entry>? = null
        @Volatile private var cacheTime = 0L
    }
}
