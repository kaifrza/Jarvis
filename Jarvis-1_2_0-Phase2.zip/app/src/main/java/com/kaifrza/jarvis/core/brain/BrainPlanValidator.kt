package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.tools.ToolCall
import com.kaifrza.jarvis.core.tools.ToolRegistry

/** Validates a model-produced plan before Android execution is even considered. */
class BrainPlanValidator(private val tools: ToolRegistry) {
    fun validate(plan: BrainPlan): BrainPlan {
        require(plan.steps.size <= 12) { "Brain produced too many steps." }
        plan.steps.forEach { step ->
            require(step.command.intent != IntentType.UNKNOWN) { "Brain produced an unknown action." }
            val descriptor = tools.find(step.command.intent)
                ?: error("Tool is not registered for ${step.command.intent}.")
            val validation = tools.validate(ToolCall(descriptor.id, step.command.parameters))
            require(validation.valid) { validation.reason ?: "Invalid tool arguments." }
        }
        return plan
    }
}
