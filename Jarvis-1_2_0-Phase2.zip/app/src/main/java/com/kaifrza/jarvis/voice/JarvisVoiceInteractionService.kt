package com.kaifrza.jarvis.voice

import android.os.Bundle
import android.service.voice.VoiceInteractionService

/** Optional system-assistant entry point. The heavy UI lives in VoiceInteractionSession. */
class JarvisVoiceInteractionService : VoiceInteractionService() {
    companion object {
        @Volatile var instance: JarvisVoiceInteractionService? = null
            private set
    }

    override fun onReady() {
        super.onReady()
        instance = this
    }

    fun showJarvis() {
        showSession(Bundle(), 0)
    }

    override fun onShutdown() {
        instance = null
        super.onShutdown()
    }
}
