package com.kaifrza.jarvis

import android.app.Application
import com.kaifrza.jarvis.core.JarvisContainer

class JarvisApplication : Application() {
    lateinit var container: JarvisContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = JarvisContainer(this)
    }
}
