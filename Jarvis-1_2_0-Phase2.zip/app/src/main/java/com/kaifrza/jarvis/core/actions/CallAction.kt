package com.kaifrza.jarvis.core.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.core.model.ActionPlan

class CallAction(
    private val context: Context,
    private val resolver: ContactResolver
) : JarvisAction {

    override val id = "communication.call"

    override fun validate(plan: ActionPlan): ActionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("Phone permission is required to place the call.")
        }

        val number = plan.command.parameters["phone_number"]
        if (!number.isNullOrBlank()) {
            return if (number.filter(Char::isDigit).length >= 7) ActionResult.Success
            else ActionResult.Failure("That phone number doesn't look valid.")
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("Contacts permission is required to find the person.")
        }

        val name = plan.command.parameters["contact_name"]
            ?: return ActionResult.Failure("Tell me who to call.")
        val matches = resolver.find(name)
        return if (matches.size == 1) ActionResult.Success
        else if (matches.isEmpty()) ActionResult.Failure("I couldn't find $name in your contacts.")
        else ActionResult.Failure("I found multiple contacts matching $name. Tell me which number.")
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val directNumber = plan.command.parameters["phone_number"]
        val number = if (!directNumber.isNullOrBlank()) {
            directNumber
        } else {
            val name = plan.command.parameters["contact_name"]
                ?: return ActionResult.Failure("Missing contact.")
            resolver.find(name).singleOrNull()?.phoneNumber
                ?: return ActionResult.Failure("The contact became ambiguous or unavailable.")
        }

        return try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.fromParts("tel", number, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult.Success
        } catch (e: SecurityException) {
            ActionResult.Failure("Android denied the call permission.")
        } catch (e: Exception) {
            ActionResult.Failure("The call could not be started.")
        }
    }

    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success
}
