package com.kaifrza.jarvis.core.security

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class ApprovalManager {
    private data class Approval(
        val commandId: String,
        val expiresAtMs: Long
    )

    private val approvals = ConcurrentHashMap<String, Approval>()

    fun request(commandId: String, ttlMs: Long = 60_000L): String {
        val token = UUID.randomUUID().toString()
        approvals[token] = Approval(
            commandId,
            System.currentTimeMillis() + ttlMs
        )
        return token
    }

    fun approve(token: String, commandId: String): Boolean {
        val approval = approvals.remove(token) ?: return false
        return approval.commandId == commandId &&
            System.currentTimeMillis() <= approval.expiresAtMs
    }

    fun revoke(token: String) {
        approvals.remove(token)
    }
}
