package com.kaifrza.jarvis.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

/** Tiny, allocation-light UI helpers. No WebView, no images, no heavy animations: tuned for a 2 GB phone. */
object Ui {
    val BG = 0xFF0B0F14.toInt()
    val SURFACE = 0xFF141A21.toInt()
    val SURFACE2 = 0xFF1C242D.toInt()
    val TEXT = 0xFFF2F6FA.toInt()
    val MUTED = 0xFF8D99A6.toInt()
    val ACCENT = 0xFF63D8FF.toInt()
    val ACCENT_DIM = 0xFF3A9DBF.toInt()
    val ACCENT_TEXT = 0xFF061116.toInt()
    val OK = 0xFF55D6A1.toInt()
    val WARN = 0xFFFFC857.toInt()
    val DANGER = 0xFFFF6B6B.toInt()

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusPx: Int, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx.toFloat()
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun label(context: Context, text: String, sizeSp: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(context).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    /** A flat pill button built from a TextView (cheaper than Button + drawables). */
    fun pill(context: Context, text: String, filled: Boolean, onClick: () -> Unit): TextView =
        TextView(context).apply {
            this.text = text
            textSize = 13f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (filled) ACCENT_TEXT else ACCENT)
            background = rounded(if (filled) ACCENT else SURFACE2, dp(context, 14))
            setPadding(dp(context, 14), dp(context, 9), dp(context, 14), dp(context, 9))
            isClickable = true
            setOnClickListener { onClick() }
        }
}
