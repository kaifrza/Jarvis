package com.kaifrza.jarvis.core.assistant

import android.content.Context
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import org.json.JSONArray
import org.json.JSONObject

class ActionHistory(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_history", Context.MODE_PRIVATE)
    private val key = "entries"
    private val maxEntries = 50

    data class Entry(
        val command: String,
        val state: CommandState,
        val timestamp: Long
    )

    fun record(command: JarvisCommand, response: CommandResponse) {
        val current = JSONArray(prefs.getString(key, "[]"))
        val output = JSONArray()

        output.put(
            JSONObject()
                .put("command", safeLabel(command))
                .put("state", response.state.name)
                .put("timestamp", System.currentTimeMillis())
        )

        for (i in 0 until minOf(current.length(), maxEntries - 1)) {
            output.put(current.getJSONObject(i))
        }

        prefs.edit().putString(key, output.toString()).apply()
    }

    private fun safeLabel(command: JarvisCommand): String = HistoryLabel.of(command)

    fun read(): List<Entry> {
        val current = JSONArray(prefs.getString(key, "[]"))
        return buildList {
            for (i in 0 until current.length()) {
                val o = current.getJSONObject(i)
                add(
                    Entry(
                        command = o.optString("command"),
                        state = runCatching {
                            CommandState.valueOf(o.optString("state"))
                        }.getOrDefault(CommandState.FAILED),
                        timestamp = o.optLong("timestamp")
                    )
                )
            }
        }
    }
}

/**
 * Privacy-safe history label. It is built from the intent and non-sensitive parameters only; the raw
 * user text is never stored because every step of a plan carries the full original sentence
 * (including dictated message bodies and typed text).
 */
object HistoryLabel {
    fun of(command: JarvisCommand): String {
        val p = command.parameters
        return when (command.intent) {
            IntentType.SEND_MESSAGE -> "Send message to " + (p["resolved_display_name"] ?: p["contact_name"] ?: p["phone_number"] ?: "contact")
            IntentType.MAKE_CALL -> "Call " + (p["resolved_display_name"] ?: p["contact_name"] ?: p["phone_number"] ?: "contact")
            IntentType.OPEN_APP -> "Open " + (p["app_name"] ?: "app")
            IntentType.UI_TYPE_TEXT -> "Type text (" + (p["text"]?.length ?: 0) + " chars)"
            IntentType.UI_CLICK_TEXT ->
                if (p["text"].equals("send", true)) "Send message" else "Click \u201C" + (p["text"].orEmpty().take(24)) + "\u201D"
            IntentType.UI_SEARCH -> "Search"
            IntentType.CALCULATE -> "Calculate"
            IntentType.UNKNOWN -> "Unrecognized command"
            else -> command.intent.name.lowercase().replace('_', ' ')
        }
    }
}
