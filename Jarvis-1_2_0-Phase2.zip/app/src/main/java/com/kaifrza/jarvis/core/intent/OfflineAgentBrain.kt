package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import java.util.UUID

/**
 * Deterministic offline agent planner. It is deliberately independent from Android APIs.
 * It handles common multi-step assistant language without an API key and emits the same
 * structured commands consumed by the normal executor.
 */
class OfflineAgentBrain(private val parser: IntentParser = IntentParser()) {
    fun plan(raw: String, context: String = ""): BrainPlan {
        val text = raw.trim()
        val n = text.lowercase().replace(Regex("\\s+"), " ")
        val steps = mutableListOf<BrainStep>()

        // High-value communication workflow: WhatsApp + contact + dictated message.
        if (looksLikeWhatsAppMessage(n)) {
            val app = command(IntentType.OPEN_APP, text, mapOf("app_name" to "WhatsApp"))
            steps += BrainStep(app, "Open WhatsApp")
            val messageText = text.replace(Regex("(?i)\\bwhatsapp\\b\\s*(?:khol[o|do]*|open(?:\\s+kara)?|launch(?:\\s+kara)?)?"), " ").replace(Regex("\\s+"), " ").trim()
            val parsedMessage = parser.parse(messageText)
            val contact = Regex("(?i)(?:whatsapp\\s+[^,]+,\\s*)?([a-z][a-z0-9 .'-]{1,40}?)\\s+ko\\s+(?:message|msg|sms|text)?\\s*(?:bolo|batao|keh do|bhejo)").find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }
                ?: parsedMessage.parameters["contact_name"]
                ?: extractContactAfterSearch(n)
                ?: extractContactBeforeMessage(n)
            val body = parsedMessage.parameters["message"] ?: extractMessageBody(text)
            if (!contact.isNullOrBlank()) {
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to "Search")), "Open WhatsApp search")
                steps += BrainStep(command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to contact)), "Type contact search")
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to contact)), "Open matching chat")
            }
            if (!body.isNullOrBlank() && !contact.isNullOrBlank()) {
                steps += BrainStep(command(IntentType.UI_FOCUS_INPUT, text), "Focus message composer")
                steps += BrainStep(command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to body)), "Prepare message")
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to "Send", "message_preview" to body, "contact_name" to contact)), "Send prepared message")
            }
            return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-agent")
        }

        // Multi-task aware planner. "Saath hi" creates a second lane; "aur/phir/then" remain sequential.
        // Message bodies are protected from splitting, and a plan is only used when EVERY clause is
        // understood, so a half-understood command can never run partially.
        val taskSegments = splitTasks(text)
        if (taskSegments.size > 1 || splitClauses(text).size > 1) {
            val segments = if (taskSegments.size > 1) taskSegments else listOf(text)
            var allUnderstood = true
            segments.forEachIndexed { taskIndex, segment ->
                splitClauses(segment).forEach { clause ->
                    val c = parser.parse(clause)
                    val command = if (c.intent != IntentType.UNKNOWN) c else parseUiClause(clause)
                    if (command != null) steps += BrainStep(command, "Offline parsed step", "task-${taskIndex + 1}", "Task ${taskIndex + 1}")
                    else allUnderstood = false
                }
            }
            if (allUnderstood && steps.isNotEmpty()) return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-multi-task")
            steps.clear()
        }

        // "A aur B" where one side is not understood must not silently run only the understood half.
        // (Calls/messages are exempt: "aur" can be part of a name or of the dictated text.)
        val rawPieces = protectedSplit(text, clauseSeparators)
        if (rawPieces.size > 1 && !rawPieces.all(::isUnderstood)) {
            val whole = parser.parse(text).intent
            if (whole != IntentType.SEND_MESSAGE && whole != IntentType.MAKE_CALL && whole != IntentType.UNKNOWN) {
                return BrainPlan(id = UUID.randomUUID().toString(), source = "offline")
            }
        }

        val parsed = parser.parse(text)
        if (parsed.intent != IntentType.UNKNOWN) return BrainPlan(id = UUID.randomUUID().toString(), steps = listOf(BrainStep(parsed)), source = "offline-local")
        parseUiClause(text)?.let { return BrainPlan(id = UUID.randomUUID().toString(), steps = listOf(BrainStep(it)), source = "offline-ui") }
        return BrainPlan(id = UUID.randomUUID().toString(), source = "offline")
    }

    private val searchTail = Regex("(?i)^(.+?)\\s+search(?:\\s+(?:karo|kro|kar\\s+do|kar|kijiye))?$")
    private val searchHead = Regex("(?i)^search\\s+(?:for\\s+)?(.+?)(?:\\s+(?:karo|kro|kar\\s+do|please))?$")
    private val searchPrefix = Regex("(?i)^(google|chrome|youtube|browser)\\s+(?:par|pe|per|mein|me)\\s+")
    private val clickHead = Regex("(?i)^(?:click|tap|press|select|dabao)\\s+(?:on\\s+)?(.+)$")
    private val clickTail = Regex("(?i)^(.+?)\\s+(?:pe|par|per|ko)\\s+(?:click|tap|dabao|press)(?:\\s+(?:karo|kro|kar\\s+do))?$")
    private val dabaoTail = Regex("(?i)^(.+?)\\s+dabao$")
    private val typeHead = Regex("(?i)^(?:type|enter|likho|likh)\\s+(.+)$")

    /**
     * UI-tap clauses. Every pattern is anchored to the start or end of the clause so ordinary
     * sentences ("what is the best type of laptop") are never hijacked into a UI action.
     */
    private fun parseUiClause(text: String): JarvisCommand? {
        val t = text.trim()
        searchTail.find(t)?.groupValues?.getOrNull(1)?.trim()?.let { head ->
            val q = head.replace(searchPrefix, "").trim()
            if (q.isNotBlank()) return command(IntentType.UI_SEARCH, text, mapOf("query" to q))
        }
        searchHead.find(t)?.groupValues?.getOrNull(1)?.trim()?.let { q ->
            if (q.isNotBlank()) return command(IntentType.UI_SEARCH, text, mapOf("query" to q))
        }
        val click = clickHead.find(t) ?: clickTail.find(t) ?: dabaoTail.find(t)
        if (click != null) return command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to click.groupValues[1].trim()))
        val type = typeHead.find(t)
        if (type != null) return command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to type.groupValues[1].trim()))
        val n = t.lowercase()
        if (Regex("\\bscroll\\b").containsMatchIn(n)) {
            val up = Regex("\\b(up|upar|oopar)\\b").containsMatchIn(n)
            return command(IntentType.UI_SCROLL, text, mapOf("direction" to if (up) "up" else "down"))
        }
        return null
    }

    private fun looksLikeWhatsAppMessage(n: String): Boolean =
        n.contains("whatsapp") && (n.contains("message") || n.contains("bolo") || n.contains("keh do") || n.contains("batao") || n.contains("likho"))

    private fun extractContactAfterSearch(n: String): String? =
        Regex("(?:chat|contact)\\s+(?:me|mein)\\s+([a-z][a-z0-9 .'-]{1,40}?)\\s+(?:search|dhoond|dhundo|find)", RegexOption.IGNORE_CASE)
            .find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }

    private fun extractContactBeforeMessage(n: String): String? =
        Regex("(?:^|\\s)([a-z][a-z0-9 .'-]{1,40}?)\\s+(?:ko|ke liye)\\s+(?:message|msg|text)?\\s*(?:bolo|batao|keh do|bhejo)", RegexOption.IGNORE_CASE)
            .find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }
            ?: Regex("(?:to|ko|usko|usse)\\s+([a-z][a-z0-9 .'-]{1,40}?)(?:\\s+(?:bolo|batao|message|msg|text|keh do)\\b)", RegexOption.IGNORE_CASE)
                .find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }

    private fun extractMessageBody(text: String): String? {
        Regex("(?i)(?:bolo|batao|keh do|message|msg|text)\\s*[:,-]?\\s*['\"]?(.+?)['\"]?$").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            val cleaned = it.replace(Regex("(?i)^(?:bolo\\s+)+"), "").trim()
            if (cleaned.isNotBlank()) return cleaned
        }
        Regex("(?i)us(?:ko|se)\\s+(.+)$").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            val cleaned = it.replace(Regex("(?i)^(?:bolo\\s+)+"), "").trim()
            if (cleaned.isNotBlank()) return cleaned
        }
        return null
    }

    private val bodyPatterns = listOf(
        Regex("(?i)\\b(?:message|msg|sms|text)\\b[^:]*:\\s*(.+)$"),
        Regex("(?i)\\bsaying\\s+(.+)$"),
        Regex("(?i)\\b(?:bolo|batao|keh\\s?do)\\s*[:,-]?\\s*(.+)$"),
        Regex("(?i)\\bbhejo\\s*:?\\s*(.+)$")
    )
    private val clauseSeparators = Regex("\\b(aur|and|phir|then|uske baad|after that)\\b", RegexOption.IGNORE_CASE)
    private val taskSeparators = Regex("\\b(?:saath hi|saath-saath|at the same time|also|meanwhile|parallel mein|parallelly)\\b", RegexOption.IGNORE_CASE)

    /** Splits only the command part; a dictated message body is kept intact. */
    private fun protectedSplit(text: String, separators: Regex): List<String> {
        val body = bodyPatterns.firstNotNullOfOrNull { it.find(text)?.groups?.get(1) }
        val head = if (body != null) text.substring(0, body.range.first) else text
        val tail = if (body != null) text.substring(body.range.first) else ""
        val pieces = separators.replace(head, "|").split('|').map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
        if (tail.isNotEmpty()) {
            if (pieces.isEmpty()) pieces += tail else pieces[pieces.lastIndex] = pieces.last() + " " + tail
        }
        return pieces
    }

    private fun isUnderstood(clause: String): Boolean =
        parser.parse(clause).intent != IntentType.UNKNOWN || parseUiClause(clause) != null

    /** "A aur B" is split only when both sides are real commands ("Rahul and Priya ko call karo" stays whole). */
    private fun splitClauses(text: String): List<String> {
        val pieces = protectedSplit(text, clauseSeparators)
        return if (pieces.size > 1 && pieces.all(::isUnderstood)) pieces else listOf(text.trim())
    }

    private fun splitTasks(text: String): List<String> = protectedSplit(text, taskSeparators)

    private fun command(intent: IntentType, raw: String, params: Map<String, String> = emptyMap()) =
        JarvisCommand(UUID.randomUUID().toString(), raw, intent, params)
}
