package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.assistant.CommandProcessor
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.conversation.ConversationManager
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.JarvisCommand

/**
 * Coordinates a plan made of independent task lanes.
 *
 * Foreground Android UI is inherently single-window, so lanes run ONE AFTER ANOTHER and each
 * lane runs to completion before the next starts. (Interleaving steps round-robin made lane A's
 * step 2 run on top of lane B's app.) A failed lane skips only its own remaining steps; other
 * lanes still run. The whole plan pauses when a user decision/approval is required.
 */
class BrainTaskRunner(
    private val brain: BrainEngine,
    private val processor: CommandProcessor,
    private val conversation: ConversationManager
) {
    private data class ActivePlan(
        val id: String,
        val reply: String?,
        val startedAtMs: Long,
        val originalText: String,
        /** True when the plan came from a remote model: HIGH-risk steps then need approval. */
        val untrusted: Boolean
    )

    private data class Lane(
        val id: String,
        val label: String,
        val steps: ArrayDeque<BrainStep>,
        var blocked: Boolean = false,
        var done: Boolean = false
    )

    data class StepView(
        val taskId: String,
        val taskLabel: String,
        val index: Int,
        val total: Int,
        val title: String,
        val state: String
    )

    fun interface ProgressListener { fun onProgress(steps: List<StepView>) }

    private val listeners = java.util.concurrent.CopyOnWriteArrayList<ProgressListener>()
    @Volatile private var abortRequested = false
    private var activePlan: ActivePlan? = null
    private val lanes = linkedMapOf<String, Lane>()
    private val states = linkedMapOf<String, String>()
    private val stepLookup = linkedMapOf<String, BrainStep>()
    private var waitingStepId: String? = null
    private var waitingTaskId: String? = null

    /** Several surfaces (app, overlay, voice session) can watch progress at once; each removes only itself. */
    fun addProgressListener(listener: ProgressListener) {
        listeners.addIfAbsent(listener)
        emitProgress()
    }

    fun removeProgressListener(listener: ProgressListener) {
        listeners.remove(listener)
    }

    /**
     * Cooperative STOP. Deliberately NOT synchronized: handle() holds the lock while it runs, so a
     * synchronized stop could never get in. The lane loop checks this flag between steps.
     */
    fun requestAbort() {
        abortRequested = true
    }

    @Synchronized
    fun handle(rawText: String, context: String = ""): CommandResponse {
        val text = rawText.trim()
        if (text.isEmpty()) return CommandResponse(CommandState.FAILED, "Command khaali hai, sir.")

        // Cancellation is an orchestration command, not an app action. It must work even
        // when no approval/choice dialog is pending.
        if (text.lowercase().trim() in setOf("cancel", "cancel karo", "cancel kar do", "stop", "stop karo", "rehne do", "chhodo")) {
            if (activePlan != null || processor.hasPendingApproval() || processor.hasPendingChoice()) {
                return cancel()
            }
        }

        // Approval/choice responses belong to the active plan; do not interpret them as a new task.
        if (processor.hasPendingApproval() || processor.hasPendingChoice()) {
            return continuePending(processor.handle(text))
        }

        abortRequested = false
        val mergedContext = buildString {
            if (context.isNotBlank()) append(context)
            val history = conversation.context()
            if (history.isNotBlank()) {
                if (isNotEmpty()) append('\n')
                append("Recent conversation:\n").append(history)
            }
        }

        val plan = brain.plan(text, mergedContext)
        if (plan.steps.isEmpty()) {
            val reply = plan.reply
            val answer = if (!reply.isNullOrBlank()) CommandResponse(CommandState.SUCCESS, reply)
            else CommandResponse(CommandState.FAILED, "Sir, mujhe abhi is command ko confidently map karna nahi aaya.")
            conversation.add(text, answer.message)
            return answer
        }

        resetPlan(plan.steps)
        activePlan = ActivePlan(plan.id, plan.reply, System.currentTimeMillis(), text, plan.source.startsWith("remote"))
        val response = runLanes()
        return finalizeIfComplete(response)
    }

    @Synchronized
    fun approve(): CommandResponse = continuePending(processor.approve())

    @Synchronized
    fun cancel(): CommandResponse {
        val response = processor.cancel()
        clearPlan()
        return response
    }

    private fun resetPlan(steps: List<BrainStep>) {
        lanes.clear()
        states.clear()
        stepLookup.clear()
        waitingStepId = null
        waitingTaskId = null

        steps.groupBy { it.taskId }.forEach { (taskId, taskSteps) ->
            val label = taskSteps.firstOrNull()?.taskLabel ?: taskId
            val queue = ArrayDeque<BrainStep>()
            taskSteps.forEach { step ->
                queue.add(step)
                stepLookup[step.command.id] = step
                states[step.command.id] = "QUEUED"
            }
            lanes[taskId] = Lane(taskId, label, queue)
        }
        emitProgress()
    }

    /** Runs lanes sequentially; each lane finishes (or fails/blocks) before the next one starts. */
    private fun runLanes(): CommandResponse {
        var lastResponse = CommandResponse(CommandState.SUCCESS, "Done, sir.")
        var failureResponse: CommandResponse? = null
        val untrusted = activePlan?.untrusted ?: false

        for ((taskId, lane) in lanes) {
            while (!lane.done && !lane.blocked && lane.steps.isNotEmpty()) {
                if (abortRequested) {
                    lanes.values.forEach { l ->
                        l.steps.forEach { states[it.command.id] = "SKIPPED" }
                        l.steps.clear()
                        l.done = true
                    }
                    emitProgress()
                    return CommandResponse(CommandState.CANCELLED, "Roka gaya, sir.")
                }
                val step = lane.steps.removeFirst()
                states[step.command.id] = "RUNNING"
                emitProgress()

                val response = processor.handleCommand(step.command, untrusted)
                lastResponse = response
                when (response.state) {
                    CommandState.WAITING_FOR_APPROVAL,
                    CommandState.WAITING_FOR_CHOICE -> {
                        states[step.command.id] = "WAITING"
                        lane.blocked = true
                        waitingStepId = step.command.id
                        waitingTaskId = taskId
                        emitProgress()
                        // A foreground-sensitive pending action must stop every other lane too.
                        return response
                    }
                    CommandState.FAILED -> {
                        states[step.command.id] = "FAILED"
                        failureResponse = failureResponse ?: CommandResponse(
                            CommandState.FAILED,
                            "\u201C${com.kaifrza.jarvis.core.assistant.HistoryLabel.of(step.command)}\u201D fail hua: ${response.message}"
                        )
                        // Only this lane is abandoned; its remaining steps are shown as skipped.
                        lane.steps.forEach { states[it.command.id] = "SKIPPED" }
                        lane.steps.clear()
                        lane.blocked = true
                        lane.done = true
                        emitProgress()
                    }
                    CommandState.CANCELLED -> {
                        states[step.command.id] = "CANCELLED"
                        lane.steps.forEach { states[it.command.id] = "SKIPPED" }
                        lane.steps.clear()
                        lane.done = true
                        emitProgress()
                    }
                    else -> {
                        states[step.command.id] = "DONE"
                        if (lane.steps.isEmpty()) lane.done = true
                        emitProgress()
                    }
                }
            }
            if (lane.steps.isEmpty() && !lane.blocked) lane.done = true
        }

        return if (lanes.values.all { it.done }) {
            failureResponse ?: CommandResponse(CommandState.SUCCESS, activePlan?.reply ?: lastResponse.message)
        } else {
            failureResponse ?: lastResponse
        }
    }

    private fun continuePending(response: CommandResponse): CommandResponse {
        val stepId = waitingStepId
        val taskId = waitingTaskId
        if (response.state == CommandState.WAITING_FOR_APPROVAL || response.state == CommandState.WAITING_FOR_CHOICE) {
            return response
        }

        if (stepId != null) {
            states[stepId] = when (response.state) {
                CommandState.SUCCESS -> "DONE"
                CommandState.CANCELLED -> "CANCELLED"
                else -> "FAILED"
            }
        }
        if (taskId != null) lanes[taskId]?.blocked = false
        waitingStepId = null
        waitingTaskId = null
        emitProgress()

        if (response.state == CommandState.CANCELLED || response.state == CommandState.FAILED) {
            return response
        }

        val next = runLanes()
        return finalizeIfComplete(next)
    }

    private fun finalizeIfComplete(response: CommandResponse): CommandResponse {
        val complete = activePlan != null && lanes.isNotEmpty() && lanes.values.all { it.done }
        if (!complete) return response
        val final = if (!activePlan?.reply.isNullOrBlank() && response.state == CommandState.SUCCESS) {
            response.copy(message = activePlan?.reply.orEmpty())
        } else response
        val original = activePlan?.originalText
        if (final.state == CommandState.SUCCESS || final.state == CommandState.FAILED || final.state == CommandState.CANCELLED) {
            if (!original.isNullOrBlank()) conversation.add(original, final.message)
            clearPlan()
        }
        return final
    }

    private fun clearPlan() {
        activePlan = null
        lanes.clear()
        states.clear()
        stepLookup.clear()
        waitingStepId = null
        waitingTaskId = null
        emitProgress()
    }

    private fun emitProgress() {
        if (listeners.isEmpty()) return
        val all = stepLookup.values.toList()
        val totals = all.groupingBy { it.taskId }.eachCount()
        val indexes = mutableMapOf<String, Int>()
        val views = all.map { step ->
            val index = (indexes[step.taskId] ?: 0) + 1
            indexes[step.taskId] = index
            StepView(
                taskId = step.taskId,
                taskLabel = step.taskLabel,
                index = index,
                total = totals[step.taskId] ?: 1,
                // Privacy-safe label: never show the whole sentence (it may contain a message body).
                title = com.kaifrza.jarvis.core.assistant.HistoryLabel.of(step.command),
                state = states[step.command.id] ?: "QUEUED"
            )
        }
        listeners.forEach { it.onProgress(views) }
    }
}
