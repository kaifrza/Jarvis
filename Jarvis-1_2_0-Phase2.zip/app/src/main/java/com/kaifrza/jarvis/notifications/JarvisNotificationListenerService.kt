package com.kaifrza.jarvis.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

class JarvisNotificationListenerService : NotificationListenerService() {
    data class Item(val app: String, val title: String, val text: String, val timestamp: Long)

    companion object {
        @Volatile var instance: JarvisNotificationListenerService? = null
            private set
        private val recent = CopyOnWriteArrayList<Item>()
    }

    override fun onListenerConnected() { instance = this }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val extras = sbn.notification.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        recent.removeAll { it.app == sbn.packageName && it.title == title && it.text == text }
        recent.add(0, Item(sbn.packageName.substringAfterLast('.'), title, text, sbn.postTime))
        while (recent.size > 50) recent.removeAt(recent.lastIndex)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = Unit
    fun recentNotifications(): List<Item> = recent.toList()
}
