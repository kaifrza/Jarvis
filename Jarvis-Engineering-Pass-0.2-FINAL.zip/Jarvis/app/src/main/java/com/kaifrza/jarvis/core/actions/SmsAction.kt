package com.kaifrza.jarvis.core.actions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.core.model.ActionPlan

class SmsAction(
    private val context: Context,
    private val resolver: ContactResolver
) : JarvisAction {

    override val id = "communication.sms"

    override fun validate(plan: ActionPlan): ActionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("Contacts permission is required to find the person.")
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("SMS permission is required to send the message.")
        }

        val name = plan.command.parameters["contact_name"]
            ?: return ActionResult.Failure("Tell me who should receive the message.")
        val body = plan.command.parameters["message"]
            ?: return ActionResult.Failure("Tell me what message I should prepare.")

        if (body.isBlank()) return ActionResult.Failure("The message is empty.")

        val matches = resolver.find(name)
        return when {
            matches.isEmpty() -> ActionResult.Failure("I couldn't find $name in your contacts.")
            matches.size > 1 -> ActionResult.Failure(
                "I found multiple contacts matching $name. I need you to choose one."
            )
            else -> ActionResult.Success
        }
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["contact_name"] ?: return ActionResult.Failure("Missing contact.")
        val body = plan.command.parameters["message"] ?: return ActionResult.Failure("Missing message.")
        val match = resolver.find(name).singleOrNull()
            ?: return ActionResult.Failure("The contact became ambiguous or unavailable.")

        return try {
            val sms = SmsManager.getDefault()
            val parts = sms.divideMessage(body)
            sms.sendMultipartTextMessage(
                match.phoneNumber,
                null,
                parts,
                null,
                null
            )
            ActionResult.Success
        } catch (e: SecurityException) {
            ActionResult.Failure("Android denied the SMS permission.")
        } catch (e: UnsupportedOperationException) {
            ActionResult.Failure("This device does not support SMS messaging.")
        } catch (e: Exception) {
            ActionResult.Failure("The SMS could not be sent.")
        }
    }

    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success
}
