package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import java.util.Locale
import java.util.UUID

class IntentParser {

    fun parse(raw: String): JarvisCommand {
        val text = raw.trim()
        val n = text.lowercase(Locale.ROOT)

        val intent = when {
            n == "back" || n == "go back" || n.contains("back jao") ->
                IntentType.NAVIGATE_BACK
            n == "home" || n.contains("home jao") ->
                IntentType.HOME
            n.contains("recent apps") || n.contains("recents") ->
                IntentType.RECENTS
            n.contains("notifications kholo") || n.contains("notification kholo") ->
                IntentType.OPEN_NOTIFICATIONS
            n.contains("call") || n.contains("phone karo") || n.contains("phone lagao") ->
                IntentType.MAKE_CALL
            n.contains("message") || n.contains("msg") || n.contains("sms") ->
                IntentType.SEND_MESSAGE
            n.contains("youtube") || n.contains("calculator") || n.contains("chrome") ||
                n.contains("whatsapp") || n.contains("instagram") ->
                IntentType.OPEN_APP
            else -> IntentType.UNKNOWN
        }

        val params = when (intent) {
            IntentType.OPEN_APP -> {
                val app = extractAppName(n)
                if (app != null) mapOf("app_name" to app) else emptyMap()
            }
            IntentType.MAKE_CALL -> {
                val target = extractPersonAfterCommand(n, listOf("call", "phone karo", "phone lagao"))
                if (target != null) mapOf("contact_name" to target) else emptyMap()
            }
            IntentType.SEND_MESSAGE -> {
                val target = extractMessageTarget(n)
                val body = extractMessageBody(text)
                buildMap {
                    if (target != null) put("contact_name", target)
                    if (body != null) put("message", body)
                }
            }
            else -> emptyMap()
        }

        return JarvisCommand(
            id = UUID.randomUUID().toString(),
            rawText = text,
            intent = intent,
            parameters = params
        )
    }

    private fun extractAppName(n: String): String? {
        val known = listOf("youtube", "calculator", "chrome", "whatsapp", "instagram")
        return known.firstOrNull { n.contains(it) }
    }

    private fun extractPersonAfterCommand(n: String, commands: List<String>): String? {
        var value = n
        commands.forEach { value = value.replace(it, " ") }
        value = value.replace("ko", " ").replace("karo", " ").replace("lagao", " ")
        return value.trim().split(Regex("\\s+")).filter { it.length > 1 }.joinToString(" ")
            .ifBlank { null }
    }

    private fun extractMessageTarget(n: String): String? {
        val before = n.substringBefore("message").substringBefore("msg").trim()
        val cleaned = before
            .replace("ko", " ")
            .replace("bhejo", " ")
            .replace("send", " ")
            .replace("karo", " ")
        return cleaned.trim().split(Regex("\\s+")).filter { it.length > 1 }
            .joinToString(" ").ifBlank { null }
    }

    private fun extractMessageBody(text: String): String? {
        val lower = text.lowercase(Locale.ROOT)
        val explicitMarkers = listOf("message:", "msg:", "message ", "msg ")
        val colonBhejo = Regex("""(?i)\bbhejo\s*:\s*""").find(text)
        if (colonBhejo != null) {
            return text.substring(colonBhejo.range.last + 1).trim().ifBlank { null }
        }
        val marker = explicitMarkers.firstOrNull { lower.contains(it) }
        if (marker != null) {
            val index = lower.indexOf(marker)
            var body = text.substring(index + marker.length).trim()
            if (body.lowercase(Locale.ROOT).startsWith("bhejo:")) {
                body = body.substringAfter(':').trim()
            }
            return body.ifBlank { null }
        }
        val bhejo = lower.indexOf("bhejo")
        if (bhejo >= 0) {
            var body = text.substring(bhejo + "bhejo".length).trim()
            if (body.startsWith(":")) body = body.substring(1).trim()
            return body.ifBlank { null }
        }
        return null
    }
}
