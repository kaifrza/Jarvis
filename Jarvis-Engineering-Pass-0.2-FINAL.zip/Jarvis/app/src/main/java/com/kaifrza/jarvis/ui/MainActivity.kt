package com.kaifrza.jarvis.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.R
import com.kaifrza.jarvis.core.assistant.CommandProcessor
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.intent.LocalCommandUnderstandingEngine
import com.kaifrza.jarvis.voice.JarvisSpeaker
import com.kaifrza.jarvis.voice.JarvisVoiceController

class MainActivity : AppCompatActivity() {

    private val container get() = (application as JarvisApplication).container

    private lateinit var processor: CommandProcessor
    private lateinit var speaker: JarvisSpeaker
    private lateinit var voice: JarvisVoiceController

    private lateinit var response: TextView
    private lateinit var input: EditText
    private lateinit var approve: Button
    private lateinit var cancel: Button
    private lateinit var mic: Button

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        processor = CommandProcessor(
            parser = LocalCommandUnderstandingEngine(),
            riskEngine = container.riskEngine,
            executor = container.actionExecutor,
            history = container.actionHistory
        )

        speaker = JarvisSpeaker(this)

        response = findViewById(R.id.responseText)
        input = findViewById(R.id.commandInput)
        approve = findViewById(R.id.approveButton)
        cancel = findViewById(R.id.cancelButton)
        mic = findViewById(R.id.micButton)

        voice = JarvisVoiceController(this, object : JarvisVoiceController.Listener {
            override fun onReady() {
                response.text = "Listening, sir…"
            }

            override fun onListening() {
                response.text = "I'm listening…"
            }

            override fun onPartial(text: String) {
                if (text.isNotBlank()) input.setText(text)
            }

            override fun onResult(text: String) {
                input.setText(text)
                process(text)
            }

            override fun onError(message: String) {
                response.text = message
            }
        })

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            process(input.text.toString())
        }

        mic.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED) {
                voice.start()
            } else {
                permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            }
        }

        approve.setOnClickListener { show(processor.approve()) }
        cancel.setOnClickListener { show(processor.cancel()) }

        findViewById<Button>(R.id.permissionsButton).setOnClickListener {
            val missing = PermissionCenter.missingPermissions(this)
            if (missing.isNotEmpty()) permissionLauncher.launch(missing)
        }
        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            PermissionCenter.openAccessibilitySettings(this)
        }
        findViewById<Button>(R.id.notificationButton).setOnClickListener {
            PermissionCenter.openNotificationAccessSettings(this)
        }
    }

    private fun process(raw: String) {
        if (raw.trim().isEmpty()) return
        show(processor.handle(raw))
    }

    private fun show(result: CommandResponse) {
        response.text = result.message

        val awaiting = result.state ==
            com.kaifrza.jarvis.core.model.CommandState.WAITING_FOR_APPROVAL

        approve.visibility = if (awaiting) View.VISIBLE else View.GONE
        cancel.visibility = if (awaiting) View.VISIBLE else View.GONE

        if (result.state ==
            com.kaifrza.jarvis.core.model.CommandState.SUCCESS) {
            speaker.speak(result.message)
        }
    }

    override fun onDestroy() {
        voice.destroy()
        speaker.shutdown()
        super.onDestroy()
    }
}
