package com.kaifrza.jarvis.core.security

import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.model.RiskLevel

class RiskEngine {

    fun plan(command: JarvisCommand): ActionPlan {
        val risk = when (command.intent) {
            IntentType.SEND_MESSAGE,
            IntentType.DELETE_FILE -> RiskLevel.HIGH

            IntentType.MAKE_CALL,
            IntentType.CREATE_ALARM,
            IntentType.CREATE_REMINDER,
            IntentType.ACCESS_SCREEN -> RiskLevel.MEDIUM

            IntentType.UNKNOWN -> RiskLevel.MEDIUM

            else -> RiskLevel.LOW
        }

        return ActionPlan(
            command = command,
            risk = risk,
            requiresConfirmation = risk >= RiskLevel.HIGH
        )
    }
}
