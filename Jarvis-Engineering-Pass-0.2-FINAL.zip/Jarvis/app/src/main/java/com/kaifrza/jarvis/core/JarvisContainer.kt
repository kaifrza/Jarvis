package com.kaifrza.jarvis.core

import android.content.Context
import com.kaifrza.jarvis.core.actions.ActionExecutor
import com.kaifrza.jarvis.core.actions.ActionRegistry
import com.kaifrza.jarvis.core.assistant.ActionHistory
import com.kaifrza.jarvis.core.security.ApprovalManager
import com.kaifrza.jarvis.core.security.RiskEngine

class JarvisContainer(context: Context) {
    private val appContext = context.applicationContext

    val riskEngine = RiskEngine()
    val approvalManager = ApprovalManager()
    val actionRegistry = ActionRegistry(appContext)
    val actionHistory = ActionHistory(appContext)

    val actionExecutor = ActionExecutor(
        riskEngine = riskEngine,
        approvalManager = approvalManager,
        registry = actionRegistry
    )
}
