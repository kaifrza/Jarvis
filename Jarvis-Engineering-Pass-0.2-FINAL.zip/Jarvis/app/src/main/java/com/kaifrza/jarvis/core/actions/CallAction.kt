package com.kaifrza.jarvis.core.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.core.model.ActionPlan

class CallAction(
    private val context: Context,
    private val resolver: ContactResolver
) : JarvisAction {

    override val id = "communication.call"

    override fun validate(plan: ActionPlan): ActionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("Contacts permission is required to find the person.")
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("Phone permission is required to place the call.")
        }
        val name = plan.command.parameters["contact_name"]
            ?: return ActionResult.Failure("Tell me who to call.")
        val matches = resolver.find(name)
        return when {
            matches.isEmpty() -> ActionResult.Failure("I couldn't find $name in your contacts.")
            matches.size > 1 -> ActionResult.Failure(
                "I found multiple contacts matching $name. I need you to choose one."
            )
            else -> ActionResult.Success
        }
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["contact_name"] ?: return ActionResult.Failure("Missing contact.")
        val match = resolver.find(name).singleOrNull()
            ?: return ActionResult.Failure("The contact became ambiguous or unavailable.")

        return try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.fromParts("tel", match.phoneNumber, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult.Success
        } catch (e: SecurityException) {
            ActionResult.Failure("Android denied the call permission.")
        } catch (e: Exception) {
            ActionResult.Failure("The call could not be started.")
        }
    }

    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success
}
