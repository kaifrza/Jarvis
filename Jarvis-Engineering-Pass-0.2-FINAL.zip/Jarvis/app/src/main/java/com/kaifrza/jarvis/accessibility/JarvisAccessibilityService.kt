package com.kaifrza.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set
    }

    @Volatile
    var foregroundPackage: String? = null
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        foregroundPackage = rootInActiveWindow?.packageName?.toString()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            foregroundPackage = event.packageName?.toString()
        }
    }

    override fun onInterrupt() = Unit

    fun performGlobalActionBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalActionHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalActionRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performGlobalActionNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun clickText(text: String): Boolean = clickBestMatchingNode(text)

    fun clickContentDescription(description: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = normalize(description)
        val node = findNodes(root) { normalize(it.contentDescription?.toString().orEmpty()) == target }
            .firstOrNull { it.isVisibleToUser }
            ?: return false
        return clickNodeOrClickableParent(node)
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodes(root) {
            it.isVisibleToUser && it.isEditable && it.isFocused
        }.firstOrNull() ?: findNodes(root) {
            it.isVisibleToUser && it.isEditable
        }.firstOrNull() ?: return false

        val arguments = android.os.Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findNodes(root) {
            it.isVisibleToUser && it.isScrollable
        }.firstOrNull()
        return scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            ?: root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun scrollBackward(): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findNodes(root) {
            it.isVisibleToUser && it.isScrollable
        }.firstOrNull()
        return scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            ?: root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun findVisibleText(text: String): List<AccessibilityNodeInfo> {
        val root = rootInActiveWindow ?: return emptyList()
        val target = normalize(text)
        return findNodes(root) {
            it.isVisibleToUser && normalize(it.text?.toString().orEmpty()).contains(target)
        }
    }

    fun waitForForegroundPackage(packageName: String, timeoutMs: Long = 2_500L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            if (foregroundPackage == packageName) return true
            SystemClock.sleep(100)
        }
        return foregroundPackage == packageName
    }

    private fun clickBestMatchingNode(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = normalize(text)
        val exact = findNodes(root) {
            it.isVisibleToUser && normalize(it.text?.toString().orEmpty()) == target
        }
        val contains = findNodes(root) {
            it.isVisibleToUser && normalize(it.text?.toString().orEmpty()).contains(target)
        }
        return (exact + contains).distinctBy { it.hashCode() }
            .firstOrNull()?.let(::clickNodeOrClickableParent) == true
    }

    private fun clickNodeOrClickableParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            parent = parent.parent
        }
        return false
    }

    private fun findNodes(
        root: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        fun visit(node: AccessibilityNodeInfo?) {
            if (node == null) return
            if (predicate(node)) result += node
            for (i in 0 until node.childCount) visit(node.getChild(i))
        }
        visit(root)
        return result
    }

    private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT)

    override fun onDestroy() {
        if (instance === this) instance = null
        foregroundPackage = null
        super.onDestroy()
    }
}
