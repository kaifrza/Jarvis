# Jarvis — Consolidated Milestone

## End-to-end flow

User -> Voice/Text -> IntentParser -> RiskEngine -> PreparedAction ->
Approval Gate -> ActionExecutor -> Android capability -> Verification -> Response/TTS

## Implemented now

### Input
- Text command
- Android SpeechRecognizer adapter
- Partial speech results
- Text-to-Speech response

### Intent layer
- Open app
- Back
- Home
- Recents
- Notifications
- Call contact
- SMS contact
- Unknown-command handling

### Android action layer
- Dynamic launcher app resolution
- Accessibility global actions
- Contact lookup via Contacts Provider
- Direct phone call via ACTION_CALL
- SMS via SmsManager
- Runtime permission gate

### Security
- High-risk SMS/call flow stays behind explicit approval
- Approval token is short-lived and memory-only
- Approval is tied to the original command ID
- Cancel revokes the pending token
- Process restart cannot silently execute a previous approval

### State/history
- Persistent local action history (last 50)
- No cloud requirement for this milestone

## Known platform boundaries

- SpeechRecognizer may use a remote recognition service and is not intended as an always-on continuous recognizer.
- Accessibility must be explicitly enabled by the user.
- Direct SMS requires SEND_SMS and telephony messaging support.
- Direct calls require CALL_PHONE.
- Contacts require READ_CONTACTS.
- Android version-specific behavior is isolated where practical.

## Next large feature group

- LLM adapter that emits JarvisCommand JSON
- Wake-word / voice-assistant role
- Rich accessibility UI-node planner
- WhatsApp/other messaging adapter with confirmation
- Alarms/reminders
- Media and volume controls
- Verification observers
- Memory and routines


## Engineering Hardening — 0.2

The 0.2 milestone adds several guardrails before the first phone build:

- Runtime permission requests use one Activity Result path, including notification permission on Android 13+.
- Notification listener settings use the platform `Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS` constant.
- Accessibility control is capability-based: global navigation, text/content-description clicks, editable-node text input, scrolling, and foreground-package observation.
- App launch verification can confirm that the resolved package became the foreground package when Accessibility is enabled.
- Command understanding is behind `CommandUnderstandingEngine`; future LLM adapters return only the existing `JarvisCommand` contract.
- Pending approvals remain in-memory and are tied to the exact prepared action.
- The app remains fail-closed when a required capability or permission is unavailable.

Android build compilation still needs the configured GitHub Actions environment; local verification in this workspace covers Kotlin core compilation, parser behavior, XML validity, stale-reference checks, and archive integrity.
