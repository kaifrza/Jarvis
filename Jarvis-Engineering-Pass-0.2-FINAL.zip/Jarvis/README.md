# Jarvis — Consolidated Milestone

Personal-use Android assistant foundation targeting Android 10+.

## Included

- Text command processing
- SpeechRecognizer voice input
- Text-to-Speech output
- Dynamic app launching
- Accessibility Back/Home/Recents/Notifications
- Contacts lookup
- Direct call flow
- SMS sending flow
- Explicit high-risk confirmation
- Runtime permission center
- Notification access settings
- Local action history
- Provider-independent action architecture
- GitHub Actions APK build

## Example commands

- `YouTube kholo`
- `Back`
- `Home`
- `Recent apps kholo`
- `Notifications kholo`
- `Call Zubair`
- `Zubair ko message bhejo: Main 10 minute mein aa raha hoon`

## Security rule

AI never receives direct Android API access.

`AI/Parser -> Structured Command -> Risk -> Approval -> Executor -> Verify`

## Build environment

- minSdk 29 (Android 10)
- targetSdk 37
- compileSdk 37
- Java 17
- Gradle 9.6
- Android Gradle Plugin 9.4.0

## Verification note

The source was reviewed for the command/data flow and Android API usage. This environment does not contain
an Android SDK/Gradle installation, so APK compilation cannot honestly be claimed as locally verified here.
The GitHub Actions workflow remains the authoritative build check.
