package com.kaifrza.jarvis.accessibility

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.R
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.ui.MainActivity
import com.kaifrza.jarvis.voice.JarvisSpeaker
import com.kaifrza.jarvis.voice.JarvisVoiceController
import java.util.Locale

/**
 * Cross-app Jarvis surface. The accessibility service is the capability boundary;
 * the command engine still only receives text and returns a structured response.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
            private set
    }

    @Volatile var foregroundPackage: String? = null
        private set

    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private lateinit var input: EditText
    private lateinit var response: TextView
    private lateinit var panel: LinearLayout
    private lateinit var approve: Button
    private lateinit var cancel: Button
    private lateinit var voice: JarvisVoiceController
    private lateinit var speaker: JarvisSpeaker

    private val processor get() = (application as JarvisApplication).container.commandProcessor

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        foregroundPackage = rootInActiveWindow?.packageName?.toString()
        speaker = JarvisSpeaker(this)
        voice = JarvisVoiceController(this, object : JarvisVoiceController.Listener {
            override fun onReady() { response.text = "Listening…" }
            override fun onListening() { response.text = "I'm listening…" }
            override fun onPartial(text: String) { if (text.isNotBlank()) input.setText(text) }
            override fun onResult(text: String) { input.setText(text); show(processor.handle(text)) }
            override fun onError(message: String) { response.text = message }
        })
        addOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            foregroundPackage = event.packageName?.toString()
        }
    }

    override fun onInterrupt() = Unit

    fun performGlobalActionBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalActionHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalActionRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performGlobalActionNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun clickText(text: String): Boolean = clickBestMatchingNode(text)

    fun clickContentDescription(description: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = normalize(description)
        val node = findNodes(root) { normalize(it.contentDescription?.toString().orEmpty()) == target }
            .firstOrNull { it.isVisibleToUser } ?: return false
        return clickNodeOrClickableParent(node)
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodes(root) { it.isVisibleToUser && it.isEditable && it.isFocused }
            .firstOrNull() ?: findNodes(root) { it.isVisibleToUser && it.isEditable }.firstOrNull() ?: return false
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    fun scrollForward(): Boolean = scroll(true)
    fun scrollBackward(): Boolean = scroll(false)

    fun findVisibleText(text: String): List<AccessibilityNodeInfo> {
        val root = rootInActiveWindow ?: return emptyList()
        val target = normalize(text)
        return findNodes(root) { it.isVisibleToUser && normalize(it.text?.toString().orEmpty()).contains(target) }
    }

    fun waitForForegroundPackage(packageName: String, timeoutMs: Long = 2_500L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            if (foregroundPackage == packageName) return true
            SystemClock.sleep(100)
        }
        return foregroundPackage == packageName
    }

    private fun addOverlay() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            setPadding(0, 0, 0, 0)
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            background = rounded(Color.rgb(20, 24, 29), 28)
            visibility = View.GONE
            elevation = 18f
        }

        val title = TextView(this).apply {
            text = "JARVIS"
            setTextColor(Color.WHITE)
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        panel.addView(title, lp(-1, 40))

        response = TextView(this).apply {
            text = "Ready, sir."
            setTextColor(Color.LTGRAY)
            textSize = 14f
            setPadding(0, 4, 0, 16)
        }
        panel.addView(response, lp(-1, -2))

        input = EditText(this).apply {
            hint = "Tell Jarvis what to do…"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(150, 160, 170))
            background = rounded(Color.rgb(31, 37, 44), 20)
            setPadding(18, 0, 18, 0)
        }
        panel.addView(input, lp(-1, 52))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mic = button("MIC") { startVoice() }
        val send = button("GO") { processOverlayCommand() }
        val close = button("×") { panel.visibility = View.GONE; resizeOverlay(root) }
        actions.addView(mic, lp(0, 48, 1f))
        actions.addView(send, lp(0, 48, 1f, 8))
        actions.addView(close, lp(52, 48, 0f, 8))
        panel.addView(actions)

        approve = button("APPROVE") { show(processor.approve()) }
        cancel = button("CANCEL") { show(processor.cancel()) }
        approve.visibility = View.GONE
        cancel.visibility = View.GONE
        val approvalRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        approvalRow.addView(approve, lp(0, 48, 1f))
        approvalRow.addView(cancel, lp(0, 48, 1f, 8))
        panel.addView(approvalRow, lp(-1, 56))

        val bubble = TextView(this).apply {
            text = "J"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = rounded(Color.rgb(70, 150, 190), 100)
            elevation = 20f
            setOnClickListener {
                panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                resizeOverlay(root)
            }
        }

        root.addView(panel, lp(340, -2))
        root.addView(bubble, lp(60, 60))

        overlay = root
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 18
            y = 0
        }
        windowManager.addView(root, params)
    }

    private fun resizeOverlay(root: View) {
        root.post {
            val params = root.layoutParams as? WindowManager.LayoutParams ?: return@post
            windowManager.updateViewLayout(root, params)
        }
    }

    private fun processOverlayCommand() {
        val text = input.text?.toString().orEmpty().trim()
        if (text.isBlank()) return
        show(processor.handle(text))
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            val intent = android.content.Intent(this, MainActivity::class.java).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("request_mic", true)
            }
            startActivity(intent)
            response.text = "Mic permission is needed once in Jarvis."
            return
        }
        voice.start()
    }

    private fun show(result: CommandResponse) {
        response.text = result.message
        val awaiting = result.state == CommandState.WAITING_FOR_APPROVAL
        approve.visibility = if (awaiting) View.VISIBLE else View.GONE
        cancel.visibility = if (awaiting) View.VISIBLE else View.GONE
        if (result.state == CommandState.SUCCESS) speaker.speak(result.message)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setOnClickListener { action() }
        background = rounded(Color.rgb(38, 47, 56), 18)
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f, marginStart: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { if (marginStart > 0) leftMargin = marginStart }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodes(root) { it.isVisibleToUser && it.isScrollable }.firstOrNull() ?: return false
        return node.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun clickBestMatchingNode(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = normalize(text)
        val exact = findNodes(root) { it.isVisibleToUser && normalize(it.text?.toString().orEmpty()) == target }
        val contains = findNodes(root) { it.isVisibleToUser && normalize(it.text?.toString().orEmpty()).contains(target) }
        return (exact + contains).distinctBy { it.hashCode() }.firstOrNull()?.let(::clickNodeOrClickableParent) == true
    }

    private fun clickNodeOrClickableParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            parent = parent.parent
        }
        return false
    }

    private fun findNodes(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        fun visit(node: AccessibilityNodeInfo?) {
            if (node == null) return
            if (predicate(node)) result += node
            for (i in 0 until node.childCount) visit(node.getChild(i))
        }
        visit(root)
        return result
    }

    private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT)

    override fun onDestroy() {
        runCatching { voice.destroy() }
        runCatching { speaker.shutdown() }
        overlay?.let { runCatching { windowManager.removeView(it) } }
        overlay = null
        if (instance === this) instance = null
        foregroundPackage = null
        super.onDestroy()
    }
}
