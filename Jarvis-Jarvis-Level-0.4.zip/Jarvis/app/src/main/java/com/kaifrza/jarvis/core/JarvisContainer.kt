package com.kaifrza.jarvis.core

import android.content.Context
import com.kaifrza.jarvis.core.actions.ActionExecutor
import com.kaifrza.jarvis.core.actions.ActionRegistry
import com.kaifrza.jarvis.core.actions.ContactResolver
import com.kaifrza.jarvis.core.assistant.ActionHistory
import com.kaifrza.jarvis.core.assistant.CommandProcessor
import com.kaifrza.jarvis.core.intent.LocalCommandUnderstandingEngine
import com.kaifrza.jarvis.core.security.ApprovalManager
import com.kaifrza.jarvis.core.security.RiskEngine

class JarvisContainer(context: Context) {
    private val appContext = context.applicationContext

    val riskEngine = RiskEngine()
    val approvalManager = ApprovalManager()
    val contactResolver = ContactResolver(appContext)
    val actionRegistry = ActionRegistry(appContext, contactResolver)
    val actionHistory = ActionHistory(appContext)
    val actionExecutor = ActionExecutor(riskEngine, approvalManager, actionRegistry)

    /** Shared command state for the app UI and the cross-app accessibility surface. */
    val commandProcessor = CommandProcessor(
        parser = LocalCommandUnderstandingEngine(),
        riskEngine = riskEngine,
        executor = actionExecutor,
        history = actionHistory,
        contacts = contactResolver
    )
}
