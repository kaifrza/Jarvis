package com.kaifrza.jarvis.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.R
import com.kaifrza.jarvis.core.assistant.CommandProcessor
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.voice.JarvisSpeaker
import com.kaifrza.jarvis.voice.JarvisVoiceController

class MainActivity : AppCompatActivity() {

    private val container get() = (application as JarvisApplication).container
    private lateinit var processor: CommandProcessor
    private lateinit var speaker: JarvisSpeaker
    private lateinit var voice: JarvisVoiceController
    private lateinit var response: TextView
    private lateinit var input: EditText
    private lateinit var approve: Button
    private lateinit var cancel: Button
    private lateinit var mic: Button
    private lateinit var setupCard: LinearLayout
    private lateinit var statusBadge: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { updateSetupState() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        processor = container.commandProcessor
        speaker = JarvisSpeaker(this)
        response = findViewById(R.id.responseText)
        input = findViewById(R.id.commandInput)
        approve = findViewById(R.id.approveButton)
        cancel = findViewById(R.id.cancelButton)
        mic = findViewById(R.id.micButton)
        setupCard = findViewById(R.id.setupCard)
        statusBadge = findViewById(R.id.statusBadge)

        voice = JarvisVoiceController(this, object : JarvisVoiceController.Listener {
            override fun onReady() { response.text = "Listening, sir…" }
            override fun onListening() { response.text = "I'm listening…" }
            override fun onPartial(text: String) { if (text.isNotBlank()) input.setText(text) }
            override fun onResult(text: String) { input.setText(text); process(text) }
            override fun onError(message: String) { response.text = message }
        })

        findViewById<Button>(R.id.sendButton).setOnClickListener { process(input.text.toString()) }
        mic.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) voice.start()
            else permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
        approve.setOnClickListener { show(processor.approve()) }
        cancel.setOnClickListener { show(processor.cancel()) }

        findViewById<Button>(R.id.permissionsButton).setOnClickListener {
            val missing = PermissionCenter.missingPermissions(this)
            if (missing.isNotEmpty()) permissionLauncher.launch(missing)
            updateSetupState()
        }
        findViewById<Button>(R.id.accessibilityButton).setOnClickListener { PermissionCenter.openAccessibilitySettings(this) }
        findViewById<Button>(R.id.notificationButton).setOnClickListener { PermissionCenter.openNotificationAccessSettings(this) }

        findViewById<TextView>(R.id.suggestionCall).setOnClickListener { input.setText("Call Zubair") }
        findViewById<TextView>(R.id.suggestionApp).setOnClickListener { input.setText("YouTube kholo") }
        findViewById<TextView>(R.id.suggestionBack).setOnClickListener { input.setText("Back jao") }

        if (intent.getBooleanExtra("request_mic", false) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
        updateSetupState()
    }

    override fun onResume() {
        super.onResume()
        updateSetupState()
    }

    private fun process(raw: String) {
        if (raw.trim().isEmpty()) return
        show(processor.handle(raw))
    }

    private fun show(result: CommandResponse) {
        response.text = result.message
        val awaiting = result.state == CommandState.WAITING_FOR_APPROVAL || result.state == CommandState.WAITING_FOR_CHOICE
        approve.visibility = if (result.state == CommandState.WAITING_FOR_APPROVAL) View.VISIBLE else View.GONE
        cancel.visibility = if (awaiting) View.VISIBLE else View.GONE
        if (result.state == CommandState.SUCCESS) speaker.speak(result.message)
    }

    private fun updateSetupState() {
        val runtimeReady = PermissionCenter.runtimePermissionsReady(this)
        val accessibilityReady = PermissionCenter.isAccessibilityEnabled(this)
        val notificationReady = PermissionCenter.isNotificationAccessEnabled(this)

        findViewById<Button>(R.id.permissionsButton).visibility = if (runtimeReady) View.GONE else View.VISIBLE
        findViewById<Button>(R.id.accessibilityButton).visibility = if (accessibilityReady) View.GONE else View.VISIBLE
        findViewById<Button>(R.id.notificationButton).visibility = if (notificationReady) View.GONE else View.VISIBLE

        // Runtime permissions + Accessibility are the core operating surface.
        // Notification access is optional context, so it never blocks READY state.
        val coreMissing = !runtimeReady || !accessibilityReady
        setupCard.visibility = if (coreMissing) View.VISIBLE else View.GONE
        statusBadge.text = if (coreMissing) "SETUP" else "READY"
        statusBadge.setTextColor(getColor(if (coreMissing) R.color.jarvis_accent else R.color.jarvis_success))
    }

    override fun onDestroy() {
        voice.destroy()
        speaker.shutdown()
        super.onDestroy()
    }
}
