# Jarvis Architecture

## Core pipeline

`Input -> Understanding -> Context/Resolution -> Plan -> Risk -> Approval -> Execute -> Verify -> Respond`

The Android execution layer never receives raw AI access. A future AI provider must emit the same structured `JarvisCommand` contract.

## 0.4 cross-app architecture

The app now has a shared `JarvisContainer`, so the main Activity and the AccessibilityService use the same command processor, history, and pending approval state.

`JarvisAccessibilityService` is the cross-app capability boundary. When the user enables it, Jarvis shows an accessibility overlay bubble. Tapping the bubble opens a compact command panel with text input, push-to-talk, response output, and approval controls. This makes Jarvis usable while another app is in the foreground without requiring `SYSTEM_ALERT_WINDOW`.

The overlay is intentionally separate from the command engine: the overlay collects input and displays results; it does not decide what Android action is safe.

## Contact resolution

Communication commands can now resolve:

- direct phone numbers;
- unique contact names;
- ambiguous contact names with conversational disambiguation.

When multiple contacts match, Jarvis lists masked numbers and accepts clarifications such as `pehla`, `dusra`, `12 se start`, `last 4 digits 5678`, or a full number. The selected number is attached to the structured command before the approval gate.

## Permissions and setup UI

Runtime permissions and the Accessibility capability are treated as core setup. The setup card hides automatically when those core capabilities are ready. Notification access is optional context and does not block the READY state.

## Why the UI remains native for this milestone

HTML/CSS/JavaScript can be used for a visual shell, but the cross-app overlay, accessibility service, runtime permissions, voice capture, and Android actions must remain native. A WebView would not replace those system components. The current milestone keeps the control plane native and lightweight; a WebView-based visual shell can be introduced later behind the same command bridge if desired.

## Future global-assistant layer

The accessibility overlay is the practical Android 10 cross-app surface for this milestone. A later milestone can add a `VoiceInteractionService`/`VoiceInteractionSessionService` integration for system-level assistant invocation. Android keeps the selected `VoiceInteractionService` running for global voice interaction, so that service must stay lightweight and hand actual UI work to its session service.
