# Jarvis Android Assistant — 0.4

Personal-use Android assistant foundation for Android 10+.

## What changed in 0.4

- Direct phone-number calling and SMS target support.
- Conversational contact disambiguation using number prefixes, suffixes, ordinals, or full numbers.
- Shared command processor between app UI and cross-app accessibility overlay.
- Cross-app Jarvis bubble with text input, push-to-talk, response, and approval controls.
- Setup controls hide automatically when core runtime permissions and Accessibility are ready.
- Cleaner native control UI.
- Command regression tests include direct phone numbers.
- GitHub Actions selects the latest committed ZIP, normalizes extracted permissions, uses JDK 17 + Gradle 9.6.0, runs tests, builds the APK, verifies the artifact, and uploads it.

## Example commands

- `Call Zubair`
- `9876543210 par call karo`
- `call +91 98765 43210`
- `Zubair ko call karo`
- If multiple Zubair contacts exist: `pehla`, `dusra`, `12 se start`, `last 4 digits 5678`
- `Zubair ko message bhejo: Main 10 minute mein aa raha hoon`
- `YouTube kholo`
- `back jao`

## Cross-app mode

Enable Jarvis Accessibility from the setup card. A small Jarvis bubble becomes available above other apps. Use it to type or speak commands without reopening the Jarvis Activity.

## Safety model

Sensitive communication actions pass through the approval gate. Prepared actions are not executed until explicitly approved. Pending sensitive approval is held in memory and is not restored after process restart.
