package com.kaifrza.jarvis.core.assistant

import com.kaifrza.jarvis.core.actions.ActionExecutor
import com.kaifrza.jarvis.core.actions.ActionResult
import com.kaifrza.jarvis.core.intent.CommandUnderstandingEngine
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.security.RiskEngine

data class CommandResponse(
    val state: CommandState,
    val message: String,
    val approvalToken: String? = null,
    val commandId: String? = null
)

class CommandProcessor(
    private val parser: CommandUnderstandingEngine,
    private val riskEngine: RiskEngine,
    private val executor: ActionExecutor,
    private val history: ActionHistory
) {
    private var pending: ActionExecutor.PreparedAction? = null

    fun handle(rawText: String): CommandResponse {
        val command = parser.parse(rawText)
        val plan = riskEngine.plan(command)

        if (command.intent == com.kaifrza.jarvis.core.model.IntentType.UNKNOWN) {
            val result = CommandResponse(CommandState.FAILED, "I couldn't understand that command yet.")
            history.record(command, result)
            return result
        }

        val prepared = executor.prepare(plan)

        if (plan.requiresConfirmation) {
            pending = prepared
            return CommandResponse(
                CommandState.WAITING_FOR_APPROVAL,
                confirmationMessage(plan),
                prepared.approvalToken,
                command.id
            )
        }

        val result = executePrepared(prepared)
        history.record(command, result)
        return result
    }

    fun approve(): CommandResponse {
        val prepared = pending
            ?: return CommandResponse(CommandState.FAILED, "There is no pending action to approve.")

        val result = executePrepared(prepared, prepared.approvalToken)
        pending = null
        history.record(prepared.plan.command, result)
        return result
    }

    fun cancel(): CommandResponse {
        val command = pending?.plan?.command
        pending?.approvalToken?.let(executor::revoke)
        pending = null

        val result = CommandResponse(CommandState.CANCELLED, "Cancelled, sir.", commandId = command?.id)
        if (command != null) history.record(command, result)
        return result
    }

    fun hasPendingApproval(): Boolean = pending != null

    private fun executePrepared(
        prepared: ActionExecutor.PreparedAction,
        approvalToken: String? = null
    ): CommandResponse {
        return when (val result = executor.execute(prepared, approvalToken)) {
            ActionResult.Success ->
                CommandResponse(CommandState.SUCCESS, successMessage(prepared.plan.command))
            is ActionResult.Failure ->
                CommandResponse(CommandState.FAILED, result.reason)
            ActionResult.RequiresApproval ->
                CommandResponse(CommandState.WAITING_FOR_APPROVAL, "I need your approval first.")
        }
    }

    private fun confirmationMessage(plan: ActionPlan): String {
        val command = plan.command
        return when (command.intent) {
            com.kaifrza.jarvis.core.model.IntentType.SEND_MESSAGE -> {
                val who = command.parameters["contact_name"] ?: "the contact"
                val body = command.parameters["message"] ?: ""
                "Message ready for $who:\n\n“$body”\n\nBhej doon, sir?"
            }
            com.kaifrza.jarvis.core.model.IntentType.MAKE_CALL -> {
                val who = command.parameters["contact_name"] ?: "this contact"
                "Call $who? Bhej/lagaa doon, sir?"
            }
            else -> "This action needs your approval, sir.\n\n${command.rawText}"
        }
    }

    private fun successMessage(command: JarvisCommand): String {
        return when (command.intent) {
            com.kaifrza.jarvis.core.model.IntentType.OPEN_APP -> "Opened the app, sir."
            com.kaifrza.jarvis.core.model.IntentType.NAVIGATE_BACK -> "Done, sir."
            com.kaifrza.jarvis.core.model.IntentType.HOME -> "Home opened, sir."
            com.kaifrza.jarvis.core.model.IntentType.RECENTS -> "Recent apps opened, sir."
            com.kaifrza.jarvis.core.model.IntentType.OPEN_NOTIFICATIONS -> "Notifications opened, sir."
            com.kaifrza.jarvis.core.model.IntentType.MAKE_CALL -> "Call started, sir."
            com.kaifrza.jarvis.core.model.IntentType.SEND_MESSAGE -> "Message sent, sir."
            else -> "Done, sir."
        }
    }

    fun lastHistory(): List<ActionHistory.Entry> = history.read()
}
