# Jarvis Android Assistant — 0.6

Personal-use Android assistant foundation for Android 10+.

## 0.6 Brain Spine

Jarvis now has a provider-neutral planning spine:

`Voice/Text -> Conversation -> Brain -> Tool/Plan Validation -> Risk Policy -> Approval/Choice -> Action Executor -> Verification -> Response`

### What changed

- **Tool registry:** one source of truth for exposed capabilities, arguments, risk and confirmation policy.
- **Function calling:** the remote OpenAI-compatible transport now advertises registered tools and can consume `tool_calls`; strict JSON planning remains as a fallback contract.
- **Plan validation:** model output is rejected before execution when a tool is unknown, unsupported, over-sized, or missing required arguments.
- **Conversation context:** bounded in-memory context helps follow-up commands without persisting the conversation.
- **Safer history:** message bodies are not written into the persistent action history.
- **Multi-step runner:** active plans pause for contact choice or approval and resume only while the process is alive.
- **SMS verification:** SMS execution waits for Android's sent-result callback instead of immediately reporting success.
- **App verification:** launch actions verify the expected foreground package when Accessibility is available.
- **System assistant foundation:** `VoiceInteractionService` and `VoiceInteractionSessionService` are now correctly declared with the required system binding permission and metadata. The user still has to select Jarvis as the active assistant in Android settings.
- **Premium Web UI:** the HTML/CSS/JS face now uses a conversation feed, action confirmation surface, cleaner status system and keyboard-safe composer.

## Brain setup

Open Jarvis settings and configure a trusted OpenAI-compatible chat endpoint, model, and API key. The endpoint should support chat completions with function/tool calls; strict JSON output is also accepted. The API key is stored using Android Keystore encryption.

Do not put API keys into source code or GitHub.

Without remote configuration, Jarvis stays usable with the local command engine.

## Example commands

- `YouTube kholo`
- `Zubair ko call karo`
- `9876543210 par call karo`
- `Zubair ko message bhejo: Main 10 minute mein aa raha hoon`
- `WhatsApp kholo aur phir back jao` (remote brain configured)

## Security model

The brain cannot access Android APIs directly. It can only propose registered tools. The policy layer decides risk and confirmation; the executor performs the action; the verifier reports what Android actually confirmed.

High-risk communication actions require explicit user approval. Pending approvals are short-lived and in-memory.

## Android 10 note

Android controls which apps can become the global assistant and how background voice interaction behaves. Jarvis does not pretend that a normal sideloaded app can bypass those platform rules. Accessibility remains a separate capability boundary for cross-app UI control.

## CI

The GitHub Actions workflow selects the latest committed `Jarvis-*.zip`, extracts it into a clean build directory, runs unit tests and assembles the debug APK, then uploads the APK artifact.


## 0.7 Offline Agent Runtime
Jarvis now plans supported multi-step cross-app workflows offline and routes them through the same approval/execution/verification boundary. API configuration remains optional. See `docs/ARCHITECTURE-0.7.md`.


## 0.8 focus
0.8 fixes the failed multi-task path by adding task lanes and visible step state, an overlay assistant launched from the draggable J bubble, broader offline command normalization, calculator/flashlight/system-settings tools, and optional-cloud behavior.

Example: `Chrome kholo aur YouTube search karo saath hi Calculator kholo aur 125 x 48 calculate karo`.
The UI now shows every planned step and its live state. Foreground UI actions are scheduled safely because Android cannot keep two third-party apps simultaneously in the foreground.


## 0.8.2 Build Fix
This build fixes Kotlin override return-type errors in the Accessibility overlay voice listener by replacing expression-bodied nullable callbacks with explicit Unit-returning block bodies. It also makes the overlay drag listener return its Boolean result explicitly.

The fix targets the GitHub Actions errors around `onPartial`, `onError`, and `Missing return statement` in `JarvisAccessibilityService.kt`.


## 0.8.2 build fix
Removed the non-portable AccessibilityNodeInfo.ACTION_IME_ENTER reference from search submission; search now uses exposed Search/Go/Enter controls.


## 0.9.0 Engineering Audit Pass

This build is a stability-focused consolidation after CI failures in 0.8.x.

### Changes
- Round-robin multi-task lanes with persistent per-step state.
- The plan no longer silently loses later tasks when an earlier lane fails.
- Browser search fallback for Chrome/Firefox/Edge/Brave when an accessible Search/Enter control is unavailable.
- Wi-Fi/mobile-data/Bluetooth natural-language toggle intents with Accessibility Quick Settings fallback.
- Capability setup now requests the runtime permissions actually declared by the app instead of hiding them after microphone-only approval.
- Overlay input explicitly focuses the HTML composer and remains scrollable/draggable.
- Task board groups steps by task and shows per-task completion.
- Added offline parser/agent regression tests.
- Added repository preflight checks for XML, manifest components, resources and known compile traps.

### Verification performed before handoff
- Pure Kotlin parser/agent compilation: PASS
- Offline phrase matrix: PASS
- Multi-task lane planner: PASS
- Round-robin scheduler harness: PASS
- JavaScript syntax: PASS
- XML parsing: PASS
- Manifest component resolution: PASS
- Resource reference audit: PASS
- Known `ACTION_IME_ENTER` compile trap: absent

A full Android SDK/Gradle build must still be performed by GitHub Actions.
