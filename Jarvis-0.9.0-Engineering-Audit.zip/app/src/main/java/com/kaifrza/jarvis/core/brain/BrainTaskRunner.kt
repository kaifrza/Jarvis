package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.assistant.CommandProcessor
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.conversation.ConversationManager
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.JarvisCommand

/**
 * Coordinates a plan made of independent task lanes.
 *
 * Foreground Android UI is inherently single-window, so the scheduler does not pretend
 * that two apps can be manipulated simultaneously. Instead it interleaves independent
 * lanes round-robin, keeps every lane's state visible, and stops the whole plan when a
 * user decision/approval is required. This prevents the old failure mode where step 2
 * of lane B was silently lost after lane A failed.
 */
class BrainTaskRunner(
    private val brain: BrainEngine,
    private val processor: CommandProcessor,
    private val conversation: ConversationManager
) {
    private data class ActivePlan(
        val id: String,
        val reply: String?,
        val startedAtMs: Long,
        val originalText: String
    )

    private data class Lane(
        val id: String,
        val label: String,
        val steps: ArrayDeque<BrainStep>,
        var blocked: Boolean = false,
        var done: Boolean = false
    )

    data class StepView(
        val taskId: String,
        val taskLabel: String,
        val index: Int,
        val total: Int,
        val title: String,
        val state: String
    )

    fun interface ProgressListener { fun onProgress(steps: List<StepView>) }

    @Volatile private var progressListener: ProgressListener? = null
    private var activePlan: ActivePlan? = null
    private val lanes = linkedMapOf<String, Lane>()
    private val states = linkedMapOf<String, String>()
    private val stepLookup = linkedMapOf<String, BrainStep>()
    private var waitingStepId: String? = null
    private var waitingTaskId: String? = null

    fun setProgressListener(listener: ProgressListener?) {
        progressListener = listener
        emitProgress()
    }

    fun handle(rawText: String, context: String = ""): CommandResponse {
        val text = rawText.trim()
        if (text.isEmpty()) return CommandResponse(CommandState.FAILED, "Command khaali hai, sir.")

        // Approval/choice responses belong to the active plan; do not interpret them as a new task.
        if (processor.hasPendingApproval() || processor.hasPendingChoice()) {
            return continuePending(processor.handle(text))
        }

        val mergedContext = buildString {
            if (context.isNotBlank()) append(context)
            val history = conversation.context()
            if (history.isNotBlank()) {
                if (isNotEmpty()) append('\n')
                append("Recent conversation:\n").append(history)
            }
        }

        val plan = brain.plan(text, mergedContext)
        if (plan.steps.isEmpty()) {
            val failed = CommandResponse(CommandState.FAILED, plan.reply ?: "Sir, mujhe abhi is command ko confidently map karna nahi aaya.")
            conversation.add(text, failed.message)
            return failed
        }

        resetPlan(plan.steps)
        activePlan = ActivePlan(plan.id, plan.reply, System.currentTimeMillis(), text)
        val response = runRoundRobin()
        return finalizeIfComplete(response)
    }

    fun approve(): CommandResponse = continuePending(processor.approve())

    fun cancel(): CommandResponse {
        val response = processor.cancel()
        clearPlan()
        return response
    }

    private fun resetPlan(steps: List<BrainStep>) {
        lanes.clear()
        states.clear()
        stepLookup.clear()
        waitingStepId = null
        waitingTaskId = null

        steps.groupBy { it.taskId }.forEach { (taskId, taskSteps) ->
            val label = taskSteps.firstOrNull()?.taskLabel ?: taskId
            val queue = ArrayDeque<BrainStep>()
            taskSteps.forEach { step ->
                queue.add(step)
                stepLookup[step.command.id] = step
                states[step.command.id] = "QUEUED"
            }
            lanes[taskId] = Lane(taskId, label, queue)
        }
        emitProgress()
    }

    /** One foreground action per lane per round. Independent lanes therefore make progress. */
    private fun runRoundRobin(): CommandResponse {
        var lastResponse = CommandResponse(CommandState.SUCCESS, "Done, sir.")
        var failureResponse: CommandResponse? = null
        var madeProgress: Boolean

        do {
            madeProgress = false
            for ((taskId, lane) in lanes) {
                if (lane.done || lane.blocked || lane.steps.isEmpty()) {
                    if (lane.steps.isEmpty()) lane.done = true
                    continue
                }

                val step = lane.steps.removeFirst()
                states[step.command.id] = "RUNNING"
                emitProgress()
                madeProgress = true

                val response = processor.handleCommand(step.command)
                lastResponse = response
                when (response.state) {
                    CommandState.WAITING_FOR_APPROVAL,
                    CommandState.WAITING_FOR_CHOICE -> {
                        states[step.command.id] = "WAITING"
                        lane.blocked = true
                        waitingStepId = step.command.id
                        waitingTaskId = taskId
                        emitProgress()
                        // A foreground-sensitive pending action must stop all other lanes.
                        return response
                    }
                    CommandState.FAILED -> {
                        states[step.command.id] = "FAILED"
                        lane.blocked = true
                        lane.done = true
                        failureResponse = failureResponse ?: response
                        emitProgress()
                        // Do not discard unrelated lanes; they continue in the next round.
                    }
                    CommandState.CANCELLED -> {
                        states[step.command.id] = "CANCELLED"
                        lane.done = true
                        emitProgress()
                    }
                    else -> {
                        states[step.command.id] = "DONE"
                        if (lane.steps.isEmpty()) lane.done = true
                        emitProgress()
                    }
                }
            }
        } while (madeProgress && lanes.values.any { !it.done && !it.blocked })

        return if (lanes.values.all { it.done }) {
            failureResponse ?: CommandResponse(CommandState.SUCCESS, activePlan?.reply ?: "Done, sir.")
        } else {
            failureResponse ?: lastResponse
        }
    }

    private fun continuePending(response: CommandResponse): CommandResponse {
        val stepId = waitingStepId
        val taskId = waitingTaskId
        if (response.state == CommandState.WAITING_FOR_APPROVAL || response.state == CommandState.WAITING_FOR_CHOICE) {
            return response
        }

        if (stepId != null) {
            states[stepId] = when (response.state) {
                CommandState.SUCCESS -> "DONE"
                CommandState.CANCELLED -> "CANCELLED"
                else -> "FAILED"
            }
        }
        if (taskId != null) lanes[taskId]?.blocked = false
        waitingStepId = null
        waitingTaskId = null
        emitProgress()

        if (response.state == CommandState.CANCELLED || response.state == CommandState.FAILED) {
            return response
        }

        val next = runRoundRobin()
        return finalizeIfComplete(next)
    }

    private fun finalizeIfComplete(response: CommandResponse): CommandResponse {
        val complete = activePlan != null && lanes.isNotEmpty() && lanes.values.all { it.done }
        if (!complete) return response
        val final = if (!activePlan?.reply.isNullOrBlank() && response.state == CommandState.SUCCESS) {
            response.copy(message = activePlan?.reply.orEmpty())
        } else response
        val original = activePlan?.originalText
        if (final.state == CommandState.SUCCESS || final.state == CommandState.FAILED || final.state == CommandState.CANCELLED) {
            if (!original.isNullOrBlank()) conversation.add(original, final.message)
            clearPlan()
        }
        return final
    }

    private fun clearPlan() {
        activePlan = null
        lanes.clear()
        states.clear()
        stepLookup.clear()
        waitingStepId = null
        waitingTaskId = null
        emitProgress()
    }

    private fun emitProgress() {
        val listener = progressListener ?: return
        val all = stepLookup.values.toList()
        val totals = all.groupingBy { it.taskId }.eachCount()
        val indexes = mutableMapOf<String, Int>()
        val views = all.map { step ->
            val index = (indexes[step.taskId] ?: 0) + 1
            indexes[step.taskId] = index
            StepView(
                taskId = step.taskId,
                taskLabel = step.taskLabel,
                index = index,
                total = totals[step.taskId] ?: 1,
                title = step.rationale ?: step.command.rawText,
                state = states[step.command.id] ?: "QUEUED"
            )
        }
        listener.onProgress(views)
    }
}
