package com.kaifrza.jarvis.core.actions

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.Settings
import android.net.wifi.WifiManager
import android.bluetooth.BluetoothAdapter
import android.os.Build
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType

class UtilityAction(private val context: Context) : JarvisAction {
    override val id = "android.utility"

    override fun validate(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.CALCULATE -> if (plan.command.parameters["expression"].isNullOrBlank()) ActionResult.Failure("Mujhe calculation expression nahi mila.") else ActionResult.Success
        IntentType.SET_FLASHLIGHT -> if (Build.VERSION.SDK_INT >= 23) ActionResult.Success else ActionResult.Failure("Torch control is not available on this Android version.")
        IntentType.TOGGLE_WIFI, IntentType.TOGGLE_MOBILE_DATA, IntentType.TOGGLE_BLUETOOTH -> if (JarvisAccessibilityService.instance == null) ActionResult.Failure("Accessibility Service is required for system toggle control.") else ActionResult.Success
        else -> ActionResult.Success
    }

    override fun execute(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.OPEN_NETWORK_SETTINGS -> open(Settings.ACTION_WIRELESS_SETTINGS)
        IntentType.OPEN_WIFI_SETTINGS -> open(Settings.ACTION_WIFI_SETTINGS)
        IntentType.OPEN_BLUETOOTH_SETTINGS -> open(Settings.ACTION_BLUETOOTH_SETTINGS)
        IntentType.SET_FLASHLIGHT -> setTorch(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_WIFI -> toggleWifi(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_MOBILE_DATA -> toggleMobileData(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_BLUETOOTH -> toggleBluetooth(plan.command.parameters["enabled"] != "false")
        IntentType.CALCULATE -> {
            val expression = plan.command.parameters["expression"].orEmpty()
            val result = SimpleCalculator.evaluate(expression)
            if (result == null) ActionResult.Failure("Main calculation ko samajh nahi paaya: $expression")
            else ActionResult.SuccessWithMessage("$expression = $result")
        }
        else -> ActionResult.Failure("Unsupported utility action.")
    }

    override fun verify(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.TOGGLE_WIFI -> verifyWifi(plan.command.parameters["enabled"] != "false")
        IntentType.TOGGLE_BLUETOOTH -> verifyBluetooth(plan.command.parameters["enabled"] != "false")
        else -> ActionResult.Success
    }

    private fun toggleWifi(enabled: Boolean): ActionResult {
        val manager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        if (manager != null && manager.isWifiEnabled == enabled) return ActionResult.Success
        return JarvisAccessibilityService.instance?.openQuickSettingsAndToggle(
            labels = listOf("Wi-Fi", "Wifi"), desiredEnabled = enabled
        )?.let { if (it) ActionResult.Success else ActionResult.Failure("Wi-Fi toggle control could not be located.") }
            ?: ActionResult.Failure("Accessibility Service is unavailable.")
    }

    private fun toggleMobileData(enabled: Boolean): ActionResult {
        return JarvisAccessibilityService.instance?.openQuickSettingsAndToggle(
            labels = listOf("Mobile data", "Mobile Data", "Internet", "Data"), desiredEnabled = enabled
        )?.let { if (it) ActionResult.Success else ActionResult.Failure("Mobile-data/Internet toggle could not be located. Android may expose it under a different label.") }
            ?: ActionResult.Failure("Accessibility Service is unavailable.")
    }

    private fun toggleBluetooth(enabled: Boolean): ActionResult {
        val adapter = runCatching { BluetoothAdapter.getDefaultAdapter() }.getOrNull()
        if (adapter != null && adapter.isEnabled == enabled) return ActionResult.Success
        return JarvisAccessibilityService.instance?.openQuickSettingsAndToggle(
            labels = listOf("Bluetooth"), desiredEnabled = enabled
        )?.let { if (it) ActionResult.Success else ActionResult.Failure("Bluetooth toggle control could not be located.") }
            ?: ActionResult.Failure("Accessibility Service is unavailable.")
    }

    private fun verifyWifi(enabled: Boolean): ActionResult {
        val manager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            ?: return ActionResult.Success
        val deadline = android.os.SystemClock.uptimeMillis() + 2_500L
        while (android.os.SystemClock.uptimeMillis() < deadline) {
            if (manager.isWifiEnabled == enabled) return ActionResult.Success
            android.os.SystemClock.sleep(120)
        }
        return ActionResult.Failure("Wi-Fi state could not be verified.")
    }

    private fun verifyBluetooth(enabled: Boolean): ActionResult {
        val adapter = runCatching { BluetoothAdapter.getDefaultAdapter() }.getOrNull()
            ?: return ActionResult.Success
        val deadline = android.os.SystemClock.uptimeMillis() + 2_500L
        while (android.os.SystemClock.uptimeMillis() < deadline) {
            if (adapter.isEnabled == enabled) return ActionResult.Success
            android.os.SystemClock.sleep(120)
        }
        return ActionResult.Failure("Bluetooth state could not be verified.")
    }

    private fun open(action: String): ActionResult = runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Settings open nahi ho sakin.") }

    private fun setTorch(enabled: Boolean): ActionResult = runCatching {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id -> manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return ActionResult.Failure("Torch camera nahi mila.")
        manager.setTorchMode(cameraId, enabled)
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Torch control fail hua: ${it.message ?: "unknown"}") }
}

private object SimpleCalculator {
    fun evaluate(raw: String): String? {
        val s = raw.replace(" ", "")
        val m = Regex("^(-?\\d+(?:\\.\\d+)?)([+\\-*/])(-?\\d+(?:\\.\\d+)?)$").matchEntire(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val v = when (m.groupValues[2]) { "+" -> a+b; "-" -> a-b; "*" -> a*b; "/" -> if (b == 0.0) return null else a/b; else -> return null }
        return if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
    }
}
