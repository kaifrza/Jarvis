package com.kaifrza.jarvis.accessibility

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class QuickSettingsParsingTest {
    @Test fun pageIndicatorIsParsed() {
        assertEquals(1 to 3, QuickSettingsParsing.parsePage("Page 1 of 3"))
        assertEquals(2 to 3, QuickSettingsParsing.parsePage("page 2 of 3"))
        assertNull(QuickSettingsParsing.parsePage("Wi-Fi,"))
        assertNull(QuickSettingsParsing.parsePage(null))
    }

    @Test fun tileLabelsLoseTrailingPunctuation() {
        // The Vivo panel exposes the Wi-Fi tile as desc="Wi-Fi," (with a comma).
        assertEquals("wi-fi", QuickSettingsParsing.cleanLabel("Wi-Fi,"))
        assertEquals("data network", QuickSettingsParsing.cleanLabel("  Data   network "))
    }

    @Test fun exactBeatsPrefixAndSaverTilesAreNotMixedUp() {
        assertEquals(2, QuickSettingsParsing.matchScore("Wi-Fi,", listOf("Wi-Fi", "WLAN")))
        assertEquals(2, QuickSettingsParsing.matchScore("Data network", listOf("Mobile data", "Data network")))
        assertEquals(1, QuickSettingsParsing.matchScore("Airplane mode", listOf("Airplane")))
        assertEquals(0, QuickSettingsParsing.matchScore("Low power mode", listOf("Super Battery Saver")))
        assertEquals(0, QuickSettingsParsing.matchScore("Super Battery Saver", listOf("Battery")))
        assertEquals(2, QuickSettingsParsing.matchScore("Super Battery Saver", listOf("Super Battery Saver")))
        assertEquals(0, QuickSettingsParsing.matchScore("", listOf("Wi-Fi")))
    }
}
