package com.kaifrza.jarvis.accessibility

/** Pure helpers for reading the Vivo Quick Settings panel (unit-tested, no Android types). */
object QuickSettingsParsing {
    private val pageRe = Regex("page\\s+(\\d+)\\s+of\\s+(\\d+)", RegexOption.IGNORE_CASE)

    /** "Page 2 of 3" -> (2, 3). The footer indicator exposes this as its content description. */
    fun parsePage(desc: String?): Pair<Int, Int>? {
        val m = pageRe.find(desc.orEmpty()) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    /** Tile descriptions carry trailing punctuation on this phone: "Wi-Fi," -> "wi-fi". */
    fun cleanLabel(raw: String?): String =
        raw.orEmpty().lowercase().replace(Regex("\\s+"), " ").trim().trimEnd(',', '.', ';', ':', ' ')

    /** 2 = exact label, 1 = label starts with the wanted text, 0 = no match. "Saver" tiles never match a non-saver request. */
    fun matchScore(label: String?, wanted: List<String>): Int {
        val l = cleanLabel(label)
        if (l.isEmpty()) return 0
        var best = 0
        for (w in wanted.map(::cleanLabel)) {
            if (w.isEmpty()) continue
            if (l == w) return 2
            if (l.startsWith(w) && !(l.contains("saver") && !w.contains("saver"))) best = 1
        }
        return best
    }
}
