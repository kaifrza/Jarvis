package com.kaifrza.jarvis.accessibility

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import com.kaifrza.jarvis.ui.MainActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Recon: reads (never taps anything except page swipes / back) the Quick Settings panel, the Bluetooth,
 * Wi-Fi and Sound settings pages and writes every node label/state to a text report. The report is used to
 * calibrate Jarvis for this exact phone (tile names, pages, which nodes expose on/off state).
 */
object ReconTool {
    @Volatile var running = false
        private set
    @Volatile var lastReport: String? = null
        private set
    @Volatile var lastPath: String? = null
        private set
    @Volatile var finishedNotice = false

    fun start(service: JarvisAccessibilityService, onDone: () -> Unit): Boolean {
        if (running) return false
        running = true
        finishedNotice = false
        Thread({
            val report = try {
                build(service)
            } catch (t: Throwable) {
                "Recon failed: ${t.message}"
            }
            lastReport = report
            lastPath = save(service.applicationContext, report)
            running = false
            finishedNotice = true
            runCatching {
                service.startActivity(
                    Intent(service, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            }
            onDone()
        }, "jarvis-recon").start()
        return true
    }

    private fun build(s: JarvisAccessibilityService): String {
        previousBody = null
        val out = StringBuilder()
        val dm = s.resources.displayMetrics
        out.append("JARVIS RECON ").append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).append('\n')
        out.append("device=").append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL)
            .append(" | android=").append(android.os.Build.VERSION.RELEASE).append(" (sdk ").append(android.os.Build.VERSION.SDK_INT).append(')')
            .append(" | screen=").append(dm.widthPixels).append('x').append(dm.heightPixels).append('\n')
        out.append("NOTE: this file contains on-screen text (device names, Wi-Fi names). Review before sharing.\n\n")

        // ---- Quick Settings: opens collapsed on this phone, so expand it, then walk the pages
        if (QuickSettingsNavigator.open(s)) {
            section(out, "QUICK_SETTINGS (as opened, before expanding)", dumpWindows(s))
            QuickSettingsNavigator.expand(s)
            section(out, "QUICK_SETTINGS expanded, page 1", dumpWindows(s))
            for (page in 2..4) {
                val moved = QuickSettingsNavigator.page(s, true)
                section(out, "QUICK_SETTINGS page $page (page-forward returned $moved)", dumpWindows(s))
            }
            repeat(4) { QuickSettingsNavigator.page(s, false) }
            s.closeQuickSettings()
        } else {
            section(out, "QUICK_SETTINGS", "GLOBAL_ACTION_QUICK_SETTINGS failed")
        }
        SystemClock.sleep(500L)

        section(out, "STATE PROBES (compare with what the panel really shows right now)", probes(s))

        // ---- Settings pages
        settingsPage(s, out, "BLUETOOTH settings", Settings.ACTION_BLUETOOTH_SETTINGS, scrolls = 1)
        settingsPage(s, out, "WI-FI settings", Settings.ACTION_WIFI_SETTINGS, scrolls = 1)
        settingsPage(s, out, "SOUND settings", Settings.ACTION_SOUND_SETTINGS, scrolls = 1)

        out.append("\nEND OF RECON\n")
        return out.toString()
    }

    private fun settingsPage(s: JarvisAccessibilityService, out: StringBuilder, title: String, action: String, scrolls: Int) {
        runCatching { s.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { section(out, title, "could not open: ${it.message}"); return }
        SystemClock.sleep(1_900L)
        section(out, "$title (top)", dumpWindows(s))
        repeat(scrolls) { i ->
            if (s.scrollForward()) {
                SystemClock.sleep(700L)
                section(out, "$title (scrolled ${i + 1})", dumpWindows(s))
            }
        }
        s.performGlobalActionBack()
        SystemClock.sleep(450L)
        s.performGlobalActionBack()
        SystemClock.sleep(450L)
    }

    /** Official-API readings of the toggles, so Jarvis can be checked against the real tile states. */
    private fun probes(s: JarvisAccessibilityService): String {
        val c = s.applicationContext
        val cr = c.contentResolver
        fun <T> p(name: String, block: () -> T): String = name + "=" + runCatching { block().toString() }.getOrElse { "ERR(" + it.javaClass.simpleName + ")" }
        val audio = c.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val wifi = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
        return listOf(
            p("mobile_data") { android.provider.Settings.Global.getInt(cr, "mobile_data", -1) },
            p("mobile_data1") { android.provider.Settings.Global.getInt(cr, "mobile_data1", -1) },
            p("mobile_data2") { android.provider.Settings.Global.getInt(cr, "mobile_data2", -1) },
            p("airplane_mode_on") { android.provider.Settings.Global.getInt(cr, android.provider.Settings.Global.AIRPLANE_MODE_ON, -1) },
            p("location_enabled") { (c.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager).isLocationEnabled },
            p("wifi_enabled") { wifi.isWifiEnabled },
            p("wifi_ap_enabled(reflection)") { WifiManager_isApEnabled(wifi) },
            p("bluetooth_enabled") { android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.isEnabled },
            p("bluetooth_bonded_devices") { android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.joinToString { it.name ?: "?" } },
            p("ringer_mode(0=silent,1=vibrate,2=normal)") { audio.ringerMode },
            p("dnd_filter(1=all,2=priority,3=none,4=alarms)") { nm.currentInterruptionFilter },
            p("dnd_access_granted") { nm.isNotificationPolicyAccessGranted },
            p("accelerometer_rotation(0=locked)") { android.provider.Settings.System.getInt(cr, android.provider.Settings.System.ACCELEROMETER_ROTATION, -1) },
            p("brightness_mode(1=auto)") { android.provider.Settings.System.getInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, -1) },
            p("brightness_255") { android.provider.Settings.System.getInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS, -1) },
            p("music_volume") { audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toString() + "/" + audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) },
            p("ring_volume") { audio.getStreamVolume(android.media.AudioManager.STREAM_RING).toString() + "/" + audio.getStreamMaxVolume(android.media.AudioManager.STREAM_RING) },
            p("alarm_volume") { audio.getStreamVolume(android.media.AudioManager.STREAM_ALARM).toString() + "/" + audio.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM) },
            p("notification_volume") { audio.getStreamVolume(android.media.AudioManager.STREAM_NOTIFICATION).toString() + "/" + audio.getStreamMaxVolume(android.media.AudioManager.STREAM_NOTIFICATION) },
            p("call_volume") { audio.getStreamVolume(android.media.AudioManager.STREAM_VOICE_CALL).toString() + "/" + audio.getStreamMaxVolume(android.media.AudioManager.STREAM_VOICE_CALL) }
        ).joinToString("\n")
    }

    @Suppress("FunctionName")
    private fun WifiManager_isApEnabled(w: android.net.wifi.WifiManager): Boolean? =
        w.javaClass.getMethod("isWifiApEnabled").invoke(w) as? Boolean

    private fun section(out: StringBuilder, title: String, body: String) {
        out.append("=== ").append(title).append(" ===\n").append(body).append("\n\n")
    }

    private val noiseIds = setOf(
        "status_bar_left_clock", "battery", "battery_level", "networkspeed_vertical", "networkspeed_num",
        "networkspeed_unit", "vivo_flow", "flow1", "vivo_carrier1", "vivo_carrier2", "date",
        "mobile_type_signal_sim1", "mobile_type_signal_sim2"
    )
    private var previousBody: String? = null

    /** Dumps the window Jarvis would act on (not the overlay/keyboard), without status-bar noise. */
    private fun dumpWindows(s: JarvisAccessibilityService): String {
        val sb = StringBuilder()
        val windows = runCatching { s.windows }.getOrNull().orEmpty()
        sb.append("windows: ").append(windows.joinToString(" | ") { w -> "type" + w.type + ":" + (w.root?.packageName ?: "-") }).append('\n')
        s.pageIndicator()?.let { sb.append("page indicator: ").append(it.first).append(" of ").append(it.second).append('\n') }
        val root = s.targetRoot()
        val body = StringBuilder()
        if (root != null) dumpNode(root, 0, body, Counter()) else body.append("(no root)\n")
        val text = body.toString()
        if (text == previousBody) sb.append("(same as previous dump)\n") else sb.append(text)
        previousBody = text
        return sb.toString()
    }

    private class Counter { var n = 0 }

    private fun dumpNode(node: AccessibilityNodeInfo, depth: Int, sb: StringBuilder, counter: Counter) {
        if (counter.n >= 300) return
        counter.n++
        val id = node.viewIdResourceName?.substringAfterLast('/')
        val text = node.text?.toString()?.replace('\n', ' ')?.take(80)
        val desc = node.contentDescription?.toString()?.replace('\n', ' ')?.take(80)
        val noisy = (id != null && id in noiseIds) || (desc != null && (desc.startsWith("4G signal") || desc.startsWith("Battery")))
        val cls = node.className?.toString()?.substringAfterLast('.') ?: "?"
        val interesting = !text.isNullOrBlank() || !desc.isNullOrBlank() || node.isClickable || node.isCheckable || node.isScrollable
        if (interesting && node.isVisibleToUser && !noisy) {
            val r = Rect()
            node.getBoundsInScreen(r)
            sb.append("  ".repeat(depth.coerceAtMost(12))).append(cls)
            if (!text.isNullOrBlank()) sb.append(" text=\"").append(text).append('"')
            if (!desc.isNullOrBlank()) sb.append(" desc=\"").append(desc).append('"')
            id?.let { sb.append(" id=").append(it) }
            val flags = buildList {
                if (node.isClickable) add("click")
                if (node.isCheckable) add(if (node.isChecked) "CHECKED" else "unchecked")
                if (node.isSelected && cls != "TextView") add("SELECTED")
                if (!node.isEnabled) add("disabled")
                if (node.isScrollable) add("scroll")
            }
            if (flags.isNotEmpty()) sb.append(" [").append(flags.joinToString(",")).append(']')
            sb.append(" @").append(r.left).append(',').append(r.top).append('-').append(r.right).append(',').append(r.bottom).append('\n')
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            dumpNode(child, depth + 1, sb, counter)
        }
    }

    private fun save(context: Context, report: String): String? = runCatching {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        val file = File(dir, "jarvis-recon.txt")
        file.writeText(report)
        file.absolutePath
    }.getOrNull()
}
