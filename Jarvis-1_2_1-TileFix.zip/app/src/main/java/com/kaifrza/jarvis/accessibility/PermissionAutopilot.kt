package com.kaifrza.jarvis.accessibility

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.kaifrza.jarvis.ui.MainActivity
import com.kaifrza.jarvis.ui.PermissionCenter

/**
 * Guided permission setup. Jarvis only OPENS each permission page / dialog, one after another, and then waits
 * until the user has allowed it by hand (it polls the real permission state). It never taps "Allow" or flips a
 * switch itself and never turns anything off, so a phone glitch can never grant or revoke anything behind the
 * user's back. A step the user does not want can be skipped with the "Skip step" button or just times out.
 */
object PermissionAutopilot {
    enum class State { PENDING, RUNNING, OK, FAILED, SKIPPED }

    data class Step(val id: String, val title: String, val state: State, val note: String = "")

    const val EXTRA_REQUEST_RUNTIME = "jarvis_request_runtime"
    private const val WAIT_MS = 120_000L

    @Volatile var running = false
        private set

    @Volatile var steps: List<Step> = emptyList()
        private set

    @Volatile private var skipRequested = false

    fun start(service: JarvisAccessibilityService): Boolean {
        if (running) return false
        running = true
        skipRequested = false
        steps = definitions().map { Step(it.first, it.second, State.PENDING) }
        Thread({ runAll(service) }, "jarvis-permission-guide").start()
        return true
    }

    /** The user pressed "Skip step" for the page that is currently open. */
    fun skipCurrent() {
        skipRequested = true
    }

    private fun definitions(): List<Pair<String, String>> = buildList {
        add("runtime" to "Mic, Contacts, Call, SMS")
        add("write_settings" to "System settings badalna")
        add("notifications" to "Notification access")
        add("dnd" to "Do Not Disturb access")
        add("battery" to "Battery restriction")
        if (PermissionCenter.isVivoFamily()) add("autostart" to "Vivo autostart")
    }

    private fun update(id: String, state: State, note: String = "") {
        steps = steps.map { if (it.id == id) it.copy(state = state, note = note) else it }
    }

    private fun runAll(service: JarvisAccessibilityService) {
        val ctx: Context = service.applicationContext
        try {
            for ((id, _) in definitions()) {
                update(id, State.RUNNING, "page khuli hai - Allow karo")
                skipRequested = false
                val result = runCatching { runStep(id, service, ctx) }
                    .getOrElse { State.FAILED to (it.message ?: "error") }
                update(id, result.first, result.second)
                SystemClock.sleep(400L)
            }
        } finally {
            running = false
            runCatching {
                service.startActivity(
                    Intent(service, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            }
        }
    }

    private fun runStep(id: String, s: JarvisAccessibilityService, ctx: Context): Pair<State, String> = when (id) {
        "runtime" -> runtimeStep(s, ctx)
        "write_settings" -> waitStep(s, { PermissionCenter.canWriteSettings(ctx) }, PermissionCenter.writeSettingsIntent(ctx))
        "notifications" -> waitStep(s, { PermissionCenter.isNotificationAccessEnabled(ctx) }, PermissionCenter.notificationListenerIntent())
        "dnd" -> waitStep(s, { PermissionCenter.isDndAccessGranted(ctx) }, PermissionCenter.dndAccessIntent())
        "battery" -> waitStep(s, { PermissionCenter.isIgnoringBatteryOptimizations(ctx) }, PermissionCenter.batteryExemptionIntent(ctx))
        "autostart" -> autostartStep(s)
        else -> State.SKIPPED to "unknown step"
    }

    /** Waits until [done] becomes true, the user skips, or the time runs out. */
    private fun waitUntil(done: () -> Boolean): Boolean? {
        val deadline = SystemClock.uptimeMillis() + WAIT_MS
        while (SystemClock.uptimeMillis() < deadline) {
            if (done()) return true
            if (skipRequested) return null
            SystemClock.sleep(500L)
        }
        return false
    }

    private fun waitStep(s: JarvisAccessibilityService, granted: () -> Boolean, intent: Intent): Pair<State, String> {
        if (granted()) return State.OK to "already granted"
        s.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return when (waitUntil(granted)) {
            true -> {
                SystemClock.sleep(500L)
                State.OK to "allow ho gaya"
            }
            null -> State.SKIPPED to "skip kiya"
            false -> State.SKIPPED to "time khatam - baad mein Setup dobara dabao"
        }
    }

    private fun runtimeStep(s: JarvisAccessibilityService, ctx: Context): Pair<State, String> {
        if (PermissionCenter.runtimePermissionsReady(ctx)) return State.OK to "already granted"
        // The Activity owns the runtime-permission request; the system dialogs are answered by the user.
        s.startActivity(
            Intent(s, MainActivity::class.java)
                .putExtra(EXTRA_REQUEST_RUNTIME, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
        return when (waitUntil { PermissionCenter.runtimePermissionsReady(ctx) }) {
            true -> State.OK to "allow ho gaya"
            null -> State.SKIPPED to "skip kiya"
            false -> State.SKIPPED to "kuch permission baaki hain - health card mein dekho"
        }
    }

    /** Vivo's autostart page is a private OEM screen whose state cannot be read: open it and let the user decide. */
    private fun autostartStep(s: JarvisAccessibilityService): Pair<State, String> {
        val components = listOf(
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.PurviewTabActivity"
        )
        var opened = false
        for ((pkg, cls) in components) {
            opened = runCatching {
                s.startActivity(Intent().setClassName(pkg, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            }.getOrDefault(false)
            if (opened) break
        }
        if (!opened) return State.SKIPPED to "Vivo autostart page nahi khuli - Settings mein Jarvis ko Autostart do"
        // Cannot be detected, so wait for "Skip step" (= I allowed it) or a short timeout.
        val deadline = SystemClock.uptimeMillis() + 45_000L
        while (SystemClock.uptimeMillis() < deadline && !skipRequested) SystemClock.sleep(500L)
        return State.SKIPPED to "Autostart me Jarvis ON karo (check nahi ho sakta)"
    }
}
