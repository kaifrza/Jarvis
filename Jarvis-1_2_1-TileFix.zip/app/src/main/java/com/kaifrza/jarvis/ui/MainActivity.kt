package com.kaifrza.jarvis.ui

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.accessibility.PermissionAutopilot
import com.kaifrza.jarvis.accessibility.ReconTool
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.brain.BrainConfig
import com.kaifrza.jarvis.core.brain.BrainTaskRunner
import com.kaifrza.jarvis.core.health.HealthItem
import com.kaifrza.jarvis.core.health.HealthModel
import com.kaifrza.jarvis.core.health.JarvisHealth
import com.kaifrza.jarvis.core.health.Readiness
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.service.JarvisKeepAliveService
import com.kaifrza.jarvis.voice.JarvisSpeaker
import com.kaifrza.jarvis.voice.JarvisVoiceController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Native, WebView-free home screen: health, one-tap setup, the assistant panel and a few tools. */
class MainActivity : AppCompatActivity() {
    private val container get() = (application as JarvisApplication).container
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("jarvis_ui", Context.MODE_PRIVATE) }

    private lateinit var speaker: JarvisSpeaker
    private lateinit var voice: JarvisVoiceController
    private lateinit var panel: JarvisPanel
    private lateinit var heroOrb: OrbView
    private lateinit var readyLabel: TextView
    private lateinit var healthBox: LinearLayout
    private lateinit var autopilotBox: LinearLayout
    private lateinit var bubblePill: TextView
    private lateinit var keepAlivePill: TextView

    private var resumed = false
    private var lastSignature = ""

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    private val progress = BrainTaskRunner.ProgressListener { steps -> runOnUiThread { panel.showTasks(steps) } }

    private val poll = object : Runnable {
        override fun run() {
            if (!resumed) return
            refresh()
            handler.postDelayed(this, 1_000L)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speaker = JarvisSpeaker(this)
        buildUi()
        voice = JarvisVoiceController(this, object : JarvisVoiceController.Listener {
            override fun onReady() = panel.show("voice", "Bolo…", "LISTENING")
            override fun onListening() = panel.show("voice", "Sun raha hoon…", "LISTENING")
            override fun onPartial(text: String) = panel.show("voice", text, "LISTENING")
            override fun onResult(text: String) {
                panel.addUserMessage(text)
                process(text)
            }
            override fun onError(message: String) = panel.show("response", message, "FAILED")
        })
        container.brainTaskRunner.addProgressListener(progress)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(PermissionAutopilot.EXTRA_REQUEST_RUNTIME, false) == true) {
            i.removeExtra(PermissionAutopilot.EXTRA_REQUEST_RUNTIME)
            val missing = PermissionCenter.missingPermissions(this)
            if (missing.isNotEmpty()) permissionLauncher.launch(missing)
        }
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
        }

        // Header
        val header = card()
        val headerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heroOrb = OrbView(this)
        headerRow.addView(heroOrb, LinearLayout.LayoutParams(dp(56), dp(56)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(Ui.label(this, "Jarvis", 22f, Ui.TEXT, bold = true))
        readyLabel = Ui.label(this, "", 13f, Ui.MUTED, bold = true)
        titles.addView(readyLabel)
        headerRow.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        header.addView(headerRow)
        col.addView(header, cardParams())

        // Health + setup
        val health = card()
        health.addView(Ui.label(this, "Jarvis health", 15f, Ui.TEXT, bold = true))
        healthBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        health.addView(healthBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        autopilotBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        health.addView(autopilotBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Ui.pill(this, "Setup guide", true) { onSetupClicked() })
        actions.addView(
            Ui.pill(this, "Accessibility", false) { PermissionCenter.openAccessibilitySettings(this) },
            LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) }
        )
        health.addView(actions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
        col.addView(health, cardParams())

        // Assistant panel
        panel = JarvisPanel(this)
        panel.setMessagesHeightPx(dp(190))
        panel.attach(object : JarvisPanel.Listener {
            override fun onCommand(text: String) = process(text)
            override fun onMic() = startMic()
            override fun onApprove() = runAsync { container.brainTaskRunner.approve() }
            override fun onCancel() = runAsync { container.brainTaskRunner.cancel() }
            override fun onStop() {
                container.brainTaskRunner.requestAbort()
                panel.show("response", "Rok raha hoon…", "CANCELLED")
            }
            override fun onOpenSettings() = showBrainSettings()
        })
        col.addView(panel, cardParams())

        // Tools
        val tools = card()
        tools.addView(Ui.label(this, "Tools", 15f, Ui.TEXT, bold = true))
        val toolRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolRow.addView(Ui.pill(this, "Phone scan (Recon)", false) { onReconClicked() })
        bubblePill = Ui.pill(this, "", false) { toggleBubble() }
        keepAlivePill = Ui.pill(this, "", false) { toggleKeepAlive() }
        toolRow.addView(bubblePill, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        tools.addView(toolRow, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        tools.addView(keepAlivePill, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        col.addView(tools, cardParams())

        scroll.addView(col)
        setContentView(scroll)
        updateToggleLabels()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.rounded(Ui.SURFACE, dp(18))
        setPadding(dp(14), dp(12), dp(14), dp(14))
    }

    private fun cardParams() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }

    private fun healthRow(item: HealthItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }
        val color = if (item.ok) Ui.OK else if (item.required) Ui.DANGER else Ui.WARN
        val dot = View(this).apply { background = Ui.rounded(color, dp(6)) }
        row.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(10) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.label(this, item.title, 13f, Ui.TEXT))
        if (!item.ok) col.addView(Ui.label(this, item.hint, 11f, Ui.MUTED))
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (!item.ok) {
            // Tap a missing item to open exactly that permission page; the user allows it by hand.
            row.isClickable = true
            row.setOnClickListener { openPermissionPage(item.id) }
        }
        return row
    }

    private fun openPermissionPage(id: String) {
        when (id) {
            "accessibility" -> PermissionCenter.openAccessibilitySettings(this)
            "runtime" -> {
                val missing = PermissionCenter.missingPermissions(this)
                if (missing.isNotEmpty()) permissionLauncher.launch(missing)
            }
            "write_settings" -> startActivity(PermissionCenter.writeSettingsIntent(this))
            "dnd" -> startActivity(PermissionCenter.dndAccessIntent())
            "notifications" -> startActivity(PermissionCenter.notificationListenerIntent())
            "battery" -> startActivity(PermissionCenter.batteryExemptionIntent(this))
        }
    }

    private fun updateToggleLabels() {
        val bubbleOn = prefs.getBoolean("bubble_visible", true)
        bubblePill.text = if (bubbleOn) "Bubble: ON" else "Bubble: OFF"
        keepAlivePill.text = if (JarvisKeepAliveService.isEnabled(this)) "Background guard: ON" else "Background guard: OFF"
    }

    private fun toggleBubble() {
        prefs.edit().putBoolean("bubble_visible", !prefs.getBoolean("bubble_visible", true)).apply()
        JarvisAccessibilityService.instance?.applyBubbleSetting()
        updateToggleLabels()
    }

    private fun toggleKeepAlive() {
        JarvisKeepAliveService.setEnabled(this, !JarvisKeepAliveService.isEnabled(this))
        updateToggleLabels()
    }

    // ---------------------------------------------------------------- health + autopilot

    override fun onResume() {
        super.onResume()
        resumed = true
        lastSignature = ""
        refresh()
        handler.removeCallbacks(poll)
        handler.postDelayed(poll, 1_000L)
        if (ReconTool.finishedNotice) {
            ReconTool.finishedNotice = false
            showReconDone()
        }
        maybeIntro()
    }

    override fun onPause() {
        resumed = false
        handler.removeCallbacks(poll)
        super.onPause()
    }

    private fun refresh() {
        val items = JarvisHealth.snapshot(this)
        val steps = PermissionAutopilot.steps
        val signature = items.joinToString("") { if (it.ok) "1" else "0" } +
            steps.joinToString("|") { it.id + it.state.name } + PermissionAutopilot.running
        if (signature != lastSignature) {
            lastSignature = signature
            val readiness = HealthModel.readiness(items)
            readyLabel.text = HealthModel.label(readiness)
            readyLabel.setTextColor(
                when (readiness) {
                    Readiness.READY -> Ui.OK
                    Readiness.DEGRADED -> Ui.WARN
                    Readiness.NEEDS_SETUP -> Ui.DANGER
                }
            )
            healthBox.removeAllViews()
            items.forEach { healthBox.addView(healthRow(it)) }
            autopilotBox.removeAllViews()
            autopilotBox.visibility = if (steps.isEmpty()) View.GONE else View.VISIBLE
            if (PermissionAutopilot.running) {
                autopilotBox.addView(Ui.pill(this, "Skip step", false) { PermissionAutopilot.skipCurrent() },
                    LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(6) })
            }
            steps.forEach { step ->
                val (tag, color) = when (step.state) {
                    PermissionAutopilot.State.OK -> "[ok]" to Ui.OK
                    PermissionAutopilot.State.RUNNING -> "[..]" to Ui.ACCENT
                    PermissionAutopilot.State.FAILED -> "[x]" to Ui.DANGER
                    PermissionAutopilot.State.SKIPPED -> "[-]" to Ui.WARN
                    PermissionAutopilot.State.PENDING -> "[ ]" to Ui.MUTED
                }
                val note = if (step.note.isBlank()) "" else " - ${step.note}"
                autopilotBox.addView(Ui.label(this, "$tag ${step.title}$note", 11f, color))
            }
            heroOrb.orbState = if (PermissionAutopilot.running) OrbState.ACTING else OrbState.IDLE
        }
        maybeAutoStartAutopilot()
    }

    /** Runs the permission autopilot once, right after the user switches Accessibility ON. */
    private fun maybeAutoStartAutopilot() {
        val service = JarvisAccessibilityService.instance ?: return
        if (prefs.getBoolean("autopilot_ran", false)) return
        prefs.edit().putBoolean("autopilot_ran", true).apply()
        PermissionAutopilot.start(service)
    }

    private fun onSetupClicked() {
        val service = JarvisAccessibilityService.instance
        if (service == null) {
            toast("Pehle Accessibility ON karo, baaki pages Jarvis kholta jayega")
            PermissionCenter.openAccessibilitySettings(this)
            return
        }
        if (!PermissionAutopilot.start(service)) toast("Setup guide pehle se chal raha hai")
    }

    private fun maybeIntro() {
        if (PermissionCenter.isAccessibilityEnabled(this) || prefs.getBoolean("intro_shown", false)) return
        prefs.edit().putBoolean("intro_shown", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Pehla step")
            .setMessage("Jarvis ko Accessibility service ON chahiye. Uske baad Jarvis ek-ek permission ka page kholega aur aap khud Allow karoge. Jarvis kabhi koi permission khud allow ya band nahi karta.")
            .setPositiveButton("Settings kholo") { _, _ -> PermissionCenter.openAccessibilitySettings(this) }
            .setNegativeButton("Baad mein", null)
            .show()
    }

    // ---------------------------------------------------------------- recon

    private fun onReconClicked() {
        val service = JarvisAccessibilityService.instance
        if (service == null) {
            toast("Pehle Accessibility ON karo")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Phone scan (Recon)")
            .setMessage("Jarvis ~30 second mein khud notification panel, Bluetooth, Wi-Fi aur Sound settings kholke unke naam padhega. Is dauran screen ko haath mat lagana. Report mein device/Wi-Fi ke naam ho sakte hain, share karne se pehle dekh lena.")
            .setPositiveButton("Shuru karo") { _, _ ->
                if (ReconTool.start(service) { }) {
                    moveTaskToBack(true)
                } else toast("Recon pehle se chal raha hai")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showReconDone() {
        val report = ReconTool.lastReport ?: return
        val path = ReconTool.lastPath
        AlertDialog.Builder(this)
            .setTitle("Recon ho gaya")
            .setMessage("Report ${report.length} characters ki hai." + (path?.let { "\nFile: $it" } ?: "") + "\n\nShare ya Copy karke yahan chat mein bhej do.")
            .setPositiveButton("Share") { _, _ ->
                startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report),
                        "Recon report"
                    )
                )
            }
            .setNeutralButton("Copy") { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Jarvis recon", report))
                toast("Copy ho gaya")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------------------------------------------------------------- running commands

    private fun process(raw: String) {
        if (raw.isBlank()) return
        panel.show("thinking", "", "THINKING")
        lifecycleScope.launch(Dispatchers.IO) {
            val context = "foreground=${JarvisAccessibilityService.instance?.foregroundPackage ?: "unknown"}"
            val result = runCatching { container.brainTaskRunner.handle(raw, context) }
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown error"}") }
            withContext(Dispatchers.Main) { deliver(result) }
        }
    }

    private fun runAsync(block: () -> CommandResponse) {
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching(block)
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown error"}") }
            withContext(Dispatchers.Main) { deliver(result) }
        }
    }

    private fun deliver(result: CommandResponse) {
        panel.show("response", result.message, result.state.name)
        heroOrb.orbState = PanelModel.orbFor("response", result.state.name)
        if (result.state == CommandState.SUCCESS) speaker.speak(result.message)
    }

    private fun startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) voice.start()
        else permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
    }

    // ---------------------------------------------------------------- brain settings

    private fun showBrainSettings() {
        val cfg = container.brainStore.read()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val endpoint = EditText(this).apply { hint = "OpenAI-compatible endpoint"; setText(cfg.endpoint) }
        val model = EditText(this).apply { hint = "Model"; setText(cfg.model) }
        val key = EditText(this).apply { hint = "API key"; setText(cfg.apiKey); inputType = 0x00000081 }
        val enabled = Switch(this).apply { text = "Enable remote brain"; isChecked = cfg.enabled }
        box.addView(endpoint); box.addView(model); box.addView(key); box.addView(enabled)
        AlertDialog.Builder(this)
            .setTitle("Jarvis Brain")
            .setMessage("Optional cloud brain (OpenAI-compatible endpoint). The API key is stored with Android Keystore encryption. Plans from the cloud brain always ask before calls, SMS or Send/Pay clicks.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                container.brainStore.save(BrainConfig(enabled.isChecked, endpoint.text.toString(), model.text.toString(), key.text.toString()))
            }.show()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        container.brainTaskRunner.removeProgressListener(progress)
        voice.destroy()
        speaker.shutdown()
        super.onDestroy()
    }
}
