package com.kaifrza.jarvis.accessibility

import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Drives the notification panel's Quick Settings tiles on the Vivo Y1s (verified with the Recon report):
 *  - the panel opens COLLAPSED with 6 tiles (Data network, Wi-Fi, Speed up, Bluetooth, Flashlight, Airplane mode);
 *  - one pull-down expands it to a 12-tile page with a "Page N of 3" indicator;
 *  - Accessibility scroll actions on the pager report success without moving, so pages are changed with a
 *    real finger swipe on the pager and verified through the indicator;
 *  - each tile is a Switch whose checked flag is the On/Off the user sees.
 */
object QuickSettingsNavigator {
    fun open(s: JarvisAccessibilityService): Boolean {
        s.awaitIdleFocus()
        if (!s.performGlobalActionQuickSettings()) return false
        SystemClock.sleep(650L)
        return true
    }

    /** Pull the collapsed panel down to its full tile grid. Harmless if it is already expanded. */
    fun expand(s: JarvisAccessibilityService) {
        if (s.pageIndicator() != null) return
        val d = s.resources.displayMetrics
        for (startY in listOf(0.05f, 0.12f)) {
            s.swipeBy(d.widthPixels / 2f, d.heightPixels * startY, d.widthPixels / 2f, d.heightPixels * 0.62f, 420L)
            SystemClock.sleep(600L)
            if (s.pageIndicator() != null) return
        }
    }

    private fun swipePager(s: JarvisAccessibilityService, forward: Boolean): Boolean {
        val d = s.resources.displayMetrics
        val r = s.pagerBounds()
        val left = r?.left?.toFloat() ?: 0f
        val width = r?.width()?.toFloat() ?: d.widthPixels.toFloat()
        val y = r?.exactCenterY() ?: (d.heightPixels * 0.33f)
        val from = left + width * (if (forward) 0.88f else 0.12f)
        val to = left + width * (if (forward) 0.12f else 0.88f)
        return s.swipeBy(from, y, to, y, 300L)
    }

    /** Moves one page. Returns true only when the "Page N of M" indicator really changed. */
    fun page(s: JarvisAccessibilityService, forward: Boolean): Boolean {
        val before = s.pageIndicator()
        swipePager(s, forward)
        SystemClock.sleep(650L)
        if (changed(before, s.pageIndicator())) return true
        if (s.scrollPager(forward)) {
            SystemClock.sleep(550L)
            if (changed(before, s.pageIndicator())) return true
        }
        return false
    }

    private fun changed(before: Pair<Int, Int>?, after: Pair<Int, Int>?): Boolean =
        before != null && after != null && before.first != after.first

    fun ensureFirstPage(s: JarvisAccessibilityService) {
        val total = s.pageIndicator()?.second ?: return
        repeat(total) {
            if ((s.pageIndicator()?.first ?: 1) > 1) page(s, false)
        }
    }

    /** Looks for the tile on the current page, then on the following pages. */
    fun findTile(s: JarvisAccessibilityService, labels: List<String>): AccessibilityNodeInfo? {
        s.findTileNode(labels)?.let { return it }
        val total = s.pageIndicator()?.second ?: return null
        for (i in 1 until total) {
            if (!page(s, true)) break
            s.findTileNode(labels)?.let { return it }
        }
        ensureFirstPage(s)
        return null
    }

    /**
     * Toggles a tile. Returns null on success or a short Hinglish error message.
     * desired = true/false when the user said on/off, null for a plain toggle.
     * The tile's own checked flag is the primary state; readState (official API) is the fallback.
     */
    fun toggleTile(
        s: JarvisAccessibilityService,
        labels: List<String>,
        desired: Boolean?,
        readState: (() -> Boolean?)?
    ): String? {
        if (!open(s)) return "Notification panel nahi khul paya."
        try {
            var node: AccessibilityNodeInfo? = s.findTileNode(labels)
            if (node == null) {
                expand(s)
                ensureFirstPage(s)
                node = findTile(s, labels)
            }
            val tile = node ?: return "Tile nahi mila (${labels.first()}). Panel ke pages mein check karo."
            fun state(): Boolean? = s.findTileNode(labels)?.let { s.readTileState(it) } ?: readState?.invoke()

            val before = s.readTileState(tile) ?: readState?.invoke()
            if (desired != null && before != null && before == desired) return null
            if (!s.clickNodeSafely(tile)) return "Tile dab nahi paya (${labels.first()})."
            SystemClock.sleep(700L)

            val deadline = SystemClock.uptimeMillis() + 3_000L
            while (SystemClock.uptimeMillis() < deadline) {
                val now = state()
                if (now == null) return null            // tile has no readable state: a single tap was the best we can do
                if (desired != null && now == desired) return null
                if (desired == null && before != null && now != before) return null
                SystemClock.sleep(150L)
            }
            return "Tile dabaya, par ${labels.first()} ki state badli nahi."
        } finally {
            s.closeQuickSettings()
        }
    }
}
