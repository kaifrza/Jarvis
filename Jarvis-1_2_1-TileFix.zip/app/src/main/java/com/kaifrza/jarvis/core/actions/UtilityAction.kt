package com.kaifrza.jarvis.core.actions

import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.accessibility.QuickSettingsNavigator
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import kotlin.math.roundToInt

/**
 * Phone controls. Rule: official Android API first (fast, verifiable, survives OEM UI changes);
 * Quick Settings tile tapping only where Android blocks the API for normal apps.
 */
class UtilityAction(private val context: Context) : JarvisAction {
    override val id = "android.utility"

    private val audio get() = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val tileIntents = setOf(
        IntentType.TOGGLE_WIFI, IntentType.TOGGLE_MOBILE_DATA, IntentType.TOGGLE_AIRPLANE,
        IntentType.TOGGLE_LOCATION, IntentType.TOGGLE_HOTSPOT, IntentType.TOGGLE_QS_TILE
    )

    override fun validate(plan: ActionPlan): ActionResult {
        val intent = plan.command.intent
        val p = plan.command.parameters
        return when {
            intent == IntentType.CALCULATE ->
                if (p["expression"].isNullOrBlank()) ActionResult.Failure("Mujhe calculation expression nahi mila.") else ActionResult.Success
            intent == IntentType.CREATE_ALARM ->
                if (p["hour"].isNullOrBlank()) ActionResult.Failure("Alarm ke liye time batao, e.g. 7:30 AM.") else ActionResult.Success
            intent == IntentType.SET_RINGER_MODE ->
                if (p["mode"].isNullOrBlank()) ActionResult.Failure("normal, vibrate ya silent batao.") else ActionResult.Success
            intent == IntentType.TOGGLE_QS_TILE ->
                if (p["tile"].isNullOrBlank()) ActionResult.Failure("Kaunsa tile dabana hai?")
                else if (JarvisAccessibilityService.instance == null) ActionResult.Failure("Accessibility Service is required for tile control.")
                else ActionResult.Success
            intent in tileIntents ->
                if (JarvisAccessibilityService.instance == null) ActionResult.Failure("Accessibility Service is required for this toggle.") else ActionResult.Success
            else -> ActionResult.Success
        }
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val p = plan.command.parameters
        val enabled = p["enabled"] != "false"
        return when (plan.command.intent) {
            IntentType.OPEN_NETWORK_SETTINGS -> open(Settings.ACTION_WIRELESS_SETTINGS)
            IntentType.OPEN_WIFI_SETTINGS -> open(Settings.ACTION_WIFI_SETTINGS)
            IntentType.OPEN_BLUETOOTH_SETTINGS -> open(Settings.ACTION_BLUETOOTH_SETTINGS)
            IntentType.SET_FLASHLIGHT -> setTorch(enabled)
            IntentType.SET_VOLUME -> setVolume(p)
            IntentType.SET_BRIGHTNESS -> setBrightness(p)
            IntentType.SET_AUTO_BRIGHTNESS -> setAutoBrightness(enabled)
            IntentType.SET_ROTATION_LOCK -> setRotationLock(p["locked"] == "true")
            IntentType.SET_RINGER_MODE -> setRingerMode(p["mode"].orEmpty())
            IntentType.SET_DND -> setDnd(enabled, p["level"])
            IntentType.PLAY_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_PLAY)
            IntentType.PAUSE_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_PAUSE)
            IntentType.STOP_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_STOP)
            IntentType.NEXT_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_NEXT)
            IntentType.PREVIOUS_MEDIA -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            IntentType.CREATE_ALARM -> createAlarm(plan)
            IntentType.TOGGLE_BLUETOOTH -> toggleBluetooth(enabled)
            IntentType.TOGGLE_WIFI -> tile(listOf("Wi-Fi", "WiFi", "WLAN"), enabled) { runCatching { wifi()?.isWifiEnabled }.getOrNull() }
            IntentType.TOGGLE_MOBILE_DATA -> tile(listOf("Data network", "Mobile data", "Cellular data"), enabled) { mobileDataState() }
            IntentType.TOGGLE_AIRPLANE -> tile(listOf("Airplane mode", "Flight mode"), enabled) { airplaneState() }
            IntentType.TOGGLE_LOCATION -> tile(listOf("Location", "GPS"), enabled) { locationState() }
            IntentType.TOGGLE_HOTSPOT -> tile(listOf("Personal hotspot", "Hotspot", "Mobile hotspot"), enabled) { hotspotState() }
            IntentType.TOGGLE_QS_TILE -> genericTile(p["tile"].orEmpty(), if (p.containsKey("enabled")) enabled else null)
            IntentType.CALCULATE -> {
                val expression = p["expression"].orEmpty()
                val result = SimpleCalculator.evaluate(expression)
                if (result == null) ActionResult.Failure("Main calculation ko samajh nahi paaya: $expression") else ActionResult.SuccessWithMessage("$expression = $result")
            }
            else -> ActionResult.Failure("Unsupported utility action.")
        }
    }

    override fun verify(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.TOGGLE_WIFI -> verifyState(plan.command.parameters["enabled"] != "false", "Wi-Fi") { runCatching { wifi()?.isWifiEnabled }.getOrNull() }
        IntentType.TOGGLE_BLUETOOTH -> verifyState(plan.command.parameters["enabled"] != "false", "Bluetooth") { runCatching { BluetoothAdapter.getDefaultAdapter()?.isEnabled }.getOrNull() }
        else -> ActionResult.Success
    }

    // ---------------------------------------------------------------- state readers (official APIs)

    private fun wifi() = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private fun airplaneState(): Boolean? = runCatching {
        Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    }.getOrNull()

    private fun locationState(): Boolean? = runCatching {
        (context.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
    }.getOrNull()

    private fun mobileDataState(): Boolean? = runCatching {
        val v = Settings.Global.getInt(context.contentResolver, "mobile_data", -1)
        if (v == -1) null else v == 1
    }.getOrNull()

    /** Hidden API, read through reflection (allowed on Android 10); null when unavailable. */
    private fun hotspotState(): Boolean? = runCatching {
        val m = WifiManager::class.java.getMethod("isWifiApEnabled")
        m.invoke(wifi()) as? Boolean
    }.getOrNull()

    private fun verifyState(enabled: Boolean, name: String, read: () -> Boolean?): ActionResult {
        if (read() == null) return ActionResult.Success
        val deadline = SystemClock.uptimeMillis() + 2_500L
        while (SystemClock.uptimeMillis() < deadline) {
            if (read() == enabled) return ActionResult.Success
            SystemClock.sleep(120)
        }
        return ActionResult.Failure("$name state could not be verified.")
    }

    // ---------------------------------------------------------------- volume

    private fun streamOf(name: String?): Pair<Int, String> = when (name) {
        "ring" -> AudioManager.STREAM_RING to "Ringtone"
        "alarm" -> AudioManager.STREAM_ALARM to "Alarm"
        "notification" -> AudioManager.STREAM_NOTIFICATION to "Notification"
        "call" -> AudioManager.STREAM_VOICE_CALL to "Call"
        "system" -> AudioManager.STREAM_SYSTEM to "System"
        else -> AudioManager.STREAM_MUSIC to "Media"
    }

    /**
     * mode = set (absolute level), up/down (relative by delta), min, unmute, get (just report).
     * A bare "level" without a mode means "set".
     */
    private fun resolveLevel(p: Map<String, String>, current: Int, minLevel: Int, remembered: Int?): Int? {
        val level = p["level"]?.toIntOrNull()
        val mode = p["mode"] ?: if (level != null) "set" else "get"
        val delta = p["delta"]?.toIntOrNull() ?: 20
        return when (mode) {
            "set" -> level?.coerceIn(minLevel, 100)
            "up" -> (current + delta).coerceIn(minLevel, 100)
            "down" -> (current - delta).coerceIn(minLevel, 100)
            "min" -> minLevel
            "unmute" -> (remembered ?: 50).coerceIn(minLevel.coerceAtLeast(1), 100)
            else -> null
        }
    }

    private fun setVolume(p: Map<String, String>): ActionResult {
        val (stream, label) = streamOf(p["stream"])
        return try {
            val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
            val minRaw = audio.getStreamMinVolume(stream)
            val currentRaw = audio.getStreamVolume(stream)
            val currentPercent = (currentRaw * 100f / max).roundToInt()
            val memory = context.getSharedPreferences("jarvis_volume", Context.MODE_PRIVATE)
            val remembered = memory.getInt("stream_$stream", -1).takeIf { it > 0 }
            val target = resolveLevel(p, currentPercent, 0, remembered)
                ?: return ActionResult.SuccessWithMessage("$label volume abhi $currentPercent% hai.")
            var value = (max * target / 100f).roundToInt().coerceIn(minRaw, max)
            if (p["mode"] == "up" && value <= currentRaw && currentRaw < max) value = currentRaw + 1
            if (p["mode"] == "down" && value >= currentRaw && currentRaw > minRaw) value = currentRaw - 1
            // Remember the level before muting so "unmute" can restore it.
            if (value <= minRaw && currentRaw > minRaw) memory.edit().putInt("stream_$stream", (currentRaw * 100f / max).roundToInt()).apply()
            audio.setStreamVolume(stream, value, AudioManager.FLAG_SHOW_UI)
            ActionResult.SuccessWithMessage("$label volume ${(audio.getStreamVolume(stream) * 100f / max).roundToInt()}% kar diya.")
        } catch (e: SecurityException) {
            ActionResult.Failure("$label volume ke liye Do Not Disturb access chahiye. Jarvis app mein 'Setup poora karo' dabao.")
        } catch (e: Exception) {
            ActionResult.Failure("$label volume control fail hua: ${e.message ?: "unknown"}")
        }
    }

    // ---------------------------------------------------------------- ringer / DND

    private fun setRingerMode(mode: String): ActionResult {
        val (target, label) = when (mode) {
            "silent" -> AudioManager.RINGER_MODE_SILENT to "silent"
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE to "vibrate"
            else -> AudioManager.RINGER_MODE_NORMAL to "normal"
        }
        return try {
            audio.ringerMode = target
            if (audio.ringerMode == target) ActionResult.SuccessWithMessage("Phone ab $label mode mein hai.")
            else ActionResult.Failure("Android ne $label mode accept nahi kiya.")
        } catch (e: SecurityException) {
            ActionResult.Failure("Silent/vibrate ke liye Do Not Disturb access chahiye. Jarvis app mein 'Setup poora karo' dabao.")
        }
    }

    private fun setDnd(enabled: Boolean, level: String?): ActionResult {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            return ActionResult.Failure("Do Not Disturb access chahiye. Jarvis app mein 'Setup poora karo' dabao.")
        }
        val filter = when {
            !enabled -> NotificationManager.INTERRUPTION_FILTER_ALL
            level == "alarms" -> NotificationManager.INTERRUPTION_FILTER_ALARMS
            level == "total" -> NotificationManager.INTERRUPTION_FILTER_NONE
            else -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
        }
        nm.setInterruptionFilter(filter)
        return ActionResult.SuccessWithMessage(if (enabled) "Do Not Disturb on kar diya." else "Do Not Disturb band kar diya.")
    }

    // ---------------------------------------------------------------- brightness / rotation (WRITE_SETTINGS)

    /** "Modify system settings" is granted by the user by hand: Jarvis only opens the page. */
    private fun ensureWriteSettings(): ActionResult.Failure? {
        if (Settings.System.canWrite(context)) return null
        runCatching {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        return ActionResult.Failure("Settings page khol di hai. 'Allow modify system settings' ON karo, phir command dobara bolo.")
    }

    private fun setBrightness(p: Map<String, String>): ActionResult {
        ensureWriteSettings()?.let { return it }
        return runCatching {
            val cr = context.contentResolver
            val current255 = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
            val current = (current255 * 100f / 255f).roundToInt()
            val target = resolveLevel(p, current, 1, null)
                ?: return ActionResult.SuccessWithMessage("Brightness abhi $current% hai.")
            // Manual mode first, otherwise adaptive brightness overrides the value immediately.
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (255 * target / 100f).roundToInt().coerceIn(1, 255))
            ActionResult.SuccessWithMessage("Brightness $target% kar di.")
        }.getOrElse { ActionResult.Failure("Brightness control fail hua: ${it.message ?: "unknown"}") }
    }

    private fun setAutoBrightness(enabled: Boolean): ActionResult {
        ensureWriteSettings()?.let { return it }
        return runCatching {
            Settings.System.putInt(
                context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (enabled) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            ActionResult.SuccessWithMessage(if (enabled) "Auto brightness on kar di." else "Auto brightness band kar di.")
        }.getOrElse { ActionResult.Failure("Auto brightness fail hua: ${it.message ?: "unknown"}") }
    }

    /** locked = true means the "Portrait orientation lock" tile is ON (auto-rotate OFF). */
    private fun setRotationLock(locked: Boolean): ActionResult {
        ensureWriteSettings()?.let { return it }
        return runCatching {
            Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 0 else 1)
            ActionResult.SuccessWithMessage(if (locked) "Rotation lock on kar diya." else "Auto-rotate on kar diya.")
        }.getOrElse { ActionResult.Failure("Rotation control fail hua: ${it.message ?: "unknown"}") }
    }

    // ---------------------------------------------------------------- media / alarm / misc

    private fun media(keyCode: Int): ActionResult = runCatching {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Media control fail hua: ${it.message ?: "unknown"}") }

    private fun createAlarm(plan: ActionPlan): ActionResult {
        val p = plan.command.parameters
        var hour = p["hour"]?.toIntOrNull() ?: return ActionResult.Failure("Alarm ke liye time batao, e.g. 7:30 AM.")
        val minute = (p["minute"]?.toIntOrNull() ?: 0).coerceIn(0, 59)
        val ampm = p["ampm"].orEmpty().lowercase()
        if (ampm == "pm" && hour < 12) hour += 12
        if (ampm == "am" && hour == 12) hour = 0
        hour = hour.coerceIn(0, 23)
        val label = String.format("%02d:%02d", hour, minute)

        fun alarmIntent(skipUi: Boolean) = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, skipUi)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(alarmIntent(true))
            ActionResult.SuccessWithMessage("Alarm $label ke liye set kar diya.")
        } catch (e1: Exception) {
            try {
                context.startActivity(alarmIntent(false))
                ActionResult.SuccessWithMessage("Alarm $label ka setup khol diya.")
            } catch (e2: Exception) {
                ActionResult.Failure("Alarm app open nahi ho saki.")
            }
        }
    }

    private fun open(action: String): ActionResult = runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Settings open nahi ho sakin.") }

    private fun setTorch(enabled: Boolean): ActionResult = runCatching {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return ActionResult.Failure("Torch camera nahi mila.")
        manager.setTorchMode(cameraId, enabled)
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Torch control fail hua: ${it.message ?: "unknown"}") }

    // ---------------------------------------------------------------- Bluetooth + tiles

    @Suppress("DEPRECATION")
    private fun toggleBluetooth(enabled: Boolean): ActionResult {
        val adapter = runCatching { BluetoothAdapter.getDefaultAdapter() }.getOrNull()
        val read: () -> Boolean? = { runCatching { adapter?.isEnabled }.getOrNull() }
        if (read() == enabled) return ActionResult.Success
        // Official API: works on Android 10 for apps holding BLUETOOTH_ADMIN; returns false on newer versions.
        val api = runCatching { if (enabled) adapter?.enable() else adapter?.disable() }.getOrNull()
        if (api == true) return ActionResult.Success
        return tile(listOf("Bluetooth"), enabled, read)
    }

    private fun tile(labels: List<String>, enabled: Boolean?, readState: (() -> Boolean?)?): ActionResult {
        val service = JarvisAccessibilityService.instance ?: return ActionResult.Failure("Accessibility Service is unavailable.")
        val error = QuickSettingsNavigator.toggleTile(service, labels, enabled, readState)
        return if (error == null) ActionResult.Success else ActionResult.Failure(error)
    }

    private val genericTiles = mapOf(
        "eye protection" to listOf("Eye Protection"),
        "dark mode" to listOf("Dark mode"),
        "low power mode" to listOf("Low power mode"),
        "super battery saver" to listOf("Super Battery Saver"),
        "bedtime mode" to listOf("Bedtime mode"),
        "screen recording" to listOf("Screen recording"),
        "quick share" to listOf("Quick Share"),
        "speed up" to listOf("Speed up")
    )

    private fun genericTile(name: String, enabled: Boolean?): ActionResult {
        val labels = genericTiles[name.lowercase()] ?: listOf(name)
        // These tiles have no official state API, so without a readable state this is a single plain tap.
        return tile(labels, enabled, null)
    }
}

internal object SimpleCalculator {
    fun evaluate(raw: String): String? {
        val s = raw.replace(" ", "")
        val m = Regex("^(-?\\d+(?:\\.\\d+)?)([+\\-*/])(-?\\d+(?:\\.\\d+)?)$").matchEntire(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val v = when (m.groupValues[2]) { "+" -> a + b; "-" -> a - b; "*" -> a * b; "/" -> if (b == 0.0) return null else a / b; else -> return null }
        return if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
    }
}
