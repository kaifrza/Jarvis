# Jarvis Android Assistant — 1.2.1

## 1.2.1
- **Permissions are granted by the user, never by Jarvis.** The "Setup guide" only opens each permission page
  or dialog (one after another) and waits until the user has allowed it by hand; "Skip step" or a timeout
  moves on. Jarvis never taps Allow / switches and never turns a permission off. Missing health items are
  tappable and open exactly that page. Brightness/rotation no longer auto-tap the "Modify system settings"
  switch, they just open the page.
- **Quick Settings (calibrated from the real Recon report of this Vivo Y1s):** tiles are `Switch` nodes whose
  checked flag is the On/Off the user sees; descriptions carry a trailing comma ("Wi-Fi,"); the panel opens
  collapsed with 6 tiles; the pager must be changed with a real swipe (accessibility scroll reports success
  without moving) and is verified with the "Page N of 3" indicator.
- Recon report is compact (target window only, no status-bar noise, repeated pages collapsed).

# 1.2.0 (Phase 2: API controls + panel tiles)

## 1.2.0
- **Controls by official API first:** volume for every stream (media by default; ring, alarm, notification,
  call, system when named; mute remembers the level so unmute restores it), silent / vibrate / normal,
  Do Not Disturb, auto-brightness, rotation lock, brightness, torch, Bluetooth (API, tile as fallback).
- **Quick Settings tiles through UI tap** (only where Android blocks the API): Wi-Fi, Data network,
  Airplane, Location, Personal hotspot, Eye Protection, Dark mode, Low power, Super Battery Saver,
  Bedtime. The navigator opens the panel, expands it (it opens collapsed on Vivo), finds the tile on
  any of its pages, reads the real state through the official API, taps only if needed, verifies, and
  closes the panel.
- **Understanding:** Hinglish spelling variants and Devanagari voice typing are normalised before parsing.
- **Fixes:** Back/scroll act on the real app window, SMS result wording, "which step failed" messages,
  instant "Jarvis is OFF" alert (works every time), search typing + keyboard Search key.
- **Overlay:** panel has an X button and can be dragged; the bubble rests 1.5 s at the edge then slides
  half-way into it.

# 1.1.0 (Phase 1: foundation)

## 1.1.0 — what is new
- **Native UI, no WebView.** App screen, cross-app overlay and the system-assistant session all use one
  light native panel (`JarvisPanel`). The bubble is a Canvas orb that is static when idle and only
  animates while Jarvis listens / thinks / acts. Nothing heavy, tuned for a 2 GB phone.
- **Permission autopilot.** The user only switches Accessibility ON. Jarvis then opens the remaining
  permission pages (system settings, notification access, Do Not Disturb access, battery exemption,
  Vivo autostart) and taps the switch / "Allow" itself. It never turns a permission off.
- **Health + watchdog.** Live "Jarvis health" card, and a tiny foreground service that re-checks every
  20 s that Accessibility is still ON; if Vivo or the system switched it off it posts a one-tap alert.
- **Recon.** "Phone scan" reads the notification panel (3 pages), Bluetooth, Wi-Fi and Sound settings and
  writes a report (`jarvis-recon.txt`, share/copy) so Jarvis can be calibrated to the real phone.
- STOP button that really stops a running multi-step command; several screens can watch progress at once.

# Earlier: 1.0.1

Personal-use Android assistant for Android 10+ (UI-tap based control, offline-first).

## 1.0.1 — audit fixes
1. Dictated message bodies are no longer split on "aur / and / phir / then"; chained commands only
   run when every part is understood.
2. Tiered approval policy: user commands run directly; steps from a *remote model* need approval for
   calls, SMS and sensitive clicks.
3. `dialer kholo`, `call log kholo`, `caller id` no longer place calls.
4. Relative volume/brightness (`badhao`, `kam karo`, `thoda`, `mute`, `full`) instead of always 50%.
5. UI-clause parser is anchored (ordinary sentences are not hijacked into click/type/search).
6. Task lanes run sequentially (no more step interleaving across apps); failed lanes skip only themselves.
7. Manifest: `ACCESS_WIFI_STATE`, `ACCESS_NETWORK_STATE`, `BLUETOOTH` (<=API 30); state reads are
   exception-safe; Quick Settings is closed after toggling and expanded by swipe if tiles are hidden.
8. Brightness switches to manual mode, uses 1-255, and the "Modify system settings" page is opened and
   tapped through Accessibility.
9. Alarm: `SET_ALARM` permission, `SKIP_UI` with fallback, morning/evening handling.
10. History no longer stores raw text, typed text or message bodies.

Also: `KeyEvent` media constants (build fix), explicit coroutines + `org.json` test dependency,
APK build no longer blocked by unit tests, approve/cancel off the main thread, plain-text/reply-only
cloud answers are shown, app list cached, voice language tag + extra error codes, repo cleanup.

## Brain setup (optional)
Open Jarvis settings and configure an OpenAI-compatible endpoint, model and API key (stored with
Android Keystore). Without it Jarvis uses the local command engine.

## Example commands
`YouTube kholo`, `Zubair ko call karo`, `volume badhao`, `brightness 30`, `Wi-Fi band karo`,
`alarm shaam 6 baje`, `Zubair ko message bhejo: main aur tum kal milenge`,
`Chrome kholo aur Google par cricket search karo`.

## Platform limits
Android 10 gives no unlimited background control; mobile-data/hotspot toggling is OEM dependent;
banking apps may block Accessibility; no on-device LLM is bundled.

## CI
The workflow picks the latest committed zip, runs preflight, builds the debug APK, uploads it, and
then runs unit tests (a failing test is visible but never hides the APK).
