package com.kaifrza.jarvis.core.assistant

import com.kaifrza.jarvis.core.actions.ActionExecutor
import com.kaifrza.jarvis.core.actions.ActionResult
import com.kaifrza.jarvis.core.intent.CommandUnderstandingEngine
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.security.RiskEngine

data class CommandResponse(
    val state: CommandState,
    val message: String,
    val approvalToken: String? = null,
    val commandId: String? = null
)

class CommandProcessor(
    private val parser: CommandUnderstandingEngine,
    private val riskEngine: RiskEngine,
    private val executor: ActionExecutor,
    private val history: ActionHistory
) {
    private var pending: ActionExecutor.PreparedAction? = null

    fun handle(rawText: String): CommandResponse {
        val cleaned = rawText.trim()
        if (cleaned.isEmpty()) return CommandResponse(CommandState.FAILED, "Command khaali hai, sir.")

        if (pending != null) {
            val approval = interpretApproval(cleaned)
            if (approval == true) return approve()
            if (approval == false) return cancel()
        }

        val command = parser.understand(cleaned)
        val plan = riskEngine.plan(command)

        if (command.intent == IntentType.UNKNOWN) {
            val message = unknownMessage(cleaned)
            val result = CommandResponse(CommandState.FAILED, message, commandId = command.id)
            history.record(command, result)
            return result
        }

        val prepared = executor.prepare(plan)

        if (plan.requiresConfirmation) {
            pending = prepared
            return CommandResponse(
                CommandState.WAITING_FOR_APPROVAL,
                confirmationMessage(plan),
                prepared.approvalToken,
                command.id
            )
        }

        val result = executePrepared(prepared)
        history.record(command, result)
        return result
    }

    fun approve(): CommandResponse {
        val prepared = pending
            ?: return CommandResponse(CommandState.FAILED, "Koi pending action nahi hai, sir.")

        val result = executePrepared(prepared, prepared.approvalToken)
        pending = null
        history.record(prepared.plan.command, result)
        return result
    }

    fun cancel(): CommandResponse {
        val command = pending?.plan?.command
        pending?.approvalToken?.let(executor::revoke)
        pending = null

        val result = CommandResponse(CommandState.CANCELLED, "Theek hai sir, cancel kar diya.", commandId = command?.id)
        if (command != null) history.record(command, result)
        return result
    }

    fun hasPendingApproval(): Boolean = pending != null

    private fun interpretApproval(text: String): Boolean? {
        val n = text.lowercase()
            .replace(Regex("[.!?,]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val yes = setOf(
            "yes", "haan", "ha", "han", "ok", "okay", "theek", "theek hai",
            "kar do", "bhej do", "send kar do", "call kar do", "confirm", "confirmed"
        )
        val no = setOf(
            "no", "nahi", "nahin", "cancel", "cancel karo", "rehne do", "chhodo",
            "mat karo", "mat bhejo", "don't", "dont", "stop"
        )

        return when {
            n in yes || n.startsWith("haan ") || n.startsWith("ha ") ||
                n.startsWith("yes ") || n.startsWith("okay ") || n.startsWith("ok ") -> true
            n in no || n.startsWith("nahi ") || n.startsWith("nahin ") ||
                n.startsWith("cancel ") || n.startsWith("mat ") -> false
            else -> null
        }
    }

    private fun executePrepared(
        prepared: ActionExecutor.PreparedAction,
        approvalToken: String? = null
    ): CommandResponse {
        return when (val result = executor.execute(prepared, approvalToken)) {
            ActionResult.Success ->
                CommandResponse(CommandState.SUCCESS, successMessage(prepared.plan.command))
            is ActionResult.Failure ->
                CommandResponse(CommandState.FAILED, result.reason)
            ActionResult.RequiresApproval ->
                CommandResponse(CommandState.WAITING_FOR_APPROVAL, "Pehle approval chahiye, sir.")
        }
    }

    private fun confirmationMessage(plan: ActionPlan): String {
        val command = plan.command
        return when (command.intent) {
            IntentType.SEND_MESSAGE -> {
                val who = command.parameters["contact_name"] ?: "the contact"
                val body = command.parameters["message"] ?: ""
                "Message ready for $who:\n\n“$body”\n\nBhej doon, sir?"
            }
            IntentType.MAKE_CALL -> {
                val who = command.parameters["contact_name"] ?: "this contact"
                "$who ko call karne wala hoon. Kar doon, sir?"
            }
            else -> "This action needs your approval, sir.\n\n${command.rawText}"
        }
    }

    private fun unknownMessage(raw: String): String {
        return "Abhi main is command ko confidently samajh nahi paaya, sir. Try: “YouTube kholo”, “Zubair ko call karo”, ya “Zubair ko message bhejo: Main aa raha hoon”."
    }

    private fun successMessage(command: JarvisCommand): String {
        return when (command.intent) {
            IntentType.OPEN_APP -> "${command.parameters["app_name"] ?: "App"} opened, sir."
            IntentType.NAVIGATE_BACK -> "Back ho gaya, sir."
            IntentType.HOME -> "Home par aa gaya, sir."
            IntentType.RECENTS -> "Recent apps khol diye, sir."
            IntentType.OPEN_NOTIFICATIONS -> "Notifications khol diye, sir."
            IntentType.MAKE_CALL -> "Call start ho gayi, sir."
            IntentType.SEND_MESSAGE -> "Message send ho gaya, sir."
            else -> "Done, sir."
        }
    }

    fun lastHistory(): List<ActionHistory.Entry> = history.read()
}
