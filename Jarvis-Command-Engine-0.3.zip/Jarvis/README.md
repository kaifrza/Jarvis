# Jarvis — Consolidated Milestone

Personal-use Android assistant foundation targeting Android 10+.

## Included

- Text command processing
- SpeechRecognizer voice input
- Text-to-Speech output
- Dynamic app launching
- Accessibility Back/Home/Recents/Notifications
- Contacts lookup
- Direct call flow
- SMS sending flow
- Explicit high-risk confirmation
- Runtime permission center
- Notification access settings
- Local action history
- Provider-independent action architecture
- GitHub Actions APK build

## Example commands

- `YouTube kholo`
- `Back`
- `Home`
- `Recent apps kholo`
- `Notifications kholo`
- `Call Zubair`
- `Zubair ko message bhejo: Main 10 minute mein aa raha hoon`

## Security rule

AI never receives direct Android API access.

`AI/Parser -> Structured Command -> Risk -> Approval -> Executor -> Verify`

## Build environment

- minSdk 29 (Android 10)
- targetSdk 37
- compileSdk 37
- Java 17
- Gradle 9.6
- Android Gradle Plugin 9.4.0

## Verification note

The source was reviewed for the command/data flow and Android API usage. This environment does not contain
an Android SDK/Gradle installation, so APK compilation cannot honestly be claimed as locally verified here.
The GitHub Actions workflow remains the authoritative build check.

## Command understanding (0.3)

Jarvis now uses an offline deterministic command-understanding layer designed for Hinglish/Roman-Urdu phrasing. Examples include:

- `YouTube kholo`, `YT open karo`, `please open WhatsApp`, `Instagram chalao`
- `back jao`, `wapas jao`, `home screen kholo`, `recent apps kholo`, `notifications dikhao`
- `Zubair ko call karo`, `mujhe Zubair ko phone lagao`
- `Zubair ko message bhejo: Main aa raha hoon`
- `message Zubair: Main aa raha hoon`
- `send a message to Zubair saying I am coming`
- `Zubair ko sms karo: Kal milte hain`

The understanding layer is isolated behind `CommandUnderstandingEngine`. It does not receive Android services or permission objects. A future LLM provider can replace the local parser without changing the risk/approval/execution layers.

The 0.3 workflow also runs the JVM command-understanding regression suite before producing the APK.
