from pathlib import Path
# BrainTaskRunner: progress listener and task-aware display
p=Path('/mnt/data/jarvis08/app/src/main/java/com/kaifrza/jarvis/core/brain/BrainTaskRunner.kt')
s=p.read_text()
s=s.replace('class BrainTaskRunner(\n', 'class BrainTaskRunner(\n')
s=s.replace('    private var activePlan: ActivePlan? = null\n', '''    private var activePlan: ActivePlan? = null\n\n    data class StepView(val taskId: String, val taskLabel: String, val index: Int, val total: Int, val title: String, val state: String)\n    fun interface ProgressListener { fun onProgress(steps: List<StepView>) }\n    @Volatile private var progressListener: ProgressListener? = null\n    private var planSteps: List<BrainStep> = emptyList()\n    private val stepStates = linkedMapOf<String, String>()\n\n    fun setProgressListener(listener: ProgressListener?) { progressListener = listener }\n''')
s=s.replace('import com.kaifrza.jarvis.core.model.JarvisCommand', 'import com.kaifrza.jarvis.core.model.JarvisCommand\nimport com.kaifrza.jarvis.core.model.BrainStep')
s=s.replace('        remaining.clear()\n        remaining.addAll(plan.steps.map { it.command })', '''        remaining.clear()\n        remaining.addAll(plan.steps.map { it.command })\n        planSteps = plan.steps\n        stepStates.clear()\n        plan.steps.forEachIndexed { i, step -> stepStates[step.command.id] = "QUEUED" }\n        emitProgress()''')
s=s.replace('            val command = remaining.removeFirst()\n            val response = processor.handleCommand(command)', '''            val command = remaining.removeFirst()\n            stepStates[command.id] = "RUNNING"\n            emitProgress()\n            val response = processor.handleCommand(command)''')
s=s.replace('                CommandState.WAITING_FOR_APPROVAL,\n                CommandState.WAITING_FOR_CHOICE,\n                CommandState.FAILED -> return response\n                else -> Unit', '''                CommandState.WAITING_FOR_APPROVAL -> { stepStates[command.id] = "WAITING"; emitProgress(); return response }\n                CommandState.WAITING_FOR_CHOICE -> { stepStates[command.id] = "WAITING"; emitProgress(); return response }\n                CommandState.FAILED -> { stepStates[command.id] = "FAILED"; emitProgress(); return response }\n                else -> { stepStates[command.id] = "DONE"; emitProgress() }''')
s=s.replace('        return CommandResponse(CommandState.SUCCESS, activePlan?.reply ?: "Done, sir.")', '        return CommandResponse(CommandState.SUCCESS, activePlan?.reply ?: "Done, sir.")')
# add import and emit method
s=s.replace('import com.kaifrza.jarvis.core.model.BrainStep', 'import com.kaifrza.jarvis.core.model.BrainStep')
s=s.replace('\n    private fun continueIfReady', '''\n    private fun emitProgress() {\n        val listener = progressListener ?: return\n        val views = planSteps.mapIndexed { index, step ->\n            StepView(step.taskId, step.taskLabel, index + 1, planSteps.size, step.rationale ?: step.command.rawText, stepStates[step.command.id] ?: "QUEUED")\n        }\n        listener.onProgress(views)\n    }\n\n    private fun continueIfReady''')
p.write_text(s)

# Offline planner task grouping and broader app/search phrases
p=Path('/mnt/data/jarvis08/app/src/main/java/com/kaifrza/jarvis/core/intent/OfflineAgentBrain.kt')
s=p.read_text()
# replace generic chained section
old='''        // Generic offline chained commands joined by "and/aur/phir/then".\n        val clauses = splitClauses(text)\n        if (clauses.size > 1) {\n            clauses.forEach { clause ->\n                val c = parser.parse(clause)\n                if (c.intent != IntentType.UNKNOWN) steps += BrainStep(c, "Offline parsed step")\n                else parseUiClause(clause)?.let { steps += BrainStep(it, "Offline UI step") }\n            }\n            if (steps.isNotEmpty()) return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-agent")\n        }'''
new='''        // Multi-task aware planner. "Saath hi" creates a second lane; "aur/phir/then" remain sequential.\n        val taskSegments = splitTasks(text)\n        if (taskSegments.size > 1 || splitClauses(text).size > 1) {\n            val segments = if (taskSegments.size > 1) taskSegments else listOf(text)\n            segments.forEachIndexed { taskIndex, segment ->\n                splitClauses(segment).forEach { clause ->\n                    val c = parser.parse(clause)\n                    val command = if (c.intent != IntentType.UNKNOWN) c else parseUiClause(clause)\n                    if (command != null) steps += BrainStep(command, "Offline parsed step", "task-${taskIndex + 1}", "Task ${taskIndex + 1}")\n                }\n            }\n            if (steps.isNotEmpty()) return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-multi-task")\n        }'''
s=s.replace(old,new)
s=s.replace('''    private fun splitClauses(text: String): List<String> {\n        val protected = text.replace(Regex("\\\\b(aur|and|phir|then|uske baad|after that)\\\\b", RegexOption.IGNORE_CASE), "|")\n        return protected.split('|').map { it.trim() }.filter { it.isNotBlank() }\n    }''','''    private fun splitClauses(text: String): List<String> {\n        val protected = text.replace(Regex("\\\\b(aur|and|phir|then|uske baad|after that)\\\\b", RegexOption.IGNORE_CASE), "|")\n        return protected.split('|').map { it.trim() }.filter { it.isNotBlank() }\n    }\n\n    private fun splitTasks(text: String): List<String> {\n        val protected = text.replace(Regex("\\\\b(?:saath hi|saath-saath|at the same time|also|meanwhile|parallel mein|parallelly)\\\\b", RegexOption.IGNORE_CASE), "|")\n        return protected.split('|').map { it.trim() }.filter { it.isNotBlank() }\n    }''')
# if replacement failed due exact string, append method before command
if 'private fun splitTasks' not in s:
    marker='    private fun command(intent: IntentType, raw: String, params: Map<String, String> = emptyMap())'
    idx=s.index(marker)
    s=s[:idx]+'    private fun splitTasks(text: String): List<String> {\n        val protected = text.replace(Regex("\\\\b(?:saath hi|saath-saath|at the same time|also|meanwhile|parallel mein|parallelly)\\\\b", RegexOption.IGNORE_CASE), "|")\n        return protected.split(\'|\').map { it.trim() }.filter { it.isNotBlank() }\n    }\n\n'+s[idx:]
p.write_text(s)

# Formatter include tasks
p=Path('/mnt/data/jarvis08/app/src/main/java/com/kaifrza/jarvis/core/brain/AgentPlanFormatter.kt')
s=p.read_text().replace('.put("rationale", step.rationale ?: JSONObject.NULL))', '.put("rationale", step.rationale ?: JSONObject.NULL)\n                .put("task_id", step.taskId)\n                .put("task_label", step.taskLabel))')
p.write_text(s)
