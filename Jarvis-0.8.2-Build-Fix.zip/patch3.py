from pathlib import Path
p=Path('/mnt/data/jarvis08/app/src/main/java/com/kaifrza/jarvis/ui/JarvisWebViewHost.kt')
s=p.read_text()
s=s.replace('import org.json.JSONObject', 'import org.json.JSONObject\nimport org.json.JSONArray')
s=s.replace('''    fun send(type: String, message: String = "", state: String = "", setupReady: Boolean = true, brainReady: Boolean = false) {''','''    fun send(type: String, message: String = "", state: String = "", setupReady: Boolean = true, brainReady: Boolean = false, tasks: JSONArray? = null) {''')
s=s.replace('''            .put("brainReady", brainReady)\n            .toString()''','''            .put("brainReady", brainReady)\n            .put("tasks", tasks ?: JSONArray())\n            .toString()''')
p.write_text(s)

# MainActivity progress hookup + offline setup state
p=Path('/mnt/data/jarvis08/app/src/main/java/com/kaifrza/jarvis/ui/MainActivity.kt')
s=p.read_text()
s=s.replace('import kotlinx.coroutines.withContext', 'import kotlinx.coroutines.withContext\nimport org.json.JSONArray\nimport org.json.JSONObject')
s=s.replace('''        host.attach(object : JarvisWebViewHost.Listener {''','''        container.brainTaskRunner.setProgressListener { steps ->\n            val json = JSONArray()\n            steps.forEach { step ->\n                json.put(JSONObject().put("taskId", step.taskId).put("taskLabel", step.taskLabel).put("index", step.index).put("total", step.total).put("title", step.title).put("state", step.state))\n            }\n            runOnUiThread { host.send("task_progress", "", "RUNNING", setupReady(), brainReady(), json) }\n        }\n\n        host.attach(object : JarvisWebViewHost.Listener {''')
s=s.replace('''    private fun brainReady(): Boolean {\n        val c = container.brainStore.read()\n        return c.enabled && c.endpoint.isNotBlank() && c.model.isNotBlank() && c.apiKey.isNotBlank()\n    }''','''    private fun brainReady(): Boolean = true''')
p.write_text(s)

# Voice session same progress and local ready
p=Path('/mnt/data/jarvis08/app/src/main/java/com/kaifrza/jarvis/voice/JarvisVoiceInteractionSession.kt')
s=p.read_text()
s=s.replace('import kotlinx.coroutines.withContext', 'import kotlinx.coroutines.withContext\nimport org.json.JSONArray\nimport org.json.JSONObject')
s=s.replace('''        webView = WebView(sessionContext)\n        host = JarvisWebViewHost(webView)''','''        webView = WebView(sessionContext)\n        host = JarvisWebViewHost(webView)\n        container.brainTaskRunner.setProgressListener { steps ->\n            val json = JSONArray()\n            steps.forEach { step -> json.put(JSONObject().put("taskId", step.taskId).put("taskLabel", step.taskLabel).put("index", step.index).put("total", step.total).put("title", step.title).put("state", step.state)) }\n            webView.post { host.send("task_progress", "", "RUNNING", setupReady(), brainReady(), json) }\n        }''')
s=s.replace('''    private fun brainReady(): Boolean {\n        val c = container.brainStore.read()\n        return c.enabled && c.endpoint.isNotBlank() && c.model.isNotBlank() && c.apiKey.isNotBlank()\n    }''','''    private fun brainReady(): Boolean = true''')
p.write_text(s)

# UI HTML task panel
p=Path('/mnt/data/jarvis08/app/src/main/assets/jarvis/index.html')
s=p.read_text().replace('<section id="conversation" class="conversation" aria-live="polite"></section>', '<section id="taskBoard" class="taskBoard hidden" aria-live="polite"></section>\n    <section id="conversation" class="conversation" aria-live="polite"></section>')
p.write_text(s)

p=Path('/mnt/data/jarvis08/app/src/main/assets/jarvis/app.js')
s=p.read_text()
s=s.replace("const input=$('#input'), conversation=$('#conversation'), status=$('#status'), dot=$('#dot'), brain=$('#brain'), approval=$('#approval'), approvalText=$('#approvalText'), setup=$('#setup');", "const input=$('#input'), conversation=$('#conversation'), status=$('#status'), dot=$('#dot'), brain=$('#brain'), approval=$('#approval'), approvalText=$('#approvalText'), setup=$('#setup'), taskBoard=$('#taskBoard');")
s=s.replace("if(d.state)status.textContent=d.state.replaceAll('_',' ');brain.textContent=d.brainReady?'BRAIN':'LOCAL';", "if(d.state)status.textContent=d.state.replaceAll('_',' ');brain.textContent='OFFLINE';\nif(Array.isArray(d.tasks)&&d.tasks.length){taskBoard.classList.remove('hidden');taskBoard.innerHTML=d.tasks.map(t=>`<div class=\"taskStep ${t.state.toLowerCase()}\"><span class=\"stepNo\">${t.index}</span><span class=\"stepBody\"><b>${escapeHtml(t.taskLabel||'Task')}</b><span>${escapeHtml(t.title||'Working…')}</span></span><span class=\"stepState\">${escapeHtml(t.state)}</span></div>`).join('');}")
p.write_text(s)

# CSS task board + overlay-friendly compact mode
p=Path('/mnt/data/jarvis08/app/src/main/assets/jarvis/style.css')
s=p.read_text()
s += '''\n.taskBoard{margin-top:12px;border:1px solid var(--line);background:rgba(10,14,19,.86);border-radius:18px;padding:8px;max-height:220px;overflow:auto}.taskStep{display:flex;align-items:center;gap:9px;padding:9px;border-radius:12px}.taskStep+.taskStep{margin-top:3px}.taskStep.running{background:rgba(114,216,255,.08)}.taskStep.done{opacity:.68}.taskStep.failed{background:rgba(255,126,139,.08)}.stepNo{width:25px;height:25px;border-radius:9px;display:grid;place-items:center;background:rgba(255,255,255,.06);font-size:10px}.stepBody{min-width:0;flex:1}.stepBody b,.stepBody span{display:block}.stepBody b{font-size:10px;color:#7f8b97;text-transform:uppercase;letter-spacing:.08em}.stepBody span{font-size:12px;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.stepState{font-size:8px;color:#71808c;letter-spacing:.08em}.overlayMode .appShell{min-height:auto;padding:10px}.overlayMode .presence{display:none}.overlayMode .topbar{padding-bottom:6px}.overlayMode .conversation{max-height:110px}.overlayMode .taskBoard{max-height:170px}.overlayMode footer,.overlayMode .quickRow{display:none}\n'''
p.write_text(s)
