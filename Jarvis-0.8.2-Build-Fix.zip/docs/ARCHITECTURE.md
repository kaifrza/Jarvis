# Jarvis 0.5 Architecture

```text
Voice / Text
     │
     ▼
HTML/CSS/JS UI ── secure local WebView bridge ──► Android host
     │                                             │
     └─────────────────────────────────────────────┤
                                                   ▼
                                         Hybrid Brain Engine
                                         ├─ Local parser
                                         └─ Remote structured brain
                                                   │
                                                   ▼
                                             Brain Plan
                                                   │
                                                   ▼
                                            Task Plan Runner
                                                   │
                                                   ▼
                                           Command Processor
                                                   │
                                      Risk / Approval / Choice
                                                   │
                                                   ▼
                                            Action Executor
                                                   │
                                                   ▼
                                      Android capabilities + verification
```

## UI boundary
The visual layer is HTML/CSS/JS only. Native Android owns permissions, contacts, calls, SMS, app launching, accessibility, speech, storage, and security decisions. The local HTML is served through `WebViewAssetLoader`; the bridge is restricted to the APK-owned origin.

## Brain boundary
The remote brain receives plain text plus a minimal context summary and returns a JSON plan. It cannot access Android APIs. The executor validates every structured action against the existing risk and permission policy.

## Multi-step state
A plan is an ordered queue. Execution stops when a step needs contact disambiguation or approval. The queue remains in memory only; sensitive pending approvals are not persisted across process restart.

## Global surface
Accessibility provides a small non-focusable bubble. The bubble launches the normal Jarvis Activity instead of hosting an EditText inside an accessibility overlay. This gives the keyboard a normal focusable window and avoids the input behavior observed in 0.4.

A true selected system assistant/wake-word implementation is deliberately isolated for a later milestone because Android 10's VoiceInteractionService metadata requires a recognition-service integration.
