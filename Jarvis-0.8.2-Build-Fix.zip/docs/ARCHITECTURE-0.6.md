# Jarvis 0.6 — Brain Spine

## Execution contract

`Input -> Conversation -> Brain -> Plan validation -> Risk policy -> Approval -> Action -> Verification -> Response`

The LLM has no Android `Context`, service reference, permission API, or executor access. It can only describe registered tools.

## Tool boundary

`core/tools/ToolRegistry.kt` is the source of truth for exposed capabilities, risk and required arguments. The same registry produces an OpenAI-compatible function schema and validates model output before execution.

## Approval

High-risk communication tools require a short-lived in-memory approval token. Approval is consumed once. Pending sensitive work is not persisted and is cleared when the process dies or the user cancels.

## Conversation

`ConversationManager` keeps a bounded in-memory context window for follow-up commands. It is deliberately not persisted.

## Verification

App launch verifies the foreground package when Accessibility is available. SMS sending now waits for Android's sent-result callback instead of immediately claiming success. Call initiation remains an initiation check, not a claim that the call was answered.

## System assistant

Jarvis now declares `VoiceInteractionService` + `VoiceInteractionSessionService` with the required `BIND_VOICE_INTERACTION` boundary. The user must still choose Jarvis as the active assistant in Android's system settings. Android 10 background voice behavior remains platform-controlled.

## Build gate

The CI workflow selects the latest committed `Jarvis-*.zip`, extracts it into a clean directory, runs unit tests and a debug APK build, then uploads the APK. Local environment verification is limited to static/source checks unless an Android SDK/Gradle environment is available.
