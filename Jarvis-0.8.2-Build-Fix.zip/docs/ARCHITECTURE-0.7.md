# Jarvis 0.7 — Offline Agent Runtime

## Goal
Jarvis is offline-first. Cloud/API configuration is optional and is never required for the core Android command path.

## Execution model
`Natural language -> Offline planner -> Structured tools -> Policy/approval -> Android executor -> Verification`

The 0.7 offline planner is deterministic and optimized for common multi-step commands. It is intentionally provider-independent. A future on-device LLM can replace/augment `OfflineAgentBrain` without changing the executor or permission boundary.

## Cross-app automation
Accessibility is treated as the generic Android UI tool boundary. The current tool set includes:
- open app
- global back/home/recents/notifications
- click visible text/content description
- focus editable input
- type/replace text
- scroll
- call contact/number
- SMS

The WhatsApp workflow is represented as reusable UI actions rather than a WhatsApp-specific native API:
1. Open WhatsApp
2. Click Search
3. Type contact name
4. Click matching chat
5. Focus message composer
6. Type message
7. Require explicit approval for Send
8. Click Send
9. Verify the message preview appears on screen

## Safety boundary
The planner cannot execute Android APIs. All actions pass through the same policy and executor used by simple commands. The `Send` UI action is dynamically promoted to HIGH risk and requires approval.

## Offline limitation
This milestone does not bundle a large generative model. It adds the offline agent spine and deterministic natural-language decomposition. This keeps the APK small and works without an API key. A future local-model milestone can plug into the same `BrainEngine` contract.
