# Jarvis 0.8 — Multi-task + Overlay Control

## What changed
- Multi-task-aware offline planning: `saath hi`, `also`, `meanwhile`, `parallel mein` create separate task lanes in the visible plan.
- Every plan step is surfaced to the UI with QUEUED/RUNNING/WAITING/DONE/FAILED state.
- The execution queue remains safe for foreground UI automation: Android can only have one active foreground UI, so UI-dependent lanes are scheduled rather than pretending to run concurrently.
- Added offline calculator, flashlight control, Wi-Fi/network/Bluetooth settings entry.
- Expanded natural-language aliases for app opening: `open`, `kholo`, `chalu kro`, `launch`, `start`, `run`, including verb-after-app forms such as `youtube open`.
- J bubble is now draggable. Tapping it opens a focusable assistant overlay instead of launching the full app.
- Overlay defaults to about 90% screen width and ~22% height, has a draggable handle, and keeps the assistant content scrollable.
- API/cloud brain remains optional; local capability path does not require an API key.

## Important Android boundary
Accessibility can interact with visible UI, but it cannot create multiple foreground apps simultaneously. The task scheduler therefore tracks multiple tasks and executes foreground-dependent steps safely one at a time while preserving each lane's state.

Direct mobile-data/Wi-Fi toggling is OS/version dependent. Where Android blocks a direct toggle, Jarvis opens the appropriate system settings so the user can complete it; Accessibility can then interact with visible settings UI when enabled.
