package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import java.util.UUID

/**
 * Deterministic offline agent planner. It is deliberately independent from Android APIs.
 * It handles common multi-step assistant language without an API key and emits the same
 * structured commands consumed by the normal executor.
 */
class OfflineAgentBrain(private val parser: IntentParser = IntentParser()) {
    fun plan(raw: String, context: String = ""): BrainPlan {
        val text = raw.trim()
        val n = text.lowercase().replace(Regex("\\s+"), " ")
        val steps = mutableListOf<BrainStep>()

        // High-value communication workflow: WhatsApp + contact + dictated message.
        if (looksLikeWhatsAppMessage(n)) {
            val app = command(IntentType.OPEN_APP, text, mapOf("app_name" to "WhatsApp"))
            steps += BrainStep(app, "Open WhatsApp")
            val contact = extractContactAfterSearch(n) ?: extractContactBeforeMessage(n)
            if (!contact.isNullOrBlank()) {
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to "Search")), "Open WhatsApp search")
                steps += BrainStep(command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to contact)), "Type contact search")
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to contact)), "Open matching chat")
            }
            val body = extractMessageBody(text)
            if (!body.isNullOrBlank()) {
                steps += BrainStep(command(IntentType.UI_FOCUS_INPUT, text), "Focus message composer")
                steps += BrainStep(command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to body)), "Prepare message")
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to "Send", "message_preview" to body!!, "contact_name" to contact!!)), "Send prepared message")
            }
            return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-agent")
        }

        // Multi-task aware planner. "Saath hi" creates a second lane; "aur/phir/then" remain sequential.
        val taskSegments = splitTasks(text)
        if (taskSegments.size > 1 || splitClauses(text).size > 1) {
            val segments = if (taskSegments.size > 1) taskSegments else listOf(text)
            segments.forEachIndexed { taskIndex, segment ->
                splitClauses(segment).forEach { clause ->
                    val c = parser.parse(clause)
                    val command = if (c.intent != IntentType.UNKNOWN) c else parseUiClause(clause)
                    if (command != null) steps += BrainStep(command, "Offline parsed step", "task-${taskIndex + 1}", "Task ${taskIndex + 1}")
                }
            }
            if (steps.isNotEmpty()) return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-multi-task")
        }

        val parsed = parser.parse(text)
        if (parsed.intent != IntentType.UNKNOWN) return BrainPlan(id = UUID.randomUUID().toString(), steps = listOf(BrainStep(parsed)), source = "offline-local")
        parseUiClause(text)?.let { return BrainPlan(id = UUID.randomUUID().toString(), steps = listOf(BrainStep(it)), source = "offline-ui") }
        return BrainPlan(id = UUID.randomUUID().toString(), source = "offline")
    }

    private fun parseUiClause(text: String): JarvisCommand? {
        val n = text.lowercase().trim()
        val searchIndex = n.lastIndexOf(" search")
        if (searchIndex >= 0) {
            var q = text.substring(0, searchIndex).trim()
            q = q.replace(Regex("(?i)^(google|chrome|youtube|browser)\\s+par\\s+"), "").trim()
            if (q.isBlank()) q = text.substring(searchIndex + 7).trim()
            if (q.isNotBlank()) return command(IntentType.UI_SEARCH, text, mapOf("query" to q))
        }
        val explicitSearch = Regex("(?i)^search\\s+(.+)$").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            it.replace(Regex("(?i)\\s+(karo|kar do|please)$"), "").trim()
        }
        if (!explicitSearch.isNullOrBlank()) return command(IntentType.UI_SEARCH, text, mapOf("query" to explicitSearch))
        val click = Regex("(?:click|tap|press|select|klick|dabao|dabao on)\\s+(.+)$").find(n)
        if (click != null) return command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to click.groupValues[1].trim()))
        val type = Regex("(?:type|enter|likho|l[ikh]o|text karo)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (type != null) return command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to type.groupValues[1].trim()))
        if (n.contains("scroll down") || n.contains("neeche scroll") || n.contains("scroll karo")) return command(IntentType.UI_SCROLL, text, mapOf("direction" to "down"))
        if (n.contains("scroll up") || n.contains("upar scroll")) return command(IntentType.UI_SCROLL, text, mapOf("direction" to "up"))
        return null
    }

    private fun looksLikeWhatsAppMessage(n: String): Boolean =
        n.contains("whatsapp") && (n.contains("message") || n.contains("bolo") || n.contains("keh do") || n.contains("batao") || n.contains("likho"))

    private fun extractContactAfterSearch(n: String): String? =
        Regex("(?:chat|contact)\\s+(?:me|mein)\\s+([a-z][a-z0-9 .'-]{1,40}?)\\s+(?:search|dhoond|dhundo|find)", RegexOption.IGNORE_CASE)
            .find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }

    private fun extractContactBeforeMessage(n: String): String? =
        Regex("(?:to|ko|usko|usse)\\s+([a-z][a-z0-9 .'-]{1,40}?)(?:\\s+(?:bolo|batao|message|msg|text|keh do)\\b)", RegexOption.IGNORE_CASE)
            .find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }

    private fun extractMessageBody(text: String): String? {
        Regex("(?i)(?:bolo|batao|keh do|message|msg|text)\\s*[:,-]?\\s*['\"]?(.+?)['\"]?$").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            val cleaned = it.replace(Regex("(?i)^(?:bolo\\s+)+"), "").trim()
            if (cleaned.isNotBlank()) return cleaned
        }
        Regex("(?i)us(?:ko|se)\\s+(.+)$").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            val cleaned = it.replace(Regex("(?i)^(?:bolo\\s+)+"), "").trim()
            if (cleaned.isNotBlank()) return cleaned
        }
        return null
    }

    private fun splitClauses(text: String): List<String> {
        val protected = text.replace(Regex("\\b(aur|and|phir|then|uske baad|after that)\\b", RegexOption.IGNORE_CASE), "|")
        return protected.split('|').map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun splitTasks(text: String): List<String> {
        val protected = text.replace(Regex("\\b(?:saath hi|saath-saath|at the same time|also|meanwhile|parallel mein|parallelly)\\b", RegexOption.IGNORE_CASE), "|")
        return protected.split('|').map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun command(intent: IntentType, raw: String, params: Map<String, String> = emptyMap()) =
        JarvisCommand(UUID.randomUUID().toString(), raw, intent, params)
}
