package com.kaifrza.jarvis.core.actions

import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.security.ApprovalManager
import com.kaifrza.jarvis.core.security.RiskEngine

class ActionExecutor(
    private val riskEngine: RiskEngine,
    private val approvalManager: ApprovalManager,
    private val registry: ActionRegistry
) {
    data class PreparedAction(
        val plan: ActionPlan,
        val approvalToken: String?
    )

    fun prepare(plan: ActionPlan): PreparedAction {
        val token = if (plan.requiresConfirmation) {
            approvalManager.request(plan.command.id)
        } else null
        return PreparedAction(plan, token)
    }

    fun execute(
        prepared: PreparedAction,
        approvalToken: String? = null
    ): ActionResult {
        val plan = prepared.plan

        if (plan.requiresConfirmation) {
            if (approvalToken == null ||
                prepared.approvalToken == null ||
                approvalToken != prepared.approvalToken ||
                !approvalManager.approve(approvalToken, plan.command.id)
            ) return ActionResult.RequiresApproval
        }

        val action = registry.resolve(plan.command.intent)
            ?: return ActionResult.Failure(
                "No executor registered for ${plan.command.intent}."
            )

        val validation = action.validate(plan)
        if (validation !is ActionResult.Success) return validation

        val execution = action.execute(plan)
        if (execution !is ActionResult.Success && execution !is ActionResult.SuccessWithMessage) return execution

        val verification = action.verify(plan)
        if (verification !is ActionResult.Success) return verification
        return execution
    }

    fun revoke(token: String) {
        approvalManager.revoke(token)
    }
}
