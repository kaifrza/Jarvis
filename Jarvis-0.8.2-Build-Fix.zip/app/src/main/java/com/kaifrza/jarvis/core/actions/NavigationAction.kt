package com.kaifrza.jarvis.core.actions

import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType

class NavigationAction : JarvisAction {
    override val id = "android.navigation"

    override fun validate(plan: ActionPlan): ActionResult {
        if (JarvisAccessibilityService.instance == null) {
            return ActionResult.Failure(
                "Jarvis Accessibility Service is not enabled. Enable it in Android Settings."
            )
        }
        return ActionResult.Success
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val service = JarvisAccessibilityService.instance
            ?: return ActionResult.Failure("Accessibility Service is unavailable.")

        val success = when (plan.command.intent) {
            IntentType.NAVIGATE_BACK -> service.performGlobalActionBack()
            IntentType.HOME -> service.performGlobalActionHome()
            IntentType.RECENTS -> service.performGlobalActionRecents()
            IntentType.OPEN_NOTIFICATIONS -> service.performGlobalActionNotifications()
            else -> false
        }

        return if (success) ActionResult.Success
        else ActionResult.Failure("Android could not perform that navigation action.")
    }

    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success
}
