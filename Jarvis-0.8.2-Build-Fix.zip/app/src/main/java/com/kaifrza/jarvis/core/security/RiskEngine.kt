package com.kaifrza.jarvis.core.security

import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.model.RiskLevel
import com.kaifrza.jarvis.core.tools.ToolRegistry

/** Policy boundary. The model cannot lower the risk declared by a registered tool. */
class RiskEngine(private val tools: ToolRegistry) {
    fun plan(command: JarvisCommand): ActionPlan {
        val descriptor = tools.find(command.intent)
        val risk = descriptor?.risk ?: when (command.intent) {
            IntentType.UNKNOWN -> RiskLevel.CRITICAL
            else -> RiskLevel.HIGH
        }
        val uiSend = command.intent == IntentType.UI_CLICK_TEXT &&
            command.parameters["text"].orEmpty().lowercase().let { it == "send" || it.contains("send message") || it == "bhejo" }
        return ActionPlan(
            command = command,
            risk = if (uiSend) RiskLevel.HIGH else risk,
            requiresConfirmation = if (uiSend) true else (descriptor?.requiresConfirmation ?: true)
        )
    }
}
