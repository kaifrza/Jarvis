package com.kaifrza.jarvis.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class JarvisSpeaker(
    context: Context,
    private val onReady: (() -> Unit)? = null
) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            onReady?.invoke()
        }
    }

    fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
