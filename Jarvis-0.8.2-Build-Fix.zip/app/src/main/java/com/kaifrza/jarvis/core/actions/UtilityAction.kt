package com.kaifrza.jarvis.core.actions

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.Settings
import com.kaifrza.jarvis.core.model.ActionPlan
import com.kaifrza.jarvis.core.model.IntentType

class UtilityAction(private val context: Context) : JarvisAction {
    override val id = "android.utility"

    override fun validate(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.CALCULATE -> if (plan.command.parameters["expression"].isNullOrBlank()) ActionResult.Failure("Mujhe calculation expression nahi mila.") else ActionResult.Success
        IntentType.SET_FLASHLIGHT -> if (android.os.Build.VERSION.SDK_INT >= 23) ActionResult.Success else ActionResult.Failure("Torch control is not available on this Android version.")
        else -> ActionResult.Success
    }

    override fun execute(plan: ActionPlan): ActionResult = when (plan.command.intent) {
        IntentType.OPEN_NETWORK_SETTINGS -> open(Settings.ACTION_WIRELESS_SETTINGS)
        IntentType.OPEN_WIFI_SETTINGS -> open(Settings.ACTION_WIFI_SETTINGS)
        IntentType.OPEN_BLUETOOTH_SETTINGS -> open(Settings.ACTION_BLUETOOTH_SETTINGS)
        IntentType.SET_FLASHLIGHT -> setTorch(plan.command.parameters["enabled"] != "false")
        IntentType.CALCULATE -> {
            val expression = plan.command.parameters["expression"].orEmpty()
            val result = SimpleCalculator.evaluate(expression)
            if (result == null) ActionResult.Failure("Main calculation ko samajh nahi paaya: $expression")
            else ActionResult.SuccessWithMessage("$expression = $result")
        }
        else -> ActionResult.Failure("Unsupported utility action.")
    }

    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success

    private fun open(action: String): ActionResult = runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Settings open nahi ho sakin.") }

    private fun setTorch(enabled: Boolean): ActionResult = runCatching {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id -> manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return ActionResult.Failure("Torch camera nahi mila.")
        manager.setTorchMode(cameraId, enabled)
        ActionResult.Success
    }.getOrElse { ActionResult.Failure("Torch control fail hua: ${it.message ?: "unknown"}") }
}

private object SimpleCalculator {
    fun evaluate(raw: String): String? {
        val s = raw.replace(" ", "")
        val m = Regex("^(-?\\d+(?:\\.\\d+)?)([+\\-*/])(-?\\d+(?:\\.\\d+)?)$").matchEntire(s) ?: return null
        val a = m.groupValues[1].toDoubleOrNull() ?: return null
        val b = m.groupValues[3].toDoubleOrNull() ?: return null
        val v = when (m.groupValues[2]) { "+" -> a+b; "-" -> a-b; "*" -> a*b; "/" -> if (b == 0.0) return null else a/b; else -> return null }
        return if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
    }
}
