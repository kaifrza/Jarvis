package com.kaifrza.jarvis.core.actions

import android.content.Context
import android.content.Intent
import com.kaifrza.jarvis.accessibility.JarvisAccessibilityService
import com.kaifrza.jarvis.core.model.ActionPlan

class OpenAppAction(private val context: Context) : JarvisAction {
    override val id = "android.open_app"

    override fun validate(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["app_name"]
            ?: return ActionResult.Failure("Tell me which app to open.")
        return if (AppResolver(context).findLaunchable(name) != null) {
            ActionResult.Success
        } else {
            ActionResult.Failure("I couldn't find $name among your launchable apps.")
        }
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["app_name"] ?: return ActionResult.Failure("Missing app.")
        val resolved = AppResolver(context).findLaunchable(name)
            ?: return ActionResult.Failure("The app is no longer available.")

        return try {
            resolved.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(resolved)
            ActionResult.Success
        } catch (e: Exception) {
            ActionResult.Failure("Android could not open $name.")
        }
    }

    override fun verify(plan: ActionPlan): ActionResult {
        val name = plan.command.parameters["app_name"] ?: return ActionResult.Failure("Missing app.")
        val resolved = AppResolver(context).findLaunchable(name)
            ?: return ActionResult.Failure("The app is no longer available.")
        val expectedPackage = resolved.component?.packageName
            ?: return ActionResult.Failure("I couldn't determine the app package.")
        val service = JarvisAccessibilityService.instance
            ?: return ActionResult.Success // Accessibility is optional for app launching.
        return if (service.waitForForegroundPackage(expectedPackage)) {
            ActionResult.Success
        } else {
            ActionResult.Failure("$name was launched, but I couldn't verify it became the active app.")
        }
    }
}

class AppResolver(private val context: Context) {
    fun findLaunchable(query: String): Intent? {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val target = query.trim().lowercase()
        val match = apps.firstOrNull {
            val label = it.loadLabel(pm).toString().lowercase()
            label == target || label.contains(target)
        } ?: return null

        return Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(match.activityInfo.packageName, match.activityInfo.name)
        }
    }
}
