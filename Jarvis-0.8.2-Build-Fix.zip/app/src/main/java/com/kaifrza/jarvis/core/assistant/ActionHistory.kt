package com.kaifrza.jarvis.core.assistant

import android.content.Context
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.JarvisCommand
import org.json.JSONArray
import org.json.JSONObject

class ActionHistory(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_history", Context.MODE_PRIVATE)
    private val key = "entries"
    private val maxEntries = 50

    data class Entry(
        val command: String,
        val state: CommandState,
        val timestamp: Long
    )

    fun record(command: JarvisCommand, response: CommandResponse) {
        val current = JSONArray(prefs.getString(key, "[]"))
        val output = JSONArray()

        output.put(
            JSONObject()
                .put("command", safeLabel(command))
                .put("state", response.state.name)
                .put("timestamp", System.currentTimeMillis())
        )

        for (i in 0 until minOf(current.length(), maxEntries - 1)) {
            output.put(current.getJSONObject(i))
        }

        prefs.edit().putString(key, output.toString()).apply()
    }

    private fun safeLabel(command: JarvisCommand): String = when (command.intent) {
        com.kaifrza.jarvis.core.model.IntentType.SEND_MESSAGE -> {
            val target = command.parameters["resolved_display_name"]
                ?: command.parameters["contact_name"]
                ?: command.parameters["phone_number"]
                ?: "contact"
            "Send message to $target"
        }
        com.kaifrza.jarvis.core.model.IntentType.MAKE_CALL -> {
            val target = command.parameters["resolved_display_name"]
                ?: command.parameters["contact_name"]
                ?: command.parameters["phone_number"]
                ?: "contact"
            "Call $target"
        }
        else -> command.rawText.take(240)
    }

    fun read(): List<Entry> {
        val current = JSONArray(prefs.getString(key, "[]"))
        return buildList {
            for (i in 0 until current.length()) {
                val o = current.getJSONObject(i)
                add(
                    Entry(
                        command = o.optString("command"),
                        state = runCatching {
                            CommandState.valueOf(o.optString("state"))
                        }.getOrDefault(CommandState.FAILED),
                        timestamp = o.optLong("timestamp")
                    )
                )
            }
        }
    }
}
