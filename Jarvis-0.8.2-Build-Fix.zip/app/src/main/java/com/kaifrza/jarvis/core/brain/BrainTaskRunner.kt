package com.kaifrza.jarvis.core.brain

import com.kaifrza.jarvis.core.assistant.CommandProcessor
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.conversation.ConversationManager
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.model.BrainStep

/**
 * Owns the active plan. Sensitive steps are never persisted and are resumed only
 * while this process remains alive and the user completes any required approval.
 */
class BrainTaskRunner(
    private val brain: BrainEngine,
    private val processor: CommandProcessor,
    private val conversation: ConversationManager
) {
    private data class ActivePlan(
        val id: String,
        val reply: String?,
        val startedAtMs: Long
    )

    private val remaining = ArrayDeque<JarvisCommand>()
    private var activePlan: ActivePlan? = null

    data class StepView(val taskId: String, val taskLabel: String, val index: Int, val total: Int, val title: String, val state: String)
    fun interface ProgressListener { fun onProgress(steps: List<StepView>) }
    @Volatile private var progressListener: ProgressListener? = null
    private var planSteps: List<BrainStep> = emptyList()
    private val stepStates = linkedMapOf<String, String>()

    fun setProgressListener(listener: ProgressListener?) { progressListener = listener }

    fun handle(rawText: String, context: String = ""): CommandResponse {
        val text = rawText.trim()
        if (text.isEmpty()) return CommandResponse(CommandState.FAILED, "Command khaali hai, sir.")

        if (processor.hasPendingApproval() || processor.hasPendingChoice()) {
            val response = processor.handle(text)
            return continueIfReady(response)
        }

        val mergedContext = buildString {
            if (context.isNotBlank()) append(context)
            val history = conversation.context()
            if (history.isNotBlank()) {
                if (isNotEmpty()) append('\n')
                append("Recent conversation:\n").append(history)
            }
        }

        val plan = brain.plan(text, mergedContext)
        if (plan.steps.isEmpty()) {
            val failed = CommandResponse(CommandState.FAILED, plan.reply ?: "Sir, mujhe abhi is command ko confidently map karna nahi aaya.")
            conversation.add(text, failed.message)
            return failed
        }

        remaining.clear()
        remaining.addAll(plan.steps.map { it.command })
        planSteps = plan.steps
        stepStates.clear()
        plan.steps.forEachIndexed { i, step -> stepStates[step.command.id] = "QUEUED" }
        emitProgress()
        activePlan = ActivePlan(plan.id, plan.reply, System.currentTimeMillis())
        val response = runNext()
        val final = if (!plan.reply.isNullOrBlank() && response.state == CommandState.SUCCESS) response.copy(message = plan.reply) else response
        if (final.state == CommandState.SUCCESS || final.state == CommandState.FAILED || final.state == CommandState.CANCELLED) {
            conversation.add(text, final.message)
            activePlan = null
        }
        return final
    }

    fun approve(): CommandResponse = continueIfReady(processor.approve())

    fun cancel(): CommandResponse {
        remaining.clear()
        activePlan = null
        return processor.cancel()
    }

    private fun runNext(): CommandResponse {
        while (remaining.isNotEmpty()) {
            val command = remaining.removeFirst()
            stepStates[command.id] = "RUNNING"
            emitProgress()
            val response = processor.handleCommand(command)
            when (response.state) {
                CommandState.WAITING_FOR_APPROVAL -> { stepStates[command.id] = "WAITING"; emitProgress(); return response }
                CommandState.WAITING_FOR_CHOICE -> { stepStates[command.id] = "WAITING"; emitProgress(); return response }
                CommandState.FAILED -> { stepStates[command.id] = "FAILED"; emitProgress(); return response }
                else -> { stepStates[command.id] = "DONE"; emitProgress() }
            }
        }
        return CommandResponse(CommandState.SUCCESS, activePlan?.reply ?: "Done, sir.")
    }

    private fun emitProgress() {
        val listener = progressListener ?: return
        val views = planSteps.mapIndexed { index, step ->
            StepView(step.taskId, step.taskLabel, index + 1, planSteps.size, step.rationale ?: step.command.rawText, stepStates[step.command.id] ?: "QUEUED")
        }
        listener.onProgress(views)
    }

    private fun continueIfReady(response: CommandResponse): CommandResponse {
        if (response.state == CommandState.WAITING_FOR_APPROVAL ||
            response.state == CommandState.WAITING_FOR_CHOICE ||
            response.state == CommandState.FAILED) return response
        return if (remaining.isEmpty()) response else runNext()
    }
}
