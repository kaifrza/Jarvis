package com.kaifrza.jarvis.ui

import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.JavascriptInterface
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import org.json.JSONArray

class JarvisWebViewHost(private val webView: WebView) {
    companion object {
        private const val ORIGIN = "https://appassets.androidplatform.net"
    }

    interface Listener {
        fun onCommand(text: String)
        fun onMic()
        fun onApprove()
        fun onCancel()
        fun onOpenSettings()
    }

    fun attach(listener: Listener) {
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(webView.context))
            .build()

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            @Suppress("DEPRECATION")
            override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(Uri.parse(url))
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(
                webView,
                "jarvisNative",
                setOf(ORIGIN),
                WebViewCompat.WebMessageListener { _, message, sourceOrigin, isMainFrame, replyProxy ->
                    if (!isMainFrame || sourceOrigin.toString() != ORIGIN) return@WebMessageListener
                    handleMessage(message.data.orEmpty(), listener)
                    replyProxy.postMessage("{\"ok\":true}")
                }
            )
        } else {
            webView.addJavascriptInterface(LocalBridge(listener), "jarvisNative")
        }

        webView.loadUrl("$ORIGIN/assets/jarvis/index.html")
    }

    fun send(type: String, message: String = "", state: String = "", setupReady: Boolean = true, brainReady: Boolean = false, tasks: JSONArray? = null) {
        val payload = JSONObject()
            .put("type", type)
            .put("message", message)
            .put("state", state)
            .put("setupReady", setupReady)
            .put("brainReady", brainReady)
            .put("tasks", tasks ?: JSONArray())
            .toString()
            .replace("\\", "\\\\")
            .replace("'", "\\'")
        webView.post { webView.evaluateJavascript("window.jarvisNativeMessage('$payload')", null) }
    }

    private inner class LocalBridge(private val listener: Listener) {
        @JavascriptInterface fun postMessage(raw: String) {
            // The page is APK-owned local content loaded from appassets.androidplatform.net.
            // No remote navigation is permitted by this host.
            handleMessage(raw, listener)
        }
    }

    private fun handleMessage(raw: String, listener: Listener) {
        runCatching {
            val obj = JSONObject(raw)
            when (obj.optString("type")) {
                "command" -> listener.onCommand(obj.optString("text"))
                "mic" -> listener.onMic()
                "approve" -> listener.onApprove()
                "cancel" -> listener.onCancel()
                "settings" -> listener.onOpenSettings()
            }
        }
    }
}
