package com.kaifrza.jarvis.ui

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.WebView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.kaifrza.jarvis.JarvisApplication
import com.kaifrza.jarvis.core.assistant.CommandResponse
import com.kaifrza.jarvis.core.brain.BrainConfig
import com.kaifrza.jarvis.core.model.CommandState
import com.kaifrza.jarvis.voice.JarvisSpeaker
import com.kaifrza.jarvis.voice.JarvisVoiceController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val container get() = (application as JarvisApplication).container
    private lateinit var webView: WebView
    private lateinit var host: JarvisWebViewHost
    private lateinit var speaker: JarvisSpeaker
    private lateinit var voice: JarvisVoiceController

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { pushStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        speaker = JarvisSpeaker(this)
        host = JarvisWebViewHost(webView)
        container.brainTaskRunner.setProgressListener { steps ->
            val json = JSONArray()
            steps.forEach { step ->
                json.put(JSONObject().put("taskId", step.taskId).put("taskLabel", step.taskLabel).put("index", step.index).put("total", step.total).put("title", step.title).put("state", step.state))
            }
            runOnUiThread { host.send("task_progress", "", "RUNNING", setupReady(), brainReady(), json) }
        }

        host.attach(object : JarvisWebViewHost.Listener {
            override fun onCommand(text: String) = process(text)
            override fun onMic() = startMic()
            override fun onApprove() = processResult(container.brainTaskRunner.approve())
            override fun onCancel() = processResult(container.brainTaskRunner.cancel())
            override fun onOpenSettings() = handleSettingsEntry()
        })

        voice = JarvisVoiceController(this, object : JarvisVoiceController.Listener {
            override fun onReady() = host.send("voice", "Listening…", "LISTENING", setupReady(), brainReady())
            override fun onListening() = host.send("voice", "I'm listening…", "LISTENING", setupReady(), brainReady())
            override fun onPartial(text: String) = host.send("voice", text, "LISTENING", setupReady(), brainReady())
            override fun onResult(text: String) = process(text)
            override fun onError(message: String) = host.send("voice", message, "FAILED", setupReady(), brainReady())
        })
        pushStatus()
    }

    override fun onResume() {
        super.onResume()
        pushStatus()
    }

    private fun process(raw: String) {
        if (raw.trim().isEmpty()) return
        host.send("thinking", "Thinking…", "THINKING", setupReady(), brainReady())
        lifecycleScope.launch(Dispatchers.IO) {
            val context = "foreground=${com.kaifrza.jarvis.accessibility.JarvisAccessibilityService.instance?.foregroundPackage ?: "unknown"}"
            val result = runCatching { container.brainTaskRunner.handle(raw, context) }
                .getOrElse { CommandResponse(CommandState.FAILED, "Brain error: ${it.message ?: "unknown error"}") }
            withContext(Dispatchers.Main) { processResult(result) }
        }
    }

    private fun processResult(result: CommandResponse) {
        host.send("response", result.message, result.state.name, setupReady(), brainReady())
        if (result.state == CommandState.SUCCESS) speaker.speak(result.message)
    }

    private fun startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) voice.start()
        else permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
    }

    private fun pushStatus() {
        if (!::host.isInitialized) return
        host.send("status", "", if (setupReady()) "READY" else "SETUP", setupReady(), brainReady())
    }

    private fun setupReady(): Boolean =
        PermissionCenter.corePermissionsReady(this) && PermissionCenter.isAccessibilityEnabled(this)

    private fun brainReady(): Boolean = true

    private fun handleSettingsEntry() {
        when {
            !PermissionCenter.corePermissionsReady(this) -> permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            !PermissionCenter.isAccessibilityEnabled(this) -> PermissionCenter.openAccessibilitySettings(this)
            else -> showSettings()
        }
    }

    private fun showSettings() {
        val cfg = container.brainStore.read()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 8, 48, 0)
        }
        val endpoint = EditText(this).apply { hint = "OpenAI-compatible endpoint"; setText(cfg.endpoint) }
        val model = EditText(this).apply { hint = "Model"; setText(cfg.model) }
        val key = EditText(this).apply { hint = "API key"; setText(cfg.apiKey); inputType = 0x00000081 }
        val enabled = Switch(this).apply { text = "Enable remote brain"; isChecked = cfg.enabled }
        box.addView(endpoint); box.addView(model); box.addView(key); box.addView(enabled)
        AlertDialog.Builder(this)
            .setTitle("Jarvis Brain")
            .setMessage("Use a trusted OpenAI-compatible endpoint. The API key is stored using Android Keystore encryption.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                container.brainStore.save(BrainConfig(enabled.isChecked, endpoint.text.toString(), model.text.toString(), key.text.toString()))
                pushStatus()
            }.show()
    }

    override fun onDestroy() {
        voice.destroy()
        speaker.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
