package com.kaifrza.jarvis.core.actions

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.kaifrza.jarvis.core.model.ActionPlan

class SmsAction(
    private val context: Context,
    private val resolver: ContactResolver
) : JarvisAction {

    override val id = "communication.sms"

    override fun validate(plan: ActionPlan): ActionResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("SMS permission is required to send the message.")
        }

        val body = plan.command.parameters["message"]
            ?: return ActionResult.Failure("Tell me what message I should prepare.")
        if (body.isBlank()) return ActionResult.Failure("The message is empty.")

        val directNumber = plan.command.parameters["phone_number"]
        if (!directNumber.isNullOrBlank()) {
            return if (directNumber.filter(Char::isDigit).length >= 7) ActionResult.Success
            else ActionResult.Failure("That phone number doesn't look valid.")
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("Contacts permission is required to find the person.")
        }

        val name = plan.command.parameters["contact_name"]
            ?: return ActionResult.Failure("Tell me who should receive the message.")
        val matches = resolver.find(name)
        return when {
            matches.isEmpty() -> ActionResult.Failure("I couldn't find $name in your contacts.")
            matches.size > 1 -> ActionResult.Failure("I found multiple contacts matching $name. Tell me which number.")
            else -> ActionResult.Success
        }
    }

    override fun execute(plan: ActionPlan): ActionResult {
        val directNumber = plan.command.parameters["phone_number"]
        val number = if (!directNumber.isNullOrBlank()) {
            directNumber
        } else {
            val name = plan.command.parameters["contact_name"] ?: return ActionResult.Failure("Missing contact.")
            resolver.find(name).singleOrNull()?.phoneNumber
                ?: return ActionResult.Failure("The contact became ambiguous or unavailable.")
        }
        val body = plan.command.parameters["message"] ?: return ActionResult.Failure("Missing message.")
        val commandId = plan.command.id
        val sentAction = "${context.packageName}.SMS_SENT.$commandId"
        return try {
            val sms = SmsManager.getDefault()
            val parts = sms.divideMessage(body)
            SmsSentReceiver.register(commandId, parts.size)
            val sentIntents = ArrayList<PendingIntent>(parts.size)
            parts.indices.forEach { index ->
                val sentActionForPart = "$sentAction.part.$index"
                sentIntents += PendingIntent.getBroadcast(
                    context,
                    commandId.hashCode() + index,
                    Intent(context, SmsSentReceiver::class.java).setAction(sentActionForPart),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }
            sms.sendMultipartTextMessage(number, null, parts, sentIntents, null)
            when (SmsSentReceiver.await(commandId)) {
                true -> ActionResult.Success
                false -> ActionResult.Failure("Android reported that the SMS could not be sent.")
                null -> ActionResult.Failure("SMS request was accepted, but Android did not confirm the send in time.")
            }
        } catch (e: SecurityException) {
            SmsSentReceiver.cancel(commandId)
            ActionResult.Failure("Android denied the SMS permission.")
        } catch (e: UnsupportedOperationException) {
            SmsSentReceiver.cancel(commandId)
            ActionResult.Failure("This device does not support SMS messaging.")
        } catch (e: Exception) {
            SmsSentReceiver.cancel(commandId)
            ActionResult.Failure("The SMS could not be sent.")
        }
    }

    override fun verify(plan: ActionPlan): ActionResult = ActionResult.Success
}
