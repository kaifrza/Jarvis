package com.kaifrza.jarvis.notifications

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // Notification ingestion will be added after the permission/privacy layer.
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = Unit
}
