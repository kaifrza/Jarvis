package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.IntentType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IntentParserTest {
    private val parser = IntentParser()

    @Test fun understandsOpenAppVariants() {
        listOf(
            "YouTube kholo",
            "YT open karo",
            "please open WhatsApp",
            "Instagram chalao",
            "Chrome launch karo",
            "calculator kholo",
            "open Settings"
        ).forEach { text ->
            assertEquals(IntentType.OPEN_APP, parser.parse(text).intent)
        }
    }

    @Test fun understandsNavigationVariants() {
        assertEquals(IntentType.NAVIGATE_BACK, parser.parse("wapas jao").intent)
        assertEquals(IntentType.NAVIGATE_BACK, parser.parse("previous page").intent)
        assertEquals(IntentType.HOME, parser.parse("home screen kholo").intent)
        assertEquals(IntentType.RECENTS, parser.parse("recent apps kholo").intent)
        assertEquals(IntentType.OPEN_NOTIFICATIONS, parser.parse("notifications dikhao").intent)
    }

    @Test fun extractsCallTarget() {
        assertEquals("zubair", parser.parse("Zubair ko call karo").parameters["contact_name"])
        assertEquals("zubair", parser.parse("mujhe Zubair ko phone lagao").parameters["contact_name"])
    }


    @Test fun extractsDirectPhoneNumber() {
        val a = parser.parse("9876543210 par call karo")
        assertEquals(IntentType.MAKE_CALL, a.intent)
        assertEquals("9876543210", a.parameters["phone_number"])

        val b = parser.parse("call +91 98765 43210")
        assertEquals(IntentType.MAKE_CALL, b.intent)
        assertEquals("919876543210", b.parameters["phone_number"])
    }

    @Test fun extractsMessageTargetAndBody() {
        val cases = listOf(
            "Zubair ko message bhejo: Main aa raha hoon" to ("zubair" to "Main aa raha hoon"),
            "message Zubair: Main aa raha hoon" to ("zubair" to "Main aa raha hoon"),
            "send a message to Zubair saying I am coming" to ("zubair" to "I am coming"),
            "Zubair ko sms karo: Kal milte hain" to ("zubair" to "Kal milte hain"),
            "Zubair ko msg bhejo Main aa raha hoon" to ("zubair" to "Main aa raha hoon")
        )

        cases.forEach { (input, expected) ->
            val command = parser.parse(input)
            assertEquals(IntentType.SEND_MESSAGE, command.intent)
            assertEquals(expected.first, command.parameters["contact_name"])
            assertEquals(expected.second, command.parameters["message"])
        }
    }

    @Test fun doesNotTreatOrdinaryYoutubeSentenceAsOpenApp() {
        val command = parser.parse("I watch youtube every day")
        assertTrue(command.intent != IntentType.OPEN_APP)
    }
}
