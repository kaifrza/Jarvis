package com.kaifrza.jarvis

import com.kaifrza.jarvis.core.brain.BrainJsonParser
import com.kaifrza.jarvis.core.brain.BrainPlanValidator
import com.kaifrza.jarvis.core.conversation.ConversationManager
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import com.kaifrza.jarvis.core.security.RiskEngine
import com.kaifrza.jarvis.core.tools.ToolRegistry
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BrainCoreTest {
    @Test
    fun toolJsonContractParsesIntoKnownIntent() {
        val json = """
            {"reply":"","steps":[{"tool":"android_back","arguments":{},"rationale":"navigation"}]}
        """.trimIndent()
        val plan = BrainJsonParser.parsePlan(json)
        assertEquals(1, plan.steps.size)
        assertEquals(IntentType.NAVIGATE_BACK, plan.steps.single().command.intent)
    }

    @Test
    fun openAiToolCallIsMappedWithoutExecutingAnything() {
        val calls = JSONArray("""
            [{"id":"call_1","type":"function","function":{"name":"android_home","arguments":"{}"}}]
        """)
        val plan = BrainJsonParser.parseToolCalls(calls)
        assertEquals(IntentType.HOME, plan.steps.single().command.intent)
    }

    @Test
    fun validatorRejectsUnknownIntent() {
        val registry = ToolRegistry()
        val validator = BrainPlanValidator(registry)
        val unknown = com.kaifrza.jarvis.core.model.BrainPlan(
            steps = listOf(com.kaifrza.jarvis.core.model.BrainStep(
                JarvisCommand("1", "unknown", IntentType.UNKNOWN)
            ))
        )
        val failed = runCatching { validator.validate(unknown) }
        assertTrue(failed.isFailure)
    }

    @Test
    fun highRiskCommunicationRequiresApproval() {
        val command = JarvisCommand("1", "call", IntentType.MAKE_CALL, mapOf("phone_number" to "9876543210"))
        val plan = RiskEngine(ToolRegistry()).plan(command)
        assertTrue(plan.requiresConfirmation)
    }

    @Test
    fun conversationWindowIsBounded() {
        val memory = ConversationManager(maxTurns = 2)
        memory.add("one", "a")
        memory.add("two", "b")
        memory.add("three", "c")
        assertEquals(listOf("two", "three"), memory.recent().map { it.user })
    }
}
