package com.kaifrza.jarvis.core.intent

import com.kaifrza.jarvis.core.model.BrainPlan
import com.kaifrza.jarvis.core.model.BrainStep
import com.kaifrza.jarvis.core.model.IntentType
import com.kaifrza.jarvis.core.model.JarvisCommand
import java.util.UUID

/**
 * Deterministic offline agent planner. It is deliberately independent from Android APIs.
 * It handles common multi-step assistant language without an API key and emits the same
 * structured commands consumed by the normal executor.
 */
class OfflineAgentBrain(private val parser: IntentParser = IntentParser()) {
    fun plan(raw: String, context: String = ""): BrainPlan {
        val text = raw.trim()
        val n = text.lowercase().replace(Regex("\\s+"), " ")
        val steps = mutableListOf<BrainStep>()

        // High-value communication workflow: WhatsApp + contact + dictated message.
        if (looksLikeWhatsAppMessage(n)) {
            val app = command(IntentType.OPEN_APP, text, mapOf("app_name" to "WhatsApp"))
            steps += BrainStep(app, "Open WhatsApp")
            val contact = extractContactAfterSearch(n) ?: extractContactBeforeMessage(n)
            if (!contact.isNullOrBlank()) {
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to "Search")), "Open WhatsApp search")
                steps += BrainStep(command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to contact)), "Type contact search")
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to contact)), "Open matching chat")
            }
            val body = extractMessageBody(text)
            if (!body.isNullOrBlank()) {
                steps += BrainStep(command(IntentType.UI_FOCUS_INPUT, text), "Focus message composer")
                steps += BrainStep(command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to body)), "Prepare message")
                steps += BrainStep(command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to "Send", "message_preview" to body!!, "contact_name" to contact!!)), "Send prepared message")
            }
            return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-agent")
        }

        // Generic offline chained commands joined by "and/aur/phir/then".
        val clauses = splitClauses(text)
        if (clauses.size > 1) {
            clauses.forEach { clause ->
                val c = parser.parse(clause)
                if (c.intent != IntentType.UNKNOWN) steps += BrainStep(c, "Offline parsed step")
                else parseUiClause(clause)?.let { steps += BrainStep(it, "Offline UI step") }
            }
            if (steps.isNotEmpty()) return BrainPlan(id = UUID.randomUUID().toString(), steps = steps, source = "offline-agent")
        }

        val parsed = parser.parse(text)
        if (parsed.intent != IntentType.UNKNOWN) return BrainPlan(id = UUID.randomUUID().toString(), steps = listOf(BrainStep(parsed)), source = "offline-local")
        parseUiClause(text)?.let { return BrainPlan(id = UUID.randomUUID().toString(), steps = listOf(BrainStep(it)), source = "offline-ui") }
        return BrainPlan(id = UUID.randomUUID().toString(), source = "offline")
    }

    private fun parseUiClause(text: String): JarvisCommand? {
        val n = text.lowercase().trim()
        val click = Regex("(?:click|tap|press|select|klick|dabao|dabao on)\\s+(.+)$").find(n)
        if (click != null) return command(IntentType.UI_CLICK_TEXT, text, mapOf("text" to click.groupValues[1].trim()))
        val type = Regex("(?:type|enter|likho|l[ikh]o|text karo)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (type != null) return command(IntentType.UI_TYPE_TEXT, text, mapOf("text" to type.groupValues[1].trim()))
        if (n.contains("scroll down") || n.contains("neeche scroll") || n.contains("scroll karo")) return command(IntentType.UI_SCROLL, text, mapOf("direction" to "down"))
        if (n.contains("scroll up") || n.contains("upar scroll")) return command(IntentType.UI_SCROLL, text, mapOf("direction" to "up"))
        return null
    }

    private fun looksLikeWhatsAppMessage(n: String): Boolean =
        n.contains("whatsapp") && (n.contains("message") || n.contains("bolo") || n.contains("keh do") || n.contains("batao") || n.contains("likho"))

    private fun extractContactAfterSearch(n: String): String? =
        Regex("(?:chat|contact)\\s+(?:me|mein)\\s+([a-z][a-z0-9 .'-]{1,40}?)\\s+(?:search|dhoond|dhundo|find)", RegexOption.IGNORE_CASE)
            .find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }

    private fun extractContactBeforeMessage(n: String): String? =
        Regex("(?:to|ko|usko|usse)\\s+([a-z][a-z0-9 .'-]{1,40}?)(?:\\s+(?:bolo|batao|message|msg|text|keh do)\\b)", RegexOption.IGNORE_CASE)
            .find(n)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }

    private fun extractMessageBody(text: String): String? {
        Regex("(?i)(?:bolo|batao|keh do|message|msg|text)\\s*[:,-]?\\s*['\"]?(.+?)['\"]?$").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            val cleaned = it.replace(Regex("(?i)^(?:bolo\\s+)+"), "").trim()
            if (cleaned.isNotBlank()) return cleaned
        }
        Regex("(?i)us(?:ko|se)\\s+(.+)$").find(text)?.groupValues?.getOrNull(1)?.trim()?.let {
            val cleaned = it.replace(Regex("(?i)^(?:bolo\\s+)+"), "").trim()
            if (cleaned.isNotBlank()) return cleaned
        }
        return null
    }

    private fun splitClauses(text: String): List<String> {
        val protected = text.replace(Regex("\\b(aur|and|phir|then|uske baad|after that)\\b", RegexOption.IGNORE_CASE), "|")
        return protected.split('|').map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun command(intent: IntentType, raw: String, params: Map<String, String> = emptyMap()) =
        JarvisCommand(UUID.randomUUID().toString(), raw, intent, params)
}
