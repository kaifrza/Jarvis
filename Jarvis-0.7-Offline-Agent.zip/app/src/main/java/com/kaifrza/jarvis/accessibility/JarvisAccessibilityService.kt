package com.kaifrza.jarvis.accessibility

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import com.kaifrza.jarvis.ui.MainActivity
import android.os.Bundle
import android.os.SystemClock

/**
 * Android capability boundary. The service keeps a tiny, non-invasive Jarvis bubble.
 * The full assistant UI is opened as a normal Activity so the IME/keyboard owns a
 * normal focusable window instead of competing with an accessibility overlay.
 */
class JarvisAccessibilityService : android.accessibilityservice.AccessibilityService() {
    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
            private set
    }

    @Volatile var foregroundPackage: String? = null
        private set

    private lateinit var windowManager: WindowManager
    private var bubble: View? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        foregroundPackage = rootInActiveWindow?.packageName?.toString()
        addBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            foregroundPackage = event.packageName?.toString()
        }
    }

    override fun onInterrupt() = Unit

    fun openJarvisUi() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("opened_from_overlay", true)
        }
        startActivity(intent)
    }

    fun performGlobalActionBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performGlobalActionHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performGlobalActionRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun performGlobalActionNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun clickText(text: String): Boolean = clickBestMatchingNode(text)

    fun clickContentDescription(description: String): Boolean {
        val target = normalize(description)
        val deadline = SystemClock.uptimeMillis() + 1_800L
        while (SystemClock.uptimeMillis() < deadline) {
            val root = rootInActiveWindow
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && normalize(n.contentDescription?.toString().orEmpty()).contains(target) }.firstOrNull() }
            if (node != null && clickNodeOrClickableParent(node)) return true
            SystemClock.sleep(120)
        }
        return false
    }

    fun focusEditable(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodes(root) { it.isVisibleToUser && it.isEditable }
            .firstOrNull { it.isFocused } ?: findNodes(root) { it.isVisibleToUser && it.isEditable }.firstOrNull() ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) || node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun typeText(text: String): Boolean {
        val deadline = SystemClock.uptimeMillis() + 1_500L
        while (SystemClock.uptimeMillis() < deadline) {
            val root = rootInActiveWindow
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && n.isEditable && n.isFocused }.firstOrNull() }
                ?: root?.let { findNodes(it) { n -> n.isVisibleToUser && n.isEditable }.firstOrNull() }
            if (node != null) {
                val arguments = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)) return true
            }
            SystemClock.sleep(120)
        }
        return false
    }

    fun scrollForward(): Boolean = scroll(true)
    fun scrollBackward(): Boolean = scroll(false)

    fun findVisibleText(text: String): List<AccessibilityNodeInfo> {
        val root = rootInActiveWindow ?: return emptyList()
        val target = normalize(text)
        return findNodes(root) { it.isVisibleToUser && normalize(it.text?.toString().orEmpty()).contains(target) }
    }

    fun isTextVisible(text: String, timeoutMs: Long = 1_200L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            if (findVisibleText(text).isNotEmpty()) return true
            SystemClock.sleep(120)
        }
        return findVisibleText(text).isNotEmpty()
    }

    fun waitForForegroundPackage(packageName: String, timeoutMs: Long = 2_500L): Boolean {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            if (foregroundPackage == packageName) return true
            SystemClock.sleep(100)
        }
        return foregroundPackage == packageName
    }

    private fun addBubble() {
        val view = TextView(this).apply {
            text = "J"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = rounded(Color.rgb(70, 150, 190), 100)
            elevation = 20f
            setOnClickListener { openJarvisUi() }
        }
        bubble = view
        val params = WindowManager.LayoutParams(
            60, 60,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 18
            y = 0
        }
        windowManager.addView(view, params)
    }

    override fun onDestroy() {
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        instance = null
        super.onDestroy()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun clickBestMatchingNode(text: String): Boolean {
        val target = normalize(text)
        val deadline = SystemClock.uptimeMillis() + 1_800L
        while (SystemClock.uptimeMillis() < deadline) {
            val root = rootInActiveWindow
            val node = root?.let { findNodes(it) { n -> n.isVisibleToUser && normalize(n.text?.toString().orEmpty()).contains(target) }.firstOrNull() }
            if (node != null && clickNodeOrClickableParent(node)) return true
            SystemClock.sleep(120)
        }
        return false
    }

    private fun clickNodeOrClickableParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent = node.parent
        repeat(6) {
            if (parent?.isClickable == true) return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            parent = parent?.parent
        }
        return false
    }

    private fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val candidates = findNodes(root) { it.isVisibleToUser && it.isScrollable }
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return candidates.firstOrNull()?.performAction(action) == true
    }

    private fun findNodes(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        fun visit(node: AccessibilityNodeInfo) {
            if (predicate(node)) result += node
            for (i in 0 until node.childCount) node.getChild(i)?.let(::visit)
        }
        visit(root)
        return result
    }

    private fun normalize(value: String): String = value.lowercase().replace(Regex("\\s+"), " ").trim()
}
