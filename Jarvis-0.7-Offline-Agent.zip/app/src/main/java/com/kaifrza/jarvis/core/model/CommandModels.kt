package com.kaifrza.jarvis.core.model

enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }

enum class CommandState {
    RECEIVED, PLANNED, PREPARED, WAITING_FOR_CHOICE, WAITING_FOR_APPROVAL,
    APPROVED, EXECUTING, VERIFYING, SUCCESS, FAILED, CANCELLED
}

enum class IntentType {
    UNKNOWN,
    OPEN_APP,
    NAVIGATE_BACK,
    HOME,
    RECENTS,
    OPEN_NOTIFICATIONS,
    SET_VOLUME,
    SET_BRIGHTNESS,
    PLAY_MEDIA,
    PAUSE_MEDIA,
    MAKE_CALL,
    SEND_MESSAGE,
    DELETE_FILE,
    CREATE_ALARM,
    CREATE_REMINDER,
    ACCESS_SCREEN,
    UI_CLICK_TEXT,
    UI_TYPE_TEXT,
    UI_FOCUS_INPUT,
    UI_SCROLL
}

data class JarvisCommand(
    val id: String,
    val rawText: String,
    val intent: IntentType,
    val parameters: Map<String, String> = emptyMap()
)

data class ActionPlan(
    val command: JarvisCommand,
    val risk: RiskLevel,
    val requiresConfirmation: Boolean
)
